import os
import re

html_files = [
    'dashboard.html',
    'books.html',
    'book-details.html',
    'users.html',
    'user-profile.html'
]

# Base navigation to inject, without the 'active' state styling.
# Active state logic:
# if active:  'bg-primary text-white border-r-4 border-[#FDBA74]'
# else:       'text-slate-300 hover:bg-slate-700 hover:text-white'

nav_items = [
    ('dashboard.html', 'layout-dashboard', 'Tablero'),
    ('users.html', 'users', 'Gestión de Usuarios'),
    ('books.html', 'library', 'Gestión de Libros'),
    ('catalogo.html', 'book-open', 'Catálogo de Libros'),
    ('#prestamos', 'calendar-check', 'Préstamos'),
    ('#devoluciones', 'archive-restore', 'Devoluciones'),
    ('#reportes', 'file-text', 'Reportes'),
    ('roles.html', 'shield', 'Roles y Permisos')
]

for filename in html_files:
    # We will build the new <nav> content dynamically based on the filename
    new_nav = '<nav class="flex-1 py-6 overflow-y-auto">\n'
    for link, icon, text in nav_items:
        if filename == link:
            active_class = 'bg-primary text-white border-r-4 border-[#FDBA74]'
        else:
            active_class = 'text-slate-300 hover:bg-slate-700 hover:text-white'
        
        new_nav += f'                <a href="{link}" class="flex items-center gap-3 px-6 py-3 transition-colors {active_class}">\n'
        new_nav += f'                    <i data-lucide="{icon}" class="w-5 h-5 flex-shrink-0"></i> <span>{text}</span>\n'
        new_nav += '                </a>\n'
    new_nav += '            </nav>'

    with open(filename, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Regex to replace the entire <nav>...</nav>
    # Note: re.sub with re.DOTALL modifier
    content_replaced = re.sub(r'<nav class="flex-1 py-6 overflow-y-auto">.*?</nav>', new_nav, content, flags=re.DOTALL)
    
    with open(filename, 'w', encoding='utf-8') as f:
        f.write(content_replaced)
    
    print(f'Updated {filename}')
