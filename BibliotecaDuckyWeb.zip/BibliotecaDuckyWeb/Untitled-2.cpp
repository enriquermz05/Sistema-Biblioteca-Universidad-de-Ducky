/*
-------------------------------------------------------
Título: Esqueletización con Zhang-Suen y Poda Greedy
Autores: Rebeca Laredo González y Mariana Gómez del Ángel
Fecha: 25 de Marzo del 2026
Materia: Análisis y Diseño de Algoritmos

Fuente:
- Zhang-Suen Thinning Algorithm
- https://en.cppreference.com/

Firma de honor:
Doy mi palabra que he realizado esta actividad con integridad académica.
-------------------------------------------------------
*/

#include <iostream>
#include <vector>
#include <string>
using namespace std;

typedef vector<vector<int>> Imagen;

struct Punto {
    int fila;
    int columna;
};

// ---------------- FUNCIONES BÁSICAS ----------------

Imagen crearImagenVacia(int filas, int columnas) {
    return Imagen(filas, vector<int>(columnas, 0));
}

void imprimirImagen(const Imagen& img) {
    for (int i = 0; i < (int)img.size(); i++) {
        for (int j = 0; j < (int)img[i].size(); j++) {
            cout << img[i][j] << " ";
        }
        cout << endl;
    }
    cout << endl;
}

bool estaDentro(int i, int j, int filas, int columnas) {
    return i >= 0 && i < filas && j >= 0 && j < columnas;
}

// ---------------- VECINOS ----------------

vector<int> obtenerVecinos(const Imagen& img, int i, int j) {
    return {
        img[i-1][j],     // P2
        img[i-1][j+1],   // P3
        img[i][j+1],     // P4
        img[i+1][j+1],   // P5
        img[i+1][j],     // P6
        img[i+1][j-1],   // P7
        img[i][j-1],     // P8
        img[i-1][j-1]    // P9
    };
}

int contarVecinos(const Imagen& img, int i, int j) {
    vector<int> v = obtenerVecinos(img, i, j);
    int suma = 0;

    for (int k = 0; k < (int)v.size(); k++) {
        suma += v[k];
    }

    return suma;
}

int contarTransiciones(const Imagen& img, int i, int j) {
    vector<int> v = obtenerVecinos(img, i, j);
    int transiciones = 0;

    for (int k = 0; k < 7; k++) {
        if (v[k] == 0 && v[k + 1] == 1) {
            transiciones++;
        }
    }

    if (v[7] == 0 && v[0] == 1) {
        transiciones++;
    }

    return transiciones;
}

// ---------------- ZHANG-SUEN ----------------

bool debeEliminarPaso1(const Imagen& img, int i, int j) {
    int B = contarVecinos(img, i, j);
    int A = contarTransiciones(img, i, j);
    vector<int> p = obtenerVecinos(img, i, j);

    return (B >= 2 && B <= 6 &&
            A == 1 &&
            p[0] * p[2] * p[4] == 0 &&
            p[2] * p[4] * p[6] == 0);
}

bool debeEliminarPaso2(const Imagen& img, int i, int j) {
    int B = contarVecinos(img, i, j);
    int A = contarTransiciones(img, i, j);
    vector<int> p = obtenerVecinos(img, i, j);

    return (B >= 2 && B <= 6 &&
            A == 1 &&
            p[0] * p[2] * p[6] == 0 &&
            p[0] * p[4] * p[6] == 0);
}

void zhangSuen(Imagen& img) {
    bool cambio;

    do {
        cambio = false;
        vector<Punto> aEliminar;

        // Paso 1
        for (int i = 1; i < (int)img.size() - 1; i++) {
            for (int j = 1; j < (int)img[i].size() - 1; j++) {
                if (img[i][j] == 1 && debeEliminarPaso1(img, i, j)) {
                    Punto p;
                    p.fila = i;
                    p.columna = j;
                    aEliminar.push_back(p);
                }
            }
        }

        for (int k = 0; k < (int)aEliminar.size(); k++) {
            img[aEliminar[k].fila][aEliminar[k].columna] = 0;
            cambio = true;
        }

        aEliminar.clear();

        // Paso 2
        for (int i = 1; i < (int)img.size() - 1; i++) {
            for (int j = 1; j < (int)img[i].size() - 1; j++) {
                if (img[i][j] == 1 && debeEliminarPaso2(img, i, j)) {
                    Punto p;
                    p.fila = i;
                    p.columna = j;
                    aEliminar.push_back(p);
                }
            }
        }

        for (int k = 0; k < (int)aEliminar.size(); k++) {
            img[aEliminar[k].fila][aEliminar[k].columna] = 0;
            cambio = true;
        }

    } while (cambio);
}

// ---------------- PODA GREEDY ----------------

void podaGreedy(Imagen& img, int iteracionesMax = 1) {
    for (int iter = 0; iter < iteracionesMax; iter++) {
        vector<Punto> aEliminar;

        for (int i = 1; i < (int)img.size() - 1; i++) {
            for (int j = 1; j < (int)img[i].size() - 1; j++) {
                if (img[i][j] == 1) {
                    int vecinos = contarVecinos(img, i, j);
                    if (vecinos <= 1) {
                        Punto p;
                        p.fila = i;
                        p.columna = j;
                        aEliminar.push_back(p);
                    }
                }
            }
        }

        if (aEliminar.empty()) {
            break;
        }

        for (int k = 0; k < (int)aEliminar.size(); k++) {
            img[aEliminar[k].fila][aEliminar[k].columna] = 0;
        }
    }
}

// ---------------- CASOS DE PRUEBA ----------------

// Caso 1: H Normal (Limpieza base)
void crearHNormal(vector<vector<int>>& img) {
    for (int i = 5; i <= 14; ++i) {
        img[i][5] = 1;
        img[i][6] = 1;
        img[i][13] = 1;
        img[i][14] = 1;
    }
    for (int j = 7; j <= 12; ++j) {
        img[9][j] = 1;
        img[10][j] = 1;
    }
}

// Caso 2: H con Ruido (Validación Greedy)
void crearHConRuido(vector<vector<int>>& img) {
    crearHNormal(img);
    img[7][4] = 1;
    img[7][3] = 1; // Ruido a la izquierda
    img[12][9] = 1; // Ruido tipo "isla"
}

// Caso 3: Cuadrado Relleno
void crearCuadradoRelleno(vector<vector<int>>& img) {
    for (int i = 5; i <= 14; ++i) {
        for (int j = 5; j <= 14; ++j) img[i][j] = 1;
    }
}

// ---------------- PRUEBAS ----------------

void probarCaso(Imagen img, const string& nombre) {
    cout << "\n" << nombre << endl;
    cout << "Imagen original:\n";
    imprimirImagen(img);

    zhangSuen(img);
    podaGreedy(img, 1);

    cout << "Imagen esqueletizada y con poda:\n";
    imprimirImagen(img);
}

// ---------------- MENÚ ----------------

void mostrarMenu() {
    cout << "===== MENU =====" << endl;
    cout << "1. Caso H normal" << endl;
    cout << "2. Caso H con ruido" << endl;
    cout << "3. Caso cuadrado relleno" << endl;
    cout << "4. Salir" << endl;
    cout << "Seleccione una opcion: ";
}

// ---------------- MAIN ----------------

int main() {
    int opcion;

    do {
        mostrarMenu();
        cin >> opcion;

        if (opcion == 1) {
            Imagen h1 = crearImagenVacia(20, 20);
            crearHNormal(h1);
            probarCaso(h1, "Caso 1: H normal");
        }
        else if (opcion == 2) {
            Imagen h2 = crearImagenVacia(20, 20);
            crearHConRuido(h2);
            probarCaso(h2, "Caso 2: H con ruido");
        }
        else if (opcion == 3) {
            Imagen cuadrado = crearImagenVacia(20, 20);
            crearCuadradoRelleno(cuadrado);
            probarCaso(cuadrado, "Caso 3: Cuadrado relleno");
        }
        else if (opcion == 4) {
            cout << "Saliendo del programa..." << endl;
        }
        else {
            cout << "Opcion no valida. Intente otra vez.\n" << endl;
        }

    } while (opcion != 4);

    return 0;
}

/*
---------------- COMPLEJIDAD ----------------

Complejidad temporal:
Zhang-Suen:
O(n * m * k)
donde n y m son las dimensiones de la imagen y k es la cantidad
de iteraciones necesarias hasta estabilizar el esqueleto.

Poda Greedy:
O(n * m * p)
donde p es el numero de iteraciones de poda realizadas.

Complejidad espacial:
O(n * m)
por el almacenamiento de la imagen y la lista auxiliar de pixeles a eliminar.

*/