-- ============================================================
--  SISTEMA DE GESTIÓN DE BIBLIOTECA - Universidad Ducky
--  Schema MySQL para phpMyAdmin
--
--  INSTRUCCIONES:
--  1. Abre phpMyAdmin en http://localhost/phpmyadmin
--  2. Crea una base de datos llamada: biblioteca_ducky
--  3. Selecciona esa base de datos
--  4. Ve a la pestaña "SQL" y pega todo este archivo
--  5. Presiona "Continuar" / "Go"
-- ============================================================

CREATE DATABASE IF NOT EXISTS `biblioteca_ducky`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `biblioteca_ducky`;

-- ============================================================
--  TABLA: libros
-- ============================================================
CREATE TABLE IF NOT EXISTS `libros` (
    `id`                INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `titulo`            VARCHAR(300)    NOT NULL,
    `autor`             VARCHAR(300)    NOT NULL,
    `isbn`              VARCHAR(30)     NOT NULL UNIQUE,
    `categoria`         VARCHAR(100)    NOT NULL DEFAULT '',
    `editorial`         VARCHAR(150)    DEFAULT NULL,
    `anio`              YEAR            DEFAULT NULL,
    `idioma`            VARCHAR(50)     NOT NULL DEFAULT 'Español',
    `paginas`           SMALLINT UNSIGNED DEFAULT NULL,
    `descripcion`       TEXT            DEFAULT NULL,
    `ubicacion`         VARCHAR(100)    DEFAULT NULL,
    `total_copias`      TINYINT UNSIGNED NOT NULL DEFAULT 1,
    `copias_disponibles` TINYINT UNSIGNED NOT NULL DEFAULT 1,
    `estado`            ENUM('Disponible','Prestado','Dañado','Perdido') NOT NULL DEFAULT 'Disponible',
    `condicion`         ENUM('Perfecto','Daño Menor','Dañado','No Utilizable') NOT NULL DEFAULT 'Perfecto',
    `precio_reposicion` DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    `creado_en`         TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `actualizado_en`    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_titulo`    (`titulo`),
    INDEX `idx_isbn`      (`isbn`),
    INDEX `idx_categoria` (`categoria`),
    INDEX `idx_estado`    (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  TABLA: usuarios
-- ============================================================
CREATE TABLE IF NOT EXISTS `usuarios` (
    `id`                INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `nombre`            VARCHAR(150)    NOT NULL,
    `id_universitario`  VARCHAR(50)     NOT NULL UNIQUE,
    `email`             VARCHAR(150)    NOT NULL UNIQUE,
    `password_hash`     VARCHAR(255)    DEFAULT NULL,   -- bcrypt hash
    `telefono`          VARCHAR(30)     DEFAULT NULL,
    `departamento`      VARCHAR(100)    DEFAULT NULL,
    `rol`               ENUM('Administrador','Bibliotecario','Profesor','Estudiante','Colaborador')
                        NOT NULL DEFAULT 'Estudiante',
    `estado`            ENUM('Activo','Inactivo','Suspendido') NOT NULL DEFAULT 'Activo',
    `prestamos_activos` TINYINT UNSIGNED NOT NULL DEFAULT 0,
    `multas_total`      DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    `fecha_registro`    DATE            NOT NULL DEFAULT (CURDATE()),
    `creado_en`         TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `actualizado_en`    TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    INDEX `idx_email`  (`email`),
    INDEX `idx_id_uni` (`id_universitario`),
    INDEX `idx_rol`    (`rol`),
    INDEX `idx_estado` (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  TABLA: prestamos
-- ============================================================
CREATE TABLE IF NOT EXISTS `prestamos` (
    `id`               INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    `libro_id`         INT UNSIGNED    NOT NULL,
    `usuario_id`       INT UNSIGNED    NOT NULL,
    `fecha_prestamo`   DATE            NOT NULL DEFAULT (CURDATE()),
    `fecha_limite`     DATE            NOT NULL,
    `fecha_devolucion` DATE            DEFAULT NULL,
    `estado`           ENUM('Activo','Vencido','Devuelto') NOT NULL DEFAULT 'Activo',
    `multa`            DECIMAL(10,2)   NOT NULL DEFAULT 0.00,
    `creado_en`        TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `actualizado_en`   TIMESTAMP       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    CONSTRAINT `fk_prestamo_libro`
        FOREIGN KEY (`libro_id`) REFERENCES `libros` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_prestamo_usuario`
        FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT,
    INDEX `idx_usuario`  (`usuario_id`),
    INDEX `idx_libro`    (`libro_id`),
    INDEX `idx_estado`   (`estado`),
    INDEX `idx_fecha_lim`(`fecha_limite`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  TABLA: multas
-- ============================================================
CREATE TABLE IF NOT EXISTS `multas` (
    `id`           INT UNSIGNED  NOT NULL AUTO_INCREMENT,
    `usuario_id`   INT UNSIGNED  NOT NULL,
    `prestamo_id`  INT UNSIGNED  DEFAULT NULL,
    `monto`        DECIMAL(10,2) NOT NULL,
    `motivo`       VARCHAR(300)  NOT NULL,
    `fecha`        DATE          NOT NULL DEFAULT (CURDATE()),
    `estado`       ENUM('Pendiente','Pagada','Condonada') NOT NULL DEFAULT 'Pendiente',
    `creado_en`    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    CONSTRAINT `fk_multa_usuario`
        FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE RESTRICT,
    CONSTRAINT `fk_multa_prestamo`
        FOREIGN KEY (`prestamo_id`) REFERENCES `prestamos` (`id`) ON DELETE SET NULL,
    INDEX `idx_usuario` (`usuario_id`),
    INDEX `idx_estado`  (`estado`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  TABLA: roles_permisos  (para el módulo Roles y Permisos)
-- ============================================================
CREATE TABLE IF NOT EXISTS `roles_permisos` (
    `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `rol`        ENUM('Administrador','Bibliotecario','Profesor','Estudiante','Colaborador') NOT NULL,
    `permiso`    VARCHAR(100) NOT NULL,
    `activo`     TINYINT(1)   NOT NULL DEFAULT 1,
    PRIMARY KEY (`id`),
    UNIQUE KEY `uq_rol_permiso` (`rol`, `permiso`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ============================================================
--  EVENTO: actualizar préstamos vencidos automáticamente
--  (requiere event_scheduler = ON en MySQL)
-- ============================================================
DELIMITER $$

CREATE EVENT IF NOT EXISTS `actualizar_prestamos_vencidos`
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    UPDATE prestamos
    SET estado = 'Vencido'
    WHERE estado = 'Activo'
      AND fecha_limite < CURDATE();
END$$

DELIMITER ;

-- ============================================================
--  DATOS INICIALES - Libros
-- ============================================================
INSERT INTO `libros`
    (titulo, autor, isbn, categoria, editorial, anio, idioma, paginas, descripcion, ubicacion, total_copias, copias_disponibles, estado, condicion, precio_reposicion)
VALUES
    ('Sistemas de Bases de Datos: El Libro Completo', 'Hector Garcia-Molina, Jeffrey D. Ullman', '978-0131873254', 'Ciencias de la Computación', 'Pearson', 2008, 'Español', 1248, 'Una introducción completa a los sistemas de bases de datos.', 'Sección A - Estante 15', 5, 2, 'Disponible', 'Perfecto', 850.00),
    ('Inteligencia Artificial: Un Enfoque Moderno', 'Stuart Russell, Peter Norvig', '978-0136042594', 'Ciencias de la Computación', 'Pearson', 2020, 'Español', 1152, 'El texto líder en el campo de la inteligencia artificial.', 'Sección A - Estante 18', 4, 3, 'Disponible', 'Perfecto', 920.00),
    ('Código Limpio', 'Robert C. Martin', '978-0132350884', 'Ciencias de la Computación', 'Prentice Hall', 2008, 'Español', 464, 'Manual de estilo para el desarrollo ágil de software.', 'Sección A - Estante 12', 6, 0, 'Prestado', 'Perfecto', 450.00),
    ('Introducción a Algoritmos', 'Thomas H. Cormen, Charles E. Leiserson', '978-0262033848', 'Ciencias de la Computación', 'MIT Press', 2009, 'Español', 1312, 'Texto completo sobre algoritmos y estructuras de datos.', 'Sección A - Estante 10', 8, 5, 'Disponible', 'Perfecto', 980.00),
    ('Matemáticas Avanzadas para Ingeniería', 'Erwin Kreyszig', '978-0470458365', 'Matemáticas', 'Wiley', 2011, 'Español', 1264, 'Texto completo de matemáticas para ingeniería.', 'Sección B - Estante 5', 10, 7, 'Disponible', 'Perfecto', 750.00);

-- ============================================================
--  DATOS INICIALES - Usuarios
--  Contraseña por defecto para todos: "ducky2024"
--  Hash generado con password_hash('ducky2024', PASSWORD_BCRYPT)
-- ============================================================
INSERT INTO `usuarios`
    (nombre, id_universitario, email, password_hash, telefono, departamento, rol, estado, prestamos_activos, multas_total, fecha_registro)
VALUES
    ('Admin Sistema', 'ADM-0001', 'admin@universidad.edu',
     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', -- password: "ducky2024"
     '+52 555-000-0001', 'Sistemas', 'Administrador', 'Activo', 0, 0.00, '2023-01-01'),

    ('Sarah Johnson', 'EST-2024-001', 'sarah.johnson@universidad.edu',
     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
     '+1 (555) 123-4567', 'Ciencias de la Computación', 'Estudiante', 'Activo', 3, 465.50, '2024-01-15'),

    ('Michael Chen', 'PRF-2022-045', 'm.chen@universidad.edu',
     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
     '+1 (555) 234-5678', 'Ingeniería', 'Profesor', 'Activo', 1, 0.00, '2022-09-01'),

    ('Emma Williams', 'BIB-2023-012', 'e.williams@universidad.edu',
     '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
     '+1 (555) 345-6789', 'Biblioteca', 'Bibliotecario', 'Activo', 0, 0.00, '2023-03-15');

-- ============================================================
--  DATOS INICIALES - Préstamos
-- ============================================================
INSERT INTO `prestamos` (libro_id, usuario_id, fecha_prestamo, fecha_limite, fecha_devolucion, estado, multa)
VALUES
    (1, 2, '2026-02-20', '2026-03-20', NULL, 'Vencido', 0.00),
    (2, 2, '2026-02-25', '2026-03-25', NULL, 'Vencido', 0.00),
    (3, 2, '2026-03-01', '2026-03-31', NULL, 'Vencido', 0.00),
    (5, 3, '2026-01-10', '2026-04-10', NULL, 'Activo',  0.00);

-- ============================================================
--  DATOS INICIALES - Multas
-- ============================================================
INSERT INTO `multas` (usuario_id, prestamo_id, monto, motivo, fecha, estado)
VALUES
    (2, 1, 15.50, 'Devolución tardía - Introducción a Algoritmos', '2026-02-15', 'Pendiente'),
    (2, NULL, 450.00, 'Reposición - Código Limpio (libro perdido)', '2026-03-01', 'Pendiente');

-- ============================================================
--  PERMISOS INICIALES POR ROL
-- ============================================================
INSERT INTO `roles_permisos` (rol, permiso, activo) VALUES
    ('Administrador', 'ver_tablero',         1),
    ('Administrador', 'gestionar_libros',    1),
    ('Administrador', 'gestionar_usuarios',  1),
    ('Administrador', 'gestionar_prestamos', 1),
    ('Administrador', 'gestionar_multas',    1),
    ('Administrador', 'ver_reportes',        1),
    ('Administrador', 'gestionar_roles',     1),

    ('Bibliotecario', 'ver_tablero',         1),
    ('Bibliotecario', 'gestionar_libros',    1),
    ('Bibliotecario', 'gestionar_usuarios',  0),
    ('Bibliotecario', 'gestionar_prestamos', 1),
    ('Bibliotecario', 'gestionar_multas',    1),
    ('Bibliotecario', 'ver_reportes',        1),
    ('Bibliotecario', 'gestionar_roles',     0),

    ('Profesor',      'ver_tablero',         1),
    ('Profesor',      'gestionar_libros',    0),
    ('Profesor',      'gestionar_usuarios',  0),
    ('Profesor',      'gestionar_prestamos', 0),
    ('Profesor',      'gestionar_multas',    0),
    ('Profesor',      'ver_reportes',        0),
    ('Profesor',      'gestionar_roles',     0),

    ('Estudiante',    'ver_tablero',         1),
    ('Estudiante',    'gestionar_libros',    0),
    ('Estudiante',    'gestionar_usuarios',  0),
    ('Estudiante',    'gestionar_prestamos', 0),
    ('Estudiante',    'gestionar_multas',    0),
    ('Estudiante',    'ver_reportes',        0),
    ('Estudiante',    'gestionar_roles',     0),

    ('Colaborador',   'ver_tablero',         1),
    ('Colaborador',   'gestionar_libros',    1),
    ('Colaborador',   'gestionar_usuarios',  0),
    ('Colaborador',   'gestionar_prestamos', 1),
    ('Colaborador',   'gestionar_multas',    0),
    ('Colaborador',   'ver_reportes',        1),
    ('Colaborador',   'gestionar_roles',     0);
