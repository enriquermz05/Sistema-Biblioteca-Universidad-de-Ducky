
  # 2 Universidad Ducky Sistema de gestion bibliteca

  This is a code bundle for 2 Universidad Ducky Sistema de gestion bibliteca. The original project is available at https://www.figma.com/design/1tw6GgCktulG5y2xIr2dMz/2-Universidad-Ducky-Sistema-de-gestion-bibliteca.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  