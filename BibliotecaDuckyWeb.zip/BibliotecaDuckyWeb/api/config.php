<?php
// ============================================================
//  CONFIGURACIÓN DE BASE DE DATOS
//  Edita estos valores con los de tu phpMyAdmin local.
//  Si usas XAMPP: host=localhost, usuario=root, password=''
//  Si usas WAMP:  host=localhost, usuario=root, password='root'
// ============================================================

define('DB_HOST',     'localhost');
define('DB_NAME',     'biblioteca_ducky');
define('DB_USER',     'root');
define('DB_PASSWORD', 'root');        // <-- cambia si tu MySQL tiene contraseña
define('DB_CHARSET',  'utf8mb4');

// ─── Cabeceras CORS (permite llamadas fetch desde el frontend) ───
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// Captura cualquier excepción no atrapada y la devuelve como JSON
set_exception_handler(function (Throwable $e) {
    http_response_code(500);
    echo json_encode([
        'error'   => $e->getMessage(),
        'file'    => basename($e->getFile()),
        'line'    => $e->getLine(),
    ], JSON_UNESCAPED_UNICODE);
    exit;
});

// Convierte errores fatales en excepciones
set_error_handler(function ($severity, $msg, $file, $line) {
    throw new ErrorException($msg, 0, $severity, $file, $line);
}, E_ALL);

// ─── Conexión PDO ─────────────────────────────────────────────────
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASSWORD, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            echo json_encode(['error' => 'Conexión fallida: ' . $e->getMessage()]);
            exit;
        }
    }
    return $pdo;
}

// ─── Helpers ─────────────────────────────────────────────────────
function jsonResponse($data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function getRequestBody(): array {
    $raw = file_get_contents('php://input');
    return json_decode($raw, true) ?? [];
}
