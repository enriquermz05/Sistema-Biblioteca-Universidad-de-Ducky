<?php
require_once 'config.php';

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = $_GET['id'] ?? null;

// ── Query base con JOINs al esquema normalizado ──────────────────────────────
$BASE_SELECT = "
    SELECT
        l.id,
        ANY_VALUE(l.titulo)           AS title,
        ANY_VALUE(l.isbn)             AS isbn,
        COALESCE(GROUP_CONCAT(DISTINCT a.nombre ORDER BY a.nombre SEPARATOR ', '), '') AS author,
        COALESCE(ANY_VALUE(c.nombre), '')        AS category,
        COALESCE(ANY_VALUE(e.nombre), '')        AS publisher,
        COALESCE(ANY_VALUE(i.nombre), 'Español') AS language,
        ANY_VALUE(l.anio_publicacion) AS year,
        ANY_VALUE(l.paginas)          AS pages,
        ANY_VALUE(l.ubicacion)        AS location,
        ANY_VALUE(l.descripcion)      AS description,
        ANY_VALUE(l.precio_reposicion) AS replacementPrice,
        ANY_VALUE(l.estado_catalogo)  AS status,
        ANY_VALUE(l.tipo_uso)         AS `condition`,
        COUNT(DISTINCT cl.id)         AS totalCopies,
        COUNT(DISTINCT CASE
            WHEN LOWER(cl.estado) = 'disponible'
             AND p_act.copia_id IS NULL
            THEN cl.id
        END) AS availableCopies,
        COUNT(DISTINCT CASE WHEN LOWER(cl.estado) = 'perdido' THEN cl.id END) AS lostCopies,
        COUNT(DISTINCT CASE WHEN p_act.copia_id IS NOT NULL   THEN cl.id END) AS loanedCopies
    FROM libros l
    LEFT JOIN categorias   c  ON l.categoria_id  = c.id
    LEFT JOIN editoriales  e  ON l.editorial_id  = e.id
    LEFT JOIN idiomas      i  ON l.idioma_id     = i.id
    LEFT JOIN libro_autor  la ON la.libro_id     = l.id
    LEFT JOIN autores      a  ON a.id            = la.autor_id
    LEFT JOIN copias_libros cl ON cl.libro_id    = l.id
    LEFT JOIN prestamos p_act ON p_act.copia_id = cl.id AND LOWER(p_act.estado) IN ('activo','vencido')
";

function resolveBookStatus(array $row): string {
    $catalogStatus = strtolower($row['status'] ?? '');
    if ($catalogStatus === 'baja') return 'Baja';
    $available = (int)$row['availableCopies'];
    $loaned    = (int)$row['loanedCopies'];
    $lost      = (int)$row['lostCopies'];
    if ($available > 0) return 'Disponible';
    if ($loaned    > 0) return 'Prestado';
    if ($lost      > 0) return 'Perdido';
    return 'Prestado';
}

switch ($method) {

    // ── GET ──────────────────────────────────────────────────────────────────
    case 'GET':
        if ($id) {
            $stmt = $db->prepare("$BASE_SELECT WHERE l.id = ? GROUP BY l.id");
            $stmt->execute([$id]);
            $libro = $stmt->fetch();
            if (!$libro) jsonResponse(['error' => 'Libro no encontrado'], 404);
            $libro['totalCopies']     = (int)$libro['totalCopies'];
            $libro['availableCopies'] = (int)$libro['availableCopies'];
            $libro['lostCopies']      = (int)$libro['lostCopies'];
            $libro['loanedCopies']    = (int)$libro['loanedCopies'];
            $libro['status']          = resolveBookStatus($libro);
            $libro['condition']       = ucfirst(strtolower($libro['condition'] ?? ''));
            jsonResponse($libro);
        } elseif (isset($_GET['meta'])) {
            $authors = $db->query('
                SELECT id, nombre AS name, nacionalidad AS nationality
                FROM autores
                ORDER BY nombre ASC
            ')->fetchAll();
            $publishers = $db->query('
                SELECT id, nombre AS name, pais AS country, contacto AS contact
                FROM editoriales
                ORDER BY nombre ASC
            ')->fetchAll();
            jsonResponse([
                'authors' => $authors,
                'publishers' => $publishers,
            ]);
        } else {
            $q      = $_GET['q']        ?? '';
            $cat    = $_GET['category'] ?? '';
            $status = $_GET['status']   ?? '';

            $where  = 'WHERE 1=1';
            $params = [];

            if ($q) {
                $where .= ' AND (l.titulo LIKE ? OR a.nombre LIKE ? OR l.isbn LIKE ?)';
                $like   = "%$q%";
                $params = array_merge($params, [$like, $like, $like]);
            }
            if ($cat) {
                $where .= ' AND c.nombre = ?';
                $params[] = $cat;
            }
            if ($status) {
                $where .= ' AND LOWER(l.estado_catalogo) = ?';
                $params[] = strtolower($status);
            } elseif (empty($_GET['includeDeleted'])) {
                $where .= " AND LOWER(l.estado_catalogo) <> 'baja'";
            }

            $stmt = $db->prepare("$BASE_SELECT $where GROUP BY l.id ORDER BY l.titulo ASC");
            $stmt->execute($params);
            $rows = $stmt->fetchAll();
            foreach ($rows as &$r) {
                $r['totalCopies']     = (int)$r['totalCopies'];
                $r['availableCopies'] = (int)$r['availableCopies'];
                $r['lostCopies']      = (int)$r['lostCopies'];
                $r['loanedCopies']    = (int)$r['loanedCopies'];
                $r['status']          = resolveBookStatus($r);
                $r['condition']       = ucfirst(strtolower($r['condition'] ?? ''));
            }
            jsonResponse($rows);
        }
        break;

    // ── POST: crear libro + autor/editorial/categoria si no existen ──────────
    case 'POST':
        $data = getRequestBody();
        $db->beginTransaction();

        try {
            // Obtener o crear editorial
            $editorialId = null;
            if (!empty($data['publisher'])) {
                $s = $db->prepare('SELECT id FROM editoriales WHERE LOWER(nombre) = LOWER(?)');
                $s->execute([trim($data['publisher'])]);
                $row = $s->fetch();
                if ($row) {
                    $editorialId = $row['id'];
                } else {
                    $db->prepare('INSERT INTO editoriales (nombre, pais, contacto) VALUES (?,?,?)')
                       ->execute([
                           trim($data['publisher']),
                           $data['publisherCountry'] ?? null,
                           $data['publisherContact'] ?? null,
                       ]);
                    $editorialId = $db->lastInsertId();
                }
            }

            // Obtener o crear categoría
            $categoriaId = null;
            if (!empty($data['category'])) {
                $s = $db->prepare('SELECT id FROM categorias WHERE LOWER(nombre) = LOWER(?)');
                $s->execute([trim($data['category'])]);
                $row = $s->fetch();
                if ($row) {
                    $categoriaId = $row['id'];
                } else {
                    $db->prepare('INSERT INTO categorias (nombre) VALUES (?)')->execute([trim($data['category'])]);
                    $categoriaId = $db->lastInsertId();
                }
            }

            // Obtener o crear idioma
            $idiomaId = null;
            if (!empty($data['language'])) {
                $s = $db->prepare('SELECT id FROM idiomas WHERE LOWER(nombre) = LOWER(?)');
                $s->execute([trim($data['language'])]);
                $row = $s->fetch();
                if ($row) {
                    $idiomaId = $row['id'];
                } else {
                    $db->prepare('INSERT INTO idiomas (nombre) VALUES (?)')->execute([trim($data['language'])]);
                    $idiomaId = $db->lastInsertId();
                }
            }

            // Insertar libro
            $stmt = $db->prepare('
                INSERT INTO libros
                    (titulo, isbn, editorial_id, categoria_id, idioma_id,
                     anio_publicacion, paginas, ubicacion, precio_reposicion,
                     descripcion, tipo_uso, estado_catalogo, fecha_alta)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,NOW())
            ');
            $stmt->execute([
                trim($data['title'] ?? ''),
                trim($data['isbn'] ?? ''),
                $editorialId,
                $categoriaId,
                $idiomaId,
                $data['year']             ?: null,
                $data['pages']            ?: null,
                $data['location']         ?? '',
                $data['replacementPrice'] ?? 0,
                $data['description']      ?? '',
                strtolower($data['condition']        ?? 'Consulta'),
                strtolower($data['status']           ?? 'Disponible'),
            ]);
            $libroId = $db->lastInsertId();

            // Crear autores y asociarlos
            if (!empty($data['author'])) {
                $names = array_map('trim', explode(',', $data['author']));
                foreach ($names as $name) {
                    if ($name === '') continue;
                    $s = $db->prepare('SELECT id FROM autores WHERE LOWER(nombre) = LOWER(?) LIMIT 1');
                    $s->execute([$name]);
                    $row = $s->fetch();
                    if ($row) {
                        $autorId = $row['id'];
                    } else {
                        $db->prepare('INSERT INTO autores (nombre, nacionalidad) VALUES (?,?)')
                           ->execute([$name, $data['authorNationality'] ?? null]);
                        $autorId = $db->lastInsertId();
                    }
                    $db->prepare('INSERT IGNORE INTO libro_autor (libro_id, autor_id) VALUES (?,?)')->execute([$libroId, $autorId]);
                }
            }

            // Crear copias según totalCopies y availableCopies
            $totalCopies = max(1, (int)($data['totalCopies'] ?? 1));
            $availableCopies = max(0, min($totalCopies, (int)($data['availableCopies'] ?? $totalCopies)));
            for ($i = 1; $i <= $totalCopies; $i++) {
                $codigo = 'LIB-' . str_pad($libroId, 4, '0', STR_PAD_LEFT) . '-' . str_pad($i, 3, '0', STR_PAD_LEFT);
                $estadoCopia = $i <= $availableCopies ? 'disponible' : 'prestado';
                $db->prepare('INSERT INTO copias_libros (libro_id, codigo_interno, estado, fecha_adquisicion) VALUES (?,?,?,NOW())')
                   ->execute([$libroId, $codigo, $estadoCopia]);
            }

            $db->commit();
            jsonResponse(['success' => true, 'id' => $libroId], 201);
        } catch (Throwable $e) {
            if ($db->inTransaction()) $db->rollBack();
            throw $e;
        }
        break;

    // ── PUT: actualizar libro ────────────────────────────────────────────────
    case 'PUT':
        if (!$id) jsonResponse(['error' => 'ID requerido'], 400);
        $data = getRequestBody();
        $db->beginTransaction();

        try {
            // Resolver FKs
            $editorialId = null;
            if (!empty($data['publisher'])) {
                $s = $db->prepare('SELECT id FROM editoriales WHERE LOWER(nombre) = LOWER(?)');
                $s->execute([trim($data['publisher'])]);
                $row = $s->fetch();
                if ($row) {
                    $editorialId = $row['id'];
                } else {
                    $db->prepare('INSERT INTO editoriales (nombre, pais, contacto) VALUES (?,?,?)')
                       ->execute([
                           trim($data['publisher']),
                           $data['publisherCountry'] ?? null,
                           $data['publisherContact'] ?? null,
                       ]);
                    $editorialId = $db->lastInsertId();
                }
            }
            $categoriaId = null;
            if (!empty($data['category'])) {
                $s = $db->prepare('SELECT id FROM categorias WHERE LOWER(nombre) = LOWER(?)');
                $s->execute([trim($data['category'])]);
                $row = $s->fetch();
                if ($row) {
                    $categoriaId = $row['id'];
                } else {
                    $db->prepare('INSERT INTO categorias (nombre) VALUES (?)')->execute([trim($data['category'])]);
                    $categoriaId = $db->lastInsertId();
                }
            }
            $idiomaId = null;
            if (!empty($data['language'])) {
                $s = $db->prepare('SELECT id FROM idiomas WHERE LOWER(nombre) = LOWER(?)');
                $s->execute([trim($data['language'])]);
                $row = $s->fetch();
                if ($row) {
                    $idiomaId = $row['id'];
                } else {
                    $db->prepare('INSERT INTO idiomas (nombre) VALUES (?)')->execute([trim($data['language'])]);
                    $idiomaId = $db->lastInsertId();
                }
            }

            $stmt = $db->prepare('
                UPDATE libros SET
                    titulo = ?, isbn = ?, editorial_id = ?, categoria_id = ?, idioma_id = ?,
                    anio_publicacion = ?, paginas = ?, ubicacion = ?, precio_reposicion = ?,
                    descripcion = ?, tipo_uso = ?, estado_catalogo = ?
                WHERE id = ?
            ');
            $stmt->execute([
                trim($data['title'] ?? ''),
                trim($data['isbn'] ?? ''),
                $editorialId,
                $categoriaId,
                $idiomaId,
                $data['year']             ?: null,
                $data['pages']            ?: null,
                $data['location']         ?? '',
                $data['replacementPrice'] ?? 0,
                $data['description']      ?? '',
                strtolower($data['condition']        ?? 'Consulta'),
                strtolower($data['status']           ?? 'Disponible'),
                $id,
            ]);

            // Actualizar autores: borrar asociaciones y recrear
            if (isset($data['author'])) {
                $db->prepare('DELETE FROM libro_autor WHERE libro_id = ?')->execute([$id]);
                $names = array_map('trim', explode(',', $data['author']));
                foreach ($names as $name) {
                    if ($name === '') continue;
                    $s = $db->prepare('SELECT id FROM autores WHERE LOWER(nombre) = LOWER(?) LIMIT 1');
                    $s->execute([$name]);
                    $row = $s->fetch();
                    if ($row) {
                        $autorId = $row['id'];
                    } else {
                        $db->prepare('INSERT INTO autores (nombre, nacionalidad) VALUES (?,?)')
                           ->execute([$name, $data['authorNationality'] ?? null]);
                        $autorId = $db->lastInsertId();
                    }
                    $db->prepare('INSERT IGNORE INTO libro_autor (libro_id, autor_id) VALUES (?,?)')->execute([$id, $autorId]);
                }
            }

            $db->commit();
            jsonResponse(['success' => true]);
        } catch (Throwable $e) {
            if ($db->inTransaction()) $db->rollBack();
            throw $e;
        }
        break;

    // ── DELETE: dar de baja el libro (no borra copias activas) ──────────────
    case 'DELETE':
        if (!$id) jsonResponse(['error' => 'ID requerido'], 400);
        // Solo actualizar estado_catalogo para no romper FK de préstamos
        $db->prepare("UPDATE libros SET estado_catalogo = 'baja' WHERE id = ?")->execute([$id]);
        jsonResponse(['success' => true]);
        break;

    default:
        jsonResponse(['error' => 'Método no permitido'], 405);
}
