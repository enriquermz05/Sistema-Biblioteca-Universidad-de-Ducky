<?php
require_once 'config.php';

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = $_GET['id'] ?? null;

switch ($method) {

    // ── GET: listar reservas ─────────────────────────────────────────
    case 'GET':
        $where  = 'WHERE 1=1';
        $params = [];

        $estado = $_GET['estado'] ?? '';
        if ($estado) {
            $where .= ' AND LOWER(r.estado) = ?';
            $params[] = strtolower($estado);
        }

        $stmt = $db->prepare("
            SELECT
                r.id,
                DATE_FORMAT(r.fecha_reserva,   '%d/%m/%Y %H:%i') AS fechaReserva,
                DATE_FORMAT(r.fecha_expiracion,'%d/%m/%Y %H:%i') AS fechaExpiracion,
                u.id       AS userId,
                u.nombre   AS userName,
                u.correo   AS userEmail,
                u.matricula AS userMatricula,
                ro.nombre  AS userRole,
                l.id       AS bookId,
                l.titulo   AS bookTitle,
                l.isbn     AS bookIsbn,
                LOWER(r.estado) AS estado,
                COUNT(DISTINCT cl.id) AS totalCopias,
                SUM(CASE WHEN LOWER(cl.estado) = 'disponible' THEN 1 ELSE 0 END) AS copiasDisponibles,
                COALESCE(SUM(DISTINCT CASE WHEN LOWER(m.estado) = 'pendiente' THEN m.monto ELSE 0 END), 0) AS multasPendientes
            FROM reservas r
            JOIN usuarios u  ON r.usuario_id = u.id
            JOIN roles    ro ON u.rol_id     = ro.id
            JOIN libros   l  ON r.libro_id   = l.id
            LEFT JOIN copias_libros cl ON cl.libro_id = l.id
            LEFT JOIN multas m ON m.usuario_id = u.id AND LOWER(m.estado) = 'pendiente'
            $where
            GROUP BY r.id
            ORDER BY r.fecha_reserva DESC
        ");
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        foreach ($rows as &$row) {
            $row['copiasDisponibles'] = (int)($row['copiasDisponibles']   ?? 0);
            $row['totalCopias']       = (int)($row['totalCopias']         ?? 0);
            $row['multasPendientes']  = (float)($row['multasPendientes']  ?? 0);
        }

        jsonResponse($rows);
        break;

    // ── PUT: aprobar o rechazar ──────────────────────────────────────
    case 'PUT':
        $data   = getRequestBody();
        $id     = $id ?? $data['id'] ?? null;   // acepta id en URL o en body
        $action = $data['action'] ?? '';

        if (!$id) jsonResponse(['error' => 'ID requerido'], 400);

        // ── Aprobar ──────────────────────────────────────────────────
        if ($action === 'aprobar') {
            $dueDate       = $data['dueDate']     ?? null;
            $librarianId   = $data['librarianId'] ?? null;

            if (!$dueDate)     jsonResponse(['error' => 'dueDate requerido'],     400);
            if (!$librarianId) jsonResponse(['error' => 'librarianId requerido'], 400);

            // Cargar la reserva
            $stmt = $db->prepare("
                SELECT * FROM reservas
                WHERE id = ? AND LOWER(estado) IN ('activa','pendiente')
            ");
            $stmt->execute([$id]);
            $reserva = $stmt->fetch();

            if (!$reserva) {
                jsonResponse(['error' => 'Reserva no encontrada o ya procesada'], 404);
            }

            $db->beginTransaction();
            try {
                // Verificar usuario activo
                $userStmt = $db->prepare("SELECT estado FROM usuarios WHERE id = ? FOR UPDATE");
                $userStmt->execute([$reserva['usuario_id']]);
                $user = $userStmt->fetch();
                if (!$user || strtolower($user['estado']) !== 'activo') {
                    $db->rollBack();
                    jsonResponse(['error' => 'El usuario no está activo'], 409);
                }

                // Verificar multas pendientes
                $fineStmt = $db->prepare("
                    SELECT COUNT(*) AS cnt FROM multas
                    WHERE usuario_id = ? AND LOWER(estado) = 'pendiente'
                ");
                $fineStmt->execute([$reserva['usuario_id']]);
                if ((int)$fineStmt->fetch()['cnt'] > 0) {
                    $db->rollBack();
                    jsonResponse(['error' => 'El usuario tiene multas pendientes'], 409);
                }

                // Buscar copia disponible
                $copyStmt = $db->prepare("
                    SELECT cl.id FROM copias_libros cl
                    WHERE cl.libro_id = ?
                      AND LOWER(cl.estado) = 'disponible'
                      AND NOT EXISTS (
                          SELECT 1 FROM prestamos p
                          WHERE p.copia_id = cl.id
                            AND LOWER(p.estado) IN ('activo','vencido')
                      )
                    ORDER BY cl.id ASC
                    LIMIT 1
                    FOR UPDATE
                ");
                $copyStmt->execute([$reserva['libro_id']]);
                $copy = $copyStmt->fetch();

                if (!$copy) {
                    $db->rollBack();
                    jsonResponse(['error' => 'No hay copias disponibles del libro'], 409);
                }

                // Crear préstamo
                $db->prepare("
                    INSERT INTO prestamos
                        (usuario_id, copia_id, bibliotecario_id, fecha_prestamo, fecha_vencimiento, numero_renovaciones, estado)
                    VALUES (?, ?, ?, NOW(), ?, 0, 'activo')
                ")->execute([$reserva['usuario_id'], $copy['id'], $librarianId, $dueDate]);

                $newLoanId = $db->lastInsertId();

                // Marcar copia como prestada
                $db->prepare("UPDATE copias_libros SET estado = 'prestado' WHERE id = ?")
                   ->execute([$copy['id']]);

                // Marcar reserva como atendida
                $db->prepare("UPDATE reservas SET estado = 'atendida' WHERE id = ?")
                   ->execute([$id]);

                $db->commit();
                jsonResponse(['success' => true, 'prestamoId' => $newLoanId], 201);

            } catch (Exception $e) {
                if ($db->inTransaction()) $db->rollBack();
                jsonResponse(['error' => 'Error al aprobar reserva: ' . $e->getMessage()], 500);
            }
        }

        // ── Rechazar ─────────────────────────────────────────────────
        if ($action === 'rechazar') {
            $stmt = $db->prepare("
                UPDATE reservas SET estado = 'cancelada'
                WHERE id = ? AND LOWER(estado) IN ('activa','pendiente')
            ");
            $stmt->execute([$id]);

            if ($stmt->rowCount() === 0) {
                jsonResponse(['error' => 'Reserva no encontrada o ya procesada'], 404);
            }

            jsonResponse(['success' => true]);
        }

        jsonResponse(['error' => 'Acción no reconocida. Usa "aprobar" o "rechazar"'], 400);
        break;

    default:
        jsonResponse(['error' => 'Método no permitido'], 405);
}
