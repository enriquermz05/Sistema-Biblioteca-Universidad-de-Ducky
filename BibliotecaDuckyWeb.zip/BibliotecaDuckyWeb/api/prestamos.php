<?php
require_once 'config.php';

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = $_GET['id'] ?? null;

const FINE_PER_DAY = 5.00;

function calcFine(string $dueDate): float {
    $due   = new DateTime($dueDate);
    $today = new DateTime('today');
    $diff  = $today->diff($due);
    return $diff->invert ? $diff->days * FINE_PER_DAY : 0.0;
}

// ── Query base ───────────────────────────────────────────────────────────────
$BASE_SELECT = "
    SELECT
        p.id,
        p.usuario_id    AS userId,
        u.nombre        AS userName,
        u.correo        AS userEmail,
        p.copia_id      AS copyId,
        l.id            AS bookId,
        l.titulo        AS bookTitle,
        l.isbn          AS bookIsbn,
        DATE_FORMAT(p.fecha_prestamo,    '%d/%m/%Y') AS borrowDate,
        DATE_FORMAT(p.fecha_vencimiento, '%d/%m/%Y') AS dueDate,
        p.estado        AS status,
        DATE_FORMAT(d.fecha_devolucion,  '%d/%m/%Y') AS returnDate,
        COALESCE((SELECT SUM(m.monto) FROM multas m WHERE m.prestamo_id = p.id AND m.estado = 'pendiente'), 0) AS fineAmount,
        p.numero_renovaciones AS renewals
    FROM prestamos p
    JOIN usuarios      u  ON p.usuario_id       = u.id
    JOIN copias_libros cl ON p.copia_id         = cl.id
    JOIN libros        l  ON cl.libro_id        = l.id
    LEFT JOIN devoluciones d ON d.prestamo_id   = p.id
";

switch ($method) {

    // ── GET ──────────────────────────────────────────────────────────────────
    case 'GET':
        if ($id) {
            $stmt = $db->prepare("$BASE_SELECT WHERE p.id = ?");
            $stmt->execute([$id]);
            $loan = $stmt->fetch();
            $loan ? jsonResponse($loan) : jsonResponse(['error' => 'Préstamo no encontrado'], 404);
        } else {
            $status = $_GET['status']  ?? '';
            $userId = $_GET['usuario'] ?? '';
            $bookId = $_GET['libro']   ?? '';

            $where  = 'WHERE 1=1';
            $params = [];

            if ($status) { $where .= ' AND LOWER(p.estado) = ?';     $params[] = strtolower($status); }
            if ($userId) { $where .= ' AND p.usuario_id = ?'; $params[] = $userId; }
            if ($bookId) { $where .= ' AND l.id = ?';         $params[] = $bookId; }

            $stmt = $db->prepare("$BASE_SELECT $where ORDER BY p.fecha_prestamo DESC");
            $stmt->execute($params);
            $rows = $stmt->fetchAll();
            foreach ($rows as &$r) {
                $r['status'] = ucfirst(strtolower($r['status'] ?? ''));
            }
            jsonResponse($rows);
        }
        break;

    // ── POST: crear préstamo ─────────────────────────────────────────────────
    case 'POST':
        $data = getRequestBody();

        $userId        = $data['userId']        ?? null;
        $bookId        = $data['bookId']        ?? null;
        $due           = $data['dueDate']       ?? null; // YYYY-MM-DD
        $bibliotecario = $data['librarianId']   ?? $userId;

        if (!$userId || !$bookId || !$due) {
            jsonResponse(['error' => 'userId, bookId y dueDate son requeridos'], 400);
        }

        $db->beginTransaction();
        try {
            // Verificar usuario y bloquear su fila durante la operación.
            $userStmt = $db->prepare("SELECT estado FROM usuarios WHERE id = ? FOR UPDATE");
            $userStmt->execute([$userId]);
            $userRow = $userStmt->fetch();
            if (!$userRow) {
                $db->rollBack();
                jsonResponse(['error' => 'Usuario no encontrado'], 404);
            }
            if (strtolower($userRow['estado'] ?? '') !== 'activo') {
                $db->rollBack();
                jsonResponse(['error' => 'El usuario no está activo'], 409);
            }

            // Bloquear préstamos si el usuario tiene multas pendientes registradas en MySQL.
            $fineStmt = $db->prepare("
                SELECT COUNT(*) AS pendingCount, COALESCE(SUM(monto), 0) AS pendingTotal
                FROM multas
                WHERE usuario_id = ?
                  AND LOWER(estado) = 'pendiente'
            ");
            $fineStmt->execute([$userId]);
            $fineRow = $fineStmt->fetch();
            if ((int)($fineRow['pendingCount'] ?? 0) > 0) {
                $db->rollBack();
                $total = number_format((float)$fineRow['pendingTotal'], 2);
                jsonResponse([
                    'error' => "El usuario tiene multas pendientes por $$total MXN. No puede registrar nuevos préstamos hasta liquidarlas."
                ], 409);
            }

            // Elegir y bloquear una copia disponible del libro. Esto evita doble préstamo simultáneo.
            $copyStmt = $db->prepare("
                SELECT cl.id
                FROM copias_libros cl
                WHERE cl.libro_id = ?
                  AND LOWER(cl.estado) = 'disponible'
                  AND NOT EXISTS (
                      SELECT 1
                      FROM prestamos p
                      WHERE p.copia_id = cl.id
                        AND LOWER(p.estado) IN ('activo','vencido')
                  )
                ORDER BY cl.id ASC
                LIMIT 1
                FOR UPDATE
            ");
            $copyStmt->execute([$bookId]);
            $copy = $copyStmt->fetch();
            if (!$copy) {
                $db->rollBack();
                jsonResponse(['error' => 'El libro no tiene copias disponibles'], 409);
            }

            $copyId = $copy['id'];

            $db->prepare('
                INSERT INTO prestamos (usuario_id, copia_id, bibliotecario_id, fecha_prestamo, fecha_vencimiento, numero_renovaciones, estado)
                VALUES (?, ?, ?, NOW(), ?, 0, "activo")
            ')->execute([$userId, $copyId, $bibliotecario, $due]);
            $newId = $db->lastInsertId();

            $db->prepare("UPDATE copias_libros SET estado = 'prestado' WHERE id = ?")->execute([$copyId]);

            $db->commit();
            jsonResponse(['success' => true, 'id' => $newId], 201);
        } catch (Exception $e) {
            if ($db->inTransaction()) $db->rollBack();
            jsonResponse(['error' => 'Error al registrar préstamo: ' . $e->getMessage()], 500);
        }
        break;

    // ── PUT: renovar préstamo ────────────────────────────────────────────────
    case 'PUT':
        if (!$id) jsonResponse(['error' => 'ID requerido'], 400);
        $data   = getRequestBody();
        $action = $data['action'] ?? 'renovar';

        if ($action === 'renovar') {
            $stmt = $db->prepare('SELECT * FROM prestamos WHERE id = ? AND estado IN ("activo","vencido")');
            $stmt->execute([$id]);
            $loan = $stmt->fetch();
            if (!$loan) jsonResponse(['error' => 'Préstamo no encontrado o no renovable'], 404);

            $newDue         = $data['newDueDate'] ?? null;
            $autorizadoPor  = $data['librarianId'] ?? $loan['bibliotecario_id'];

            if (!$newDue) jsonResponse(['error' => 'newDueDate requerido'], 400);

            // Registrar renovación
            $db->prepare('
                INSERT INTO renovaciones (prestamo_id, fecha_renovacion, fecha_vencimiento_anterior, fecha_vencimiento_nueva, autorizado_por)
                VALUES (?, NOW(), ?, ?, ?)
            ')->execute([$id, $loan['fecha_vencimiento'], $newDue, $autorizadoPor]);

            // Actualizar préstamo
            $db->prepare('
                UPDATE prestamos SET fecha_vencimiento = ?, numero_renovaciones = numero_renovaciones + 1, estado = "activo"
                WHERE id = ?
            ')->execute([$newDue, $id]);

            jsonResponse(['success' => true]);
        }

        jsonResponse(['error' => 'Acción no reconocida'], 400);
        break;

    // ── DELETE: cancelar préstamo (devuelve la copia) ────────────────────────
    case 'DELETE':
        if (!$id) jsonResponse(['error' => 'ID requerido'], 400);

        $stmt = $db->prepare('SELECT * FROM prestamos WHERE id = ? AND estado NOT IN ("devuelto","cancelado")');
        $stmt->execute([$id]);
        $loan = $stmt->fetch();
        if (!$loan) jsonResponse(['error' => 'Préstamo no encontrado o ya cerrado'], 404);

        $db->prepare("UPDATE prestamos SET estado = 'cancelado' WHERE id = ?")->execute([$id]);
        $db->prepare("UPDATE copias_libros SET estado = 'disponible' WHERE id = ?")->execute([$loan['copia_id']]);

        jsonResponse(['success' => true]);
        break;

    default:
        jsonResponse(['error' => 'Método no permitido'], 405);
}
