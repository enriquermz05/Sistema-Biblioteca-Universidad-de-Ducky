<?php
require_once 'config.php';

$db = getDB();
$method = $_SERVER['REQUEST_METHOD'];

function columnExists(PDO $db, string $table, string $column): bool {
    $stmt = $db->prepare("SELECT COUNT(*) AS total FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
    $stmt->execute([$table, $column]);
    return (int)($stmt->fetch()['total'] ?? 0) > 0;
}

function ensureExternalSchema(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS entidades_externas (
        id int PRIMARY KEY AUTO_INCREMENT,
        nombre varchar(255) UNIQUE NOT NULL,
        tipo varchar(255) UNIQUE NOT NULL,
        descripcion varchar(255),
        estado varchar(255) NOT NULL DEFAULT 'activo'
    ) ENGINE=InnoDB");

    $db->exec("CREATE TABLE IF NOT EXISTS microcontroladores_integracion (
        id int PRIMARY KEY AUTO_INCREMENT,
        entidad_externa_id int NOT NULL,
        codigo varchar(255) UNIQUE NOT NULL,
        ubicacion varchar(255),
        estado varchar(255) NOT NULL DEFAULT 'activo',
        ultimo_ping datetime,
        INDEX (entidad_externa_id)
    ) ENGINE=InnoDB");

    $db->exec("CREATE TABLE IF NOT EXISTS eventos_microcontrolador (
        id int PRIMARY KEY AUTO_INCREMENT,
        microcontrolador_id int NOT NULL,
        accion varchar(255) NOT NULL,
        payload json,
        fecha_evento datetime NOT NULL,
        estado varchar(255) NOT NULL,
        INDEX (microcontrolador_id)
    ) ENGINE=InnoDB");

    $db->exec("CREATE TABLE IF NOT EXISTS registros_entidad_externa (
        id int PRIMARY KEY AUTO_INCREMENT,
        entidad_externa_id int NOT NULL,
        clave_externa varchar(255) UNIQUE NOT NULL,
        nombre varchar(255) NOT NULL,
        correo varchar(255),
        matricula varchar(255),
        rol_sugerido varchar(255) NOT NULL,
        area varchar(255),
        payload json,
        estado varchar(255) NOT NULL DEFAULT 'pendiente',
        fecha_sincronizacion datetime NOT NULL,
        INDEX (entidad_externa_id)
    ) ENGINE=InnoDB");

    if (columnExists($db, 'usuarios', 'entidad_externa_id') === false) {
        $db->exec("ALTER TABLE usuarios ADD COLUMN entidad_externa_id int NULL AFTER rol_id");
    }
    if (columnExists($db, 'pagos', 'entidad_externa_id') === false) {
        $db->exec("ALTER TABLE pagos ADD COLUMN entidad_externa_id int NULL AFTER multa_id");
    }

    seedExternalEntities($db);
}

function seedExternalEntities(PDO $db): void {
    $entities = [
        ['Sistema Escolar', 'escolar', 'Entidad externa que provee alumnos inscritos', 'MCU-ESCOLAR-01'],
        ['Recursos Humanos', 'recursos_humanos', 'Entidad externa que provee profesores y colaboradores', 'MCU-RH-01'],
        ['Tesorería', 'tesoreria', 'Entidad externa que valida pagos y multas', 'MCU-TESORERIA-01'],
    ];

    $insertEntity = $db->prepare("INSERT IGNORE INTO entidades_externas (nombre, tipo, descripcion, estado) VALUES (?, ?, ?, 'activo')");
    $selectEntity = $db->prepare("SELECT id FROM entidades_externas WHERE tipo = ?");
    $insertMcu = $db->prepare("INSERT IGNORE INTO microcontroladores_integracion (entidad_externa_id, codigo, ubicacion, estado, ultimo_ping) VALUES (?, ?, 'Rack de integración biblioteca', 'activo', NOW())");

    foreach ($entities as [$name, $type, $description, $code]) {
        $insertEntity->execute([$name, $type, $description]);
        $selectEntity->execute([$type]);
        $entity = $selectEntity->fetch();
        if ($entity) $insertMcu->execute([$entity['id'], $code]);
    }

    $records = [
        ['escolar', 'ESC-ALU-1001', 'Ana Sofia Reyes', 'ana.reyes@uni.edu', 'ALU-1001', 'alumno', 'Ingeniería en Software', ['semestre' => 4, 'sensor' => 'lector-rfid-escolar']],
        ['escolar', 'ESC-ALU-1002', 'Luis Martinez Gomez', 'luis.martinez@uni.edu', 'ALU-1002', 'alumno', 'Arquitectura', ['semestre' => 2, 'sensor' => 'lector-rfid-escolar']],
        ['escolar', 'ESC-ALU-1003', 'Valeria Perez', 'valeria.perez@uni.edu', 'ALU-1003', 'alumno', 'Derecho', ['semestre' => 6, 'sensor' => 'lector-rfid-escolar']],
        ['recursos_humanos', 'RH-PRO-2001', 'Dr. Roberto Silva', 'roberto.silva@uni.edu', 'PRO-2001', 'profesor', 'Ciencias Exactas', ['puesto' => 'Profesor titular', 'sensor' => 'nodo-rh']],
        ['recursos_humanos', 'RH-PRO-2002', 'Mtra. Carmen Rodriguez', 'carmen.rodriguez@uni.edu', 'PRO-2002', 'profesor', 'Humanidades', ['puesto' => 'Profesora', 'sensor' => 'nodo-rh']],
        ['recursos_humanos', 'RH-COL-3001', 'Mariana Torres', 'mariana.torres@ducky.edu', 'COL-3001', 'colaborador', 'Biblioteca', ['puesto' => 'Auxiliar administrativo', 'sensor' => 'nodo-rh']],
    ];

    $selectEntityByType = $db->prepare("SELECT id FROM entidades_externas WHERE tipo = ?");
    $insertRecord = $db->prepare("INSERT IGNORE INTO registros_entidad_externa
        (entidad_externa_id, clave_externa, nombre, correo, matricula, rol_sugerido, area, payload, estado, fecha_sincronizacion)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pendiente', NOW())");

    foreach ($records as [$type, $externalKey, $name, $email, $matricula, $role, $area, $payload]) {
        $selectEntityByType->execute([$type]);
        $entity = $selectEntityByType->fetch();
        if (!$entity) continue;
        $insertRecord->execute([$entity['id'], $externalKey, $name, $email, $matricula, $role, $area, json_encode($payload, JSON_UNESCAPED_UNICODE)]);
    }
}

function normalizeExternalType(?string $value): string {
    $key = strtolower(trim($value ?? ''));
    return [
        'escolar' => 'escolar',
        'capitalhumano' => 'recursos_humanos',
        'capital_humano' => 'recursos_humanos',
        'recursos_humanos' => 'recursos_humanos',
        'recursos humanos' => 'recursos_humanos',
        'rh' => 'recursos_humanos',
        'tesoreria' => 'tesoreria',
        'tesorería' => 'tesoreria',
    ][$key] ?? $key;
}

function logMicrocontrollerFetch(PDO $db, int $microcontrollerId, string $type, int $recordsCount): int {
    $db->prepare("UPDATE microcontroladores_integracion SET ultimo_ping = NOW(), estado = 'activo' WHERE id = ?")
       ->execute([$microcontrollerId]);

    $payload = json_encode([
        'origen' => $type,
        'registros_recibidos' => $recordsCount,
        'protocolo' => 'UART->HTTP gateway simulado',
    ], JSON_UNESCAPED_UNICODE);

    $stmt = $db->prepare("INSERT INTO eventos_microcontrolador (microcontrolador_id, accion, payload, fecha_evento, estado) VALUES (?, 'lectura_externa', ?, NOW(), 'procesado')");
    $stmt->execute([$microcontrollerId, $payload]);
    return (int)$db->lastInsertId();
}

ensureExternalSchema($db);

if ($method !== 'GET') {
    jsonResponse(['error' => 'Método no permitido'], 405);
}

$type = normalizeExternalType($_GET['tipo'] ?? $_GET['origin'] ?? '');
if (!$type) {
    jsonResponse(['error' => 'Tipo de entidad externa requerido'], 400);
}

$stmt = $db->prepare("SELECT id, nombre, tipo, descripcion, estado FROM entidades_externas WHERE tipo = ? AND LOWER(estado) = 'activo'");
$stmt->execute([$type]);
$entity = $stmt->fetch();
if (!$entity) jsonResponse(['error' => 'Entidad externa no encontrada'], 404);

$mcuStmt = $db->prepare("SELECT id, codigo, ubicacion, estado, ultimo_ping FROM microcontroladores_integracion WHERE entidad_externa_id = ? AND LOWER(estado) = 'activo' ORDER BY id LIMIT 1");
$mcuStmt->execute([$entity['id']]);
$microcontroller = $mcuStmt->fetch();
if (!$microcontroller) jsonResponse(['error' => 'No hay microcontrolador activo para la entidad externa'], 409);

$recordsStmt = $db->prepare("SELECT
        id,
        clave_externa AS externalId,
        nombre AS name,
        correo AS email,
        matricula AS universityId,
        rol_sugerido AS role,
        area AS department,
        estado AS status,
        fecha_sincronizacion AS syncedAt
    FROM registros_entidad_externa
    WHERE entidad_externa_id = ?
    ORDER BY nombre ASC");
$recordsStmt->execute([$entity['id']]);
$records = $recordsStmt->fetchAll();

$eventId = logMicrocontrollerFetch($db, (int)$microcontroller['id'], $type, count($records));
$microcontroller['lastEventId'] = $eventId;
$microcontroller['ultimo_ping'] = date('Y-m-d H:i:s');

jsonResponse([
    'entity' => $entity,
    'microcontroller' => $microcontroller,
    'records' => $records,
]);
