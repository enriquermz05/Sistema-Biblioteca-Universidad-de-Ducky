<?php
require_once 'config.php';

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = $_GET['id'] ?? null;

function columnExists(PDO $db, string $table, string $column): bool {
    $stmt = $db->prepare("SELECT COUNT(*) AS total FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?");
    $stmt->execute([$table, $column]);
    return (int)($stmt->fetch()['total'] ?? 0) > 0;
}

function ensureExternalTablesForUsers(PDO $db): void {
    $db->exec("CREATE TABLE IF NOT EXISTS entidades_externas (id int PRIMARY KEY AUTO_INCREMENT, nombre varchar(255) UNIQUE NOT NULL, tipo varchar(255) UNIQUE NOT NULL, descripcion varchar(255), estado varchar(255) NOT NULL DEFAULT 'activo') ENGINE=InnoDB");
    $db->exec("CREATE TABLE IF NOT EXISTS registros_entidad_externa (id int PRIMARY KEY AUTO_INCREMENT, entidad_externa_id int NOT NULL, clave_externa varchar(255) UNIQUE NOT NULL, nombre varchar(255) NOT NULL, correo varchar(255), matricula varchar(255), rol_sugerido varchar(255) NOT NULL, area varchar(255), payload json, estado varchar(255) NOT NULL DEFAULT 'pendiente', fecha_sincronizacion datetime NOT NULL, INDEX (entidad_externa_id)) ENGINE=InnoDB");
    $db->exec("CREATE TABLE IF NOT EXISTS suspensiones (id int PRIMARY KEY AUTO_INCREMENT, usuario_id int NOT NULL, motivo varchar(255) NOT NULL, fecha_inicio datetime NOT NULL, fecha_fin datetime NULL, estado varchar(255) NOT NULL, INDEX (usuario_id)) ENGINE=InnoDB");
    if (!columnExists($db, 'usuarios', 'entidad_externa_id')) {
        $db->exec("ALTER TABLE usuarios ADD COLUMN entidad_externa_id int NULL AFTER rol_id");
    }
}
ensureExternalTablesForUsers($db);

function normalizeRoleForDB(?string $role): string {
    $key = strtolower(trim($role ?? ''));
    return [
        'administrador' => 'admin',
        'admin' => 'admin',
        'bibliotecario' => 'bibliotecario',
        'profesor' => 'profesor',
        'alumno' => 'alumno',
        'estudiante' => 'alumno',
        'colaborador' => 'colaborador',
    ][$key] ?? $key;
}


switch ($method) {

    // ── GET ──────────────────────────────────────────────────────────────────
    case 'GET':
        if ($id) {
            $stmt = $db->prepare("
                SELECT
                    u.id,
                    u.nombre        AS name,
                    u.matricula     AS universityId,
                    u.correo        AS email,
                    r.nombre        AS role,
                    ee.nombre       AS externalSource,
                    ee.tipo         AS externalSourceType,
                    u.estado        AS status,
                    u.fecha_creacion AS joinedDate,
                    COALESCE(p_act.cnt, 0)  AS activeLoans,
                    COALESCE(m_sum.total, 0) AS fines
                FROM usuarios u
                LEFT JOIN roles r ON u.rol_id = r.id
                LEFT JOIN entidades_externas ee ON u.entidad_externa_id = ee.id
                LEFT JOIN (
                    SELECT usuario_id, COUNT(*) AS cnt
                    FROM prestamos
                    WHERE LOWER(estado) IN ('activo','vencido')
                    GROUP BY usuario_id
                ) p_act ON p_act.usuario_id = u.id
                LEFT JOIN (
                    SELECT usuario_id, SUM(monto) AS total
                    FROM multas
                    WHERE LOWER(estado) = 'pendiente'
                    GROUP BY usuario_id
                ) m_sum ON m_sum.usuario_id = u.id
                WHERE u.id = ?
            ");
            $stmt->execute([$id]);
            $user = $stmt->fetch();
            if (!$user) jsonResponse(['error' => 'Usuario no encontrado'], 404);

            // Préstamos activos con título de libro
            $loans = $db->prepare("
                SELECT p.id, l.titulo AS bookTitle,
                       DATE_FORMAT(p.fecha_prestamo, '%d/%m/%Y')   AS borrowDate,
                       DATE_FORMAT(p.fecha_vencimiento, '%d/%m/%Y') AS dueDate,
                       p.estado AS status
                FROM prestamos p
                JOIN copias_libros cl ON p.copia_id  = cl.id
                JOIN libros        l  ON cl.libro_id = l.id
                WHERE p.usuario_id = ?
                ORDER BY p.fecha_prestamo DESC
            ");
            $loans->execute([$id]);
            $user['loans'] = $loans->fetchAll();

            // Multas pendientes
            $fines = $db->prepare("
                SELECT m.id, m.monto AS amount, m.observaciones AS reason,
                       DATE_FORMAT(m.fecha_generacion, '%d/%m/%Y') AS date,
                       m.estado AS status
                FROM multas m
                WHERE m.usuario_id = ?
                ORDER BY m.fecha_generacion DESC
            ");
            $fines->execute([$id]);
            $user['fineHistory'] = $fines->fetchAll();

            $user['activeLoans'] = (int)$user['activeLoans'];
            $user['fines']       = (float)$user['fines'];
            jsonResponse($user);
        } else {
            $q      = $_GET['q']      ?? '';
            $role   = $_GET['role']   ?? '';
            $status = $_GET['status'] ?? '';

            $sql = "
                SELECT
                    u.id,
                    u.nombre        AS name,
                    u.matricula     AS universityId,
                    u.correo        AS email,
                    r.nombre        AS role,
                    ee.nombre       AS externalSource,
                    ee.tipo         AS externalSourceType,
                    u.estado        AS status,
                    u.fecha_creacion AS joinedDate,
                    COALESCE(p_act.cnt, 0)  AS activeLoans,
                    COALESCE(m_sum.total, 0) AS fines
                FROM usuarios u
                LEFT JOIN roles r ON u.rol_id = r.id
                LEFT JOIN entidades_externas ee ON u.entidad_externa_id = ee.id
                LEFT JOIN (
                    SELECT usuario_id, COUNT(*) AS cnt
                    FROM prestamos
                    WHERE LOWER(estado) IN ('activo','vencido')
                    GROUP BY usuario_id
                ) p_act ON p_act.usuario_id = u.id
                LEFT JOIN (
                    SELECT usuario_id, SUM(monto) AS total
                    FROM multas
                    WHERE LOWER(estado) = 'pendiente'
                    GROUP BY usuario_id
                ) m_sum ON m_sum.usuario_id = u.id
                WHERE 1=1
            ";
            $params = [];

            if ($q) {
                $sql .= ' AND (u.nombre LIKE ? OR u.correo LIKE ? OR u.matricula LIKE ?)';
                $like = "%$q%";
                $params = array_merge($params, [$like, $like, $like]);
            }
            if ($role) {
                $sql .= ' AND LOWER(r.nombre) = ?';
                $params[] = normalizeRoleForDB($role);
            }
            if ($status) {
                $sql .= ' AND LOWER(u.estado) = ?';
                $params[] = strtolower($status);
            }
            $sql .= ' ORDER BY u.nombre ASC';

            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $rows = $stmt->fetchAll();
            foreach ($rows as &$r) {
                $r['activeLoans'] = (int)$r['activeLoans'];
                $r['fines']       = (float)$r['fines'];
                $r['status']      = ucfirst(strtolower($r['status'] ?? ''));
                $r['role']        = ucfirst(strtolower($r['role']   ?? ''));
            }
            jsonResponse($rows);
        }
        break;

    // ── POST: crear usuario ──────────────────────────────────────────────────
    case 'POST':
        $data = getRequestBody();

        // Resolver rol
        $rolId = 1; // fallback
        if (!empty($data['role'])) {
            $s = $db->prepare('SELECT id FROM roles WHERE LOWER(nombre) = ?');
            $s->execute([normalizeRoleForDB($data['role'])]);
            $row = $s->fetch();
            if ($row) $rolId = $row['id'];
        }

        $entityExternalId = !empty($data['entityExternalId']) ? (int)$data['entityExternalId'] : null;
        $externalRecordId = !empty($data['externalRecordId']) ? (int)$data['externalRecordId'] : null;
        $hasExternalColumn = columnExists($db, 'usuarios', 'entidad_externa_id');

        if ($hasExternalColumn) {
            $stmt = $db->prepare('
                INSERT INTO usuarios (nombre, matricula, correo, password, rol_id, entidad_externa_id, estado, fecha_creacion)
                VALUES (?,?,?,?,?,?,?,NOW())
            ');
            $stmt->execute([
                $data['name']         ?? '',
                $data['universityId'] ?? null,
                $data['email']        ?? '',
                password_hash($data['password'] ?? 'temporal123', PASSWORD_DEFAULT),
                $rolId,
                $entityExternalId,
                strtolower($data['status'] ?? 'Activo'),
            ]);
        } else {
            $stmt = $db->prepare('
                INSERT INTO usuarios (nombre, matricula, correo, password, rol_id, estado, fecha_creacion)
                VALUES (?,?,?,?,?,?,NOW())
            ');
            $stmt->execute([
                $data['name']         ?? '',
                $data['universityId'] ?? null,
                $data['email']        ?? '',
                password_hash($data['password'] ?? 'temporal123', PASSWORD_DEFAULT),
                $rolId,
                strtolower($data['status'] ?? 'Activo'),
            ]);
        }
        $newId = $db->lastInsertId();

        // Crear fila en tabla de perfil según rol
        $rolName = normalizeRoleForDB($data['role'] ?? '');
        if ($rolName === 'alumno') {
            $db->prepare('INSERT INTO alumnos (usuario_id, carrera, semestre, estado) VALUES (?,?,?,?)')
               ->execute([$newId, $data['department'] ?? '', null, 'activo']);
        } elseif ($rolName === 'profesor') {
            $db->prepare('INSERT INTO profesores (usuario_id, departamento, especialidad, estado) VALUES (?,?,?,?)')
               ->execute([$newId, $data['department'] ?? '', '', 'activo']);
        } elseif ($rolName === 'bibliotecario' || $rolName === 'colaborador') {
            $db->prepare('INSERT INTO colaboradores (usuario_id, area, puesto, estado) VALUES (?,?,?,?)')
               ->execute([$newId, $data['department'] ?? '', $rolName, 'activo']);
        }

        if ($externalRecordId) {
            $db->prepare("UPDATE registros_entidad_externa SET estado = 'importado', fecha_sincronizacion = NOW() WHERE id = ?")
               ->execute([$externalRecordId]);
        }

        jsonResponse(['success' => true, 'id' => $newId], 201);
        break;

    // ── PUT: actualizar usuario ──────────────────────────────────────────────
    case 'PUT':
        if (!$id) jsonResponse(['error' => 'ID requerido'], 400);
        $data = getRequestBody();

        if (($data['action'] ?? '') === 'suspend') {
            $reason = trim($data['reason'] ?? '');
            if ($reason === '') jsonResponse(['error' => 'El motivo de suspensión es requerido'], 400);

            $db->beginTransaction();
            try {
                $db->prepare("UPDATE usuarios SET estado = 'suspendido' WHERE id = ?")->execute([$id]);
                $db->prepare("
                    UPDATE suspensiones
                    SET fecha_fin = NOW(), estado = 'finalizada'
                    WHERE usuario_id = ?
                      AND fecha_fin IS NULL
                      AND LOWER(estado) IN ('activa','activo')
                ")->execute([$id]);
                $db->prepare("
                    INSERT INTO suspensiones (usuario_id, motivo, fecha_inicio, fecha_fin, estado)
                    VALUES (?, ?, NOW(), NULL, 'activa')
                ")->execute([$id, $reason]);
                $db->commit();
                jsonResponse(['success' => true]);
            } catch (Throwable $e) {
                if ($db->inTransaction()) $db->rollBack();
                throw $e;
            }
        }

        if (($data['action'] ?? '') === 'reactivate') {
            $db->beginTransaction();
            try {
                $db->prepare("UPDATE usuarios SET estado = 'activo' WHERE id = ?")->execute([$id]);
                $db->prepare("
                    UPDATE suspensiones
                    SET fecha_fin = NOW(), estado = 'finalizada'
                    WHERE usuario_id = ?
                      AND fecha_fin IS NULL
                      AND LOWER(estado) IN ('activa','activo')
                ")->execute([$id]);
                $db->commit();
                jsonResponse(['success' => true]);
            } catch (Throwable $e) {
                if ($db->inTransaction()) $db->rollBack();
                throw $e;
            }
        }

        $rolId = null;
        if (!empty($data['role'])) {
            $s = $db->prepare('SELECT id FROM roles WHERE LOWER(nombre) = ?');
            $s->execute([normalizeRoleForDB($data['role'])]);
            $row = $s->fetch();
            if ($row) $rolId = $row['id'];
        }

        $sql    = 'UPDATE usuarios SET nombre = ?, correo = ?, estado = ?';
        $params = [$data['name'] ?? '', $data['email'] ?? '', strtolower($data['status'] ?? 'Activo')];

        if (!empty($data['universityId'])) {
            $sql .= ', matricula = ?';
            $params[] = $data['universityId'];
        }
        if ($rolId) {
            $sql .= ', rol_id = ?';
            $params[] = $rolId;
        }
        if (!empty($data['password'])) {
            $sql .= ', password = ?';
            $params[] = password_hash($data['password'], PASSWORD_DEFAULT);
        }

        $sql .= ' WHERE id = ?';
        $params[] = $id;

        $db->prepare($sql)->execute($params);
        jsonResponse(['success' => true]);
        break;

    // ── DELETE: desactivar usuario ───────────────────────────────────────────
    case 'DELETE':
        if (!$id) jsonResponse(['error' => 'ID requerido'], 400);
        $db->prepare("UPDATE usuarios SET estado = 'inactivo' WHERE id = ?")->execute([$id]);
        jsonResponse(['success' => true]);
        break;

    default:
        jsonResponse(['error' => 'Método no permitido'], 405);
}
