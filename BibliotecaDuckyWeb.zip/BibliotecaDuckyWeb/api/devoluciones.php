<?php
require_once 'config.php';

$db     = getDB();
$method = $_SERVER['REQUEST_METHOD'];
$id     = $_GET['id'] ?? null; // prestamo_id

const FINE_PER_DAY = 5.00;

function calcFine(string $dueDate): float {
    $due   = new DateTime($dueDate);
    $today = new DateTime('today');
    $diff  = $today->diff($due);
    return $diff->invert ? $diff->days * FINE_PER_DAY : 0.0;
}

switch ($method) {

    // ── GET: devoluciones registradas ────────────────────────────────────────
    case 'GET':
        $stmt = $db->prepare("
            SELECT
                d.id,
                d.prestamo_id     AS loanId,
                l.titulo          AS bookTitle,
                u.nombre          AS userName,
                DATE_FORMAT(d.fecha_devolucion, '%d/%m/%Y') AS returnDate,
                d.condicion_libro AS condition,
                d.observaciones   AS notes
            FROM devoluciones d
            JOIN prestamos     p  ON d.prestamo_id = p.id
            JOIN copias_libros cl ON p.copia_id    = cl.id
            JOIN libros        l  ON cl.libro_id   = l.id
            JOIN usuarios      u  ON p.usuario_id  = u.id
            ORDER BY d.fecha_devolucion DESC
        ");
        $stmt->execute();
        jsonResponse($stmt->fetchAll());
        break;

    // ── POST: procesar devolución de un préstamo ─────────────────────────────
    case 'POST':
        $data      = getRequestBody();
        $loanId    = $data['loanId']    ?? $id;
        $condition = $data['condition'] ?? 'Bueno';
        $notes     = $data['notes']     ?? '';
        $recibidoPor = $data['librarianId'] ?? null;

        if (!$loanId) jsonResponse(['error' => 'loanId requerido'], 400);

        // Obtener préstamo
        $stmt = $db->prepare('SELECT * FROM prestamos WHERE id = ? AND estado NOT IN ("devuelto","cancelado")');
        $stmt->execute([$loanId]);
        $loan = $stmt->fetch();
        if (!$loan) jsonResponse(['error' => 'Préstamo no encontrado o ya cerrado'], 404);

        $fine = calcFine($loan['fecha_vencimiento']);

        $db->beginTransaction();
        try {
            // Registrar devolución
            $db->prepare('
                INSERT INTO devoluciones (prestamo_id, recibido_por, fecha_devolucion, condicion_libro, observaciones)
                VALUES (?, ?, NOW(), ?, ?)
            ')->execute([$loanId, $recibidoPor ?? $loan['bibliotecario_id'], $condition, $notes]);

            // Actualizar estado del préstamo
            $db->prepare("UPDATE prestamos SET estado = 'devuelto' WHERE id = ?")->execute([$loanId]);

            // Actualizar la copia según la condición registrada en la devolución.
            $conditionKey = strtolower(trim($condition));
            $copyState = 'disponible';
            if (in_array($conditionKey, ['dañado', 'danado', 'no utilizable'], true)) {
                $copyState = 'dañado';
            } elseif ($conditionKey === 'perdido') {
                $copyState = 'perdido';
            }
            $db->prepare("UPDATE copias_libros SET estado = ?, observaciones = ? WHERE id = ?")
               ->execute([$copyState, $notes, $loan['copia_id']]);

            // Generar multa si aplica
            $multaId = null;
            if ($fine > 0) {
                // Buscar tipo_multa "Retraso" o el primero disponible
                $tipoStmt = $db->prepare("SELECT id FROM tipos_multa WHERE nombre LIKE '%retraso%' OR nombre LIKE '%tardía%' LIMIT 1");
                $tipoStmt->execute();
                $tipo = $tipoStmt->fetch();
                $tipoId = $tipo ? $tipo['id'] : 1;

                $daysLate = (int)round($fine / FINE_PER_DAY);

                $db->prepare('
                    INSERT INTO multas (usuario_id, prestamo_id, tipo_id, monto, estado, fecha_generacion, dias_retraso, observaciones)
                    VALUES (?, ?, ?, ?, "pendiente", NOW(), ?, ?)
                ')->execute([
                    $loan['usuario_id'],
                    $loanId,
                    $tipoId,
                    $fine,
                    $daysLate,
                    'Devolución tardía - ' . $daysLate . ' días',
                ]);
                $multaId = $db->lastInsertId();
            }

            if (in_array($conditionKey, ['dañado', 'danado', 'no utilizable', 'perdido'], true)) {
                $bookStmt = $db->prepare('
                    SELECT l.precio_reposicion
                    FROM copias_libros cl
                    JOIN libros l ON l.id = cl.libro_id
                    WHERE cl.id = ?
                ');
                $bookStmt->execute([$loan['copia_id']]);
                $book = $bookStmt->fetch();
                $replacement = (float)($book['precio_reposicion'] ?? 0);

                $tipoNombre = $conditionKey === 'perdido' ? 'perdida' : 'daño';
                $tipoStmt = $db->prepare('SELECT id FROM tipos_multa WHERE LOWER(nombre) LIKE ? LIMIT 1');
                $tipoStmt->execute(['%' . $tipoNombre . '%']);
                $tipo = $tipoStmt->fetch();
                $tipoId = $tipo ? $tipo['id'] : 1;

                if ($replacement > 0) {
                    $db->prepare('
                        INSERT INTO multas (usuario_id, prestamo_id, tipo_id, monto, estado, fecha_generacion, dias_retraso, observaciones)
                        VALUES (?, ?, ?, ?, "pendiente", NOW(), NULL, ?)
                    ')->execute([
                        $loan['usuario_id'],
                        $loanId,
                        $tipoId,
                        $replacement,
                        'Multa por condición de devolución: ' . $condition,
                    ]);
                }
            }

            $db->commit();
            jsonResponse(['success' => true, 'fine' => $fine, 'replacementFine' => $replacement ?? 0, 'condition' => $condition, 'multaId' => $multaId]);
        } catch (Exception $e) {
            $db->rollBack();
            jsonResponse(['error' => 'Error al procesar devolución: ' . $e->getMessage()], 500);
        }
        break;

    default:
        jsonResponse(['error' => 'Método no permitido'], 405);
}
