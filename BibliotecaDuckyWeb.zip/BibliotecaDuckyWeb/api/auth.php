<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(['error' => 'Método no permitido'], 405);
}

$data     = getRequestBody();
$email    = trim($data['email']    ?? '');
$password = trim($data['password'] ?? '');

if (!$email || !$password) {
    jsonResponse(['error' => 'Email y contraseña son requeridos'], 400);
}

function normalizeRoleName(?string $role): string {
    $key = strtolower(trim($role ?? ''));
    return [
        'admin' => 'Administrador',
        'administrador' => 'Administrador',
        'bibliotecario' => 'Bibliotecario',
        'profesor' => 'Profesor',
        'alumno' => 'Alumno',
        'estudiante' => 'Alumno',
        'colaborador' => 'Colaborador',
    ][$key] ?? ucfirst($key);
}

function permissionKeysFromDB(array $permissionNames): array {
    $mapped = [];
    foreach ($permissionNames as $name) {
        switch (strtolower(trim($name))) {
            case 'crearusuarios':
            case 'crear_usuarios':
                $mapped[] = 'crearUsuarios';
                break;
            case 'suspenderusuarios':
            case 'suspender_usuarios':
                $mapped[] = 'suspenderUsuarios';
                break;
            case 'registrarprestamo':
            case 'registrar_prestamo':
            case 'realizar_prestamo':
                $mapped[] = 'registrarPrestamo';
                break;
            case 'registrardevolucion':
            case 'registrar_devolucion':
                $mapped[] = 'registrarDevolucion';
                break;
            case 'renovarprestamo':
            case 'renovar_prestamo':
                $mapped[] = 'renovarPrestamo';
                break;
            case 'buscarlibros':
            case 'buscar_libros':
                $mapped[] = 'buscarLibros';
                break;
            case 'consultarcatalogo':
            case 'consultar_catalogo':
            case 'ver_catalogo':
                $mapped[] = 'consultarCatalogo';
                $mapped[] = 'buscarLibros';
                break;
            case 'verreportes':
            case 'ver_reportes':
                $mapped[] = 'verReportes';
                break;
            case 'gestionar_usuarios':
                $mapped[] = 'crearUsuarios';
                $mapped[] = 'suspenderUsuarios';
                break;
            case 'gestionar_catalogo':
                $mapped[] = 'gestionarCatalogo';
                $mapped[] = 'buscarLibros';
                $mapped[] = 'consultarCatalogo';
                break;
        }
    }
    return array_values(array_unique($mapped));
}

$db   = getDB();
$stmt = $db->prepare('
    SELECT u.id, u.nombre AS name, u.matricula AS universityId, u.correo AS email,
           r.id AS roleId, r.nombre AS role, u.estado AS status, u.password
    FROM usuarios u
    LEFT JOIN roles r ON u.rol_id = r.id
    WHERE u.correo = ?
');
$stmt->execute([$email]);
$user = $stmt->fetch();

if (!$user || !password_verify($password, $user['password'])) {
    jsonResponse(['error' => 'Credenciales incorrectas'], 401);
}

if (strtolower($user['status'] ?? '') !== 'activo') {
    jsonResponse(['error' => 'Cuenta inactiva. Contacta a soporte.'], 403);
}

$permissionStmt = $db->prepare('
    SELECT p.nombre
    FROM permisos p
    INNER JOIN rol_permisos rp ON rp.permiso_id = p.id
    WHERE rp.rol_id = ?
');
$permissionStmt->execute([$user['roleId']]);
$permissionNames = array_column($permissionStmt->fetchAll(), 'nombre');

$user['role'] = normalizeRoleName($user['role']);
$user['status'] = ucfirst(strtolower($user['status']));
unset($user['password'], $user['roleId']);

jsonResponse([
    'success' => true,
    'user' => $user,
    'permissions' => permissionKeysFromDB($permissionNames),
]);
