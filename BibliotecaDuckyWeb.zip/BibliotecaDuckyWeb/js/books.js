document.addEventListener('DOMContentLoaded', async () => { await window.__dbReady;
    if (!requirePermission('gestionarCatalogo')) return;
    const tableBody = document.getElementById('booksTableBody');
    const mobileContainer = document.getElementById('booksMobileContainer');
    const searchInput = document.getElementById('searchInput');

    // Modals
    const deleteModal = document.getElementById('deleteModal');
    const bookModal = document.getElementById('bookModal');
    const bookForm = document.getElementById('bookForm');
    const authorInput = document.getElementById('author');
    const publisherInput = document.getElementById('publisher');
    const authorsList = document.getElementById('authorsList');
    const publishersList = document.getElementById('publishersList');
    const authorSuggestions = document.getElementById('authorSuggestions');
    const publisherSuggestions = document.getElementById('publisherSuggestions');
    const relatedEntitiesSection = document.getElementById('relatedEntitiesSection');
    const newAuthorFields = document.getElementById('newAuthorFields');
    const newPublisherFields = document.getElementById('newPublisherFields');
    const newAuthorHint = document.getElementById('newAuthorHint');
    const newPublisherHint = document.getElementById('newPublisherHint');

    let currentBooks = getBooks();
    let bookToDeleteId = null;
    let editingBookId = null;
    let knownAuthors = [];
    let knownPublishers = [];
    let authorRecords = [];
    let publisherRecords = [];

    const normalizeName = (value) => value.trim().replace(/\s+/g, ' ').toLowerCase();
    const escapeHtml = (value) => String(value)
        .replace(/&/g, '&amp;')
        .replace(/"/g, '&quot;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');

    async function loadKnownEntities() {
        if (USE_API) {
            try {
                const meta = await apiFetch('libros?meta=1');
                authorRecords = Array.isArray(meta.authors) ? meta.authors : [];
                publisherRecords = Array.isArray(meta.publishers) ? meta.publishers : [];
            } catch (error) {
                console.warn('[Books] No se pudieron cargar autores/editoriales:', error.message);
                authorRecords = [];
                publisherRecords = [];
            }
        }
        refreshKnownEntities();
    }

    function refreshKnownEntities() {
        const bookAuthors = currentBooks
            .flatMap(book => String(book.author || '').split(','))
            .map(name => name.trim())
            .filter(Boolean);
        const apiAuthors = authorRecords.map(author => author.name).filter(Boolean);
        knownAuthors = [...new Set([...apiAuthors, ...bookAuthors])].sort((a, b) => a.localeCompare(b));

        const bookPublishers = currentBooks
            .map(book => String(book.publisher || '').trim())
            .filter(Boolean);
        const apiPublishers = publisherRecords.map(publisher => publisher.name).filter(Boolean);
        knownPublishers = [...new Set([...apiPublishers, ...bookPublishers])].sort((a, b) => a.localeCompare(b));

        authorsList.innerHTML = knownAuthors.map(author => `<option value="${escapeHtml(author)}"></option>`).join('');
        publishersList.innerHTML = knownPublishers.map(publisher => `<option value="${escapeHtml(publisher)}"></option>`).join('');
    }

    function renderSuggestions(input, container, values, onPick) {
        const lastTerm = input === authorInput ? input.value.split(',').pop() || '' : input.value;
        const query = normalizeName(lastTerm);
        const matches = values
            .filter(value => !query || normalizeName(value).includes(query))
            .slice(0, 8);

        if (!matches.length || document.activeElement !== input) {
            container.classList.add('hidden');
            container.innerHTML = '';
            return;
        }

        container.innerHTML = matches.map(value => `
            <button type="button" class="w-full text-left px-4 py-2 text-sm text-slate-700 hover:bg-orange-50 hover:text-primary transition-colors" data-value="${escapeHtml(value)}">
                ${escapeHtml(value)}
            </button>
        `).join('');
        container.classList.remove('hidden');

        container.querySelectorAll('button').forEach(button => {
            button.addEventListener('mousedown', (event) => {
                event.preventDefault();
                onPick(button.dataset.value || '');
                container.classList.add('hidden');
            });
        });
    }

    function renderAuthorSuggestions() {
        renderSuggestions(authorInput, authorSuggestions, knownAuthors, (value) => {
            const parts = authorInput.value.split(',');
            if (parts.length > 1) {
                parts[parts.length - 1] = ` ${value}`;
                authorInput.value = parts.map(part => part.trim()).filter(Boolean).join(', ');
            } else {
                authorInput.value = value;
            }
            updateRelatedEntityFields();
        });
    }

    function renderPublisherSuggestions() {
        renderSuggestions(publisherInput, publisherSuggestions, knownPublishers, (value) => {
            publisherInput.value = value;
            updateRelatedEntityFields();
        });
    }

    function isNewAuthorValue(value) {
        const names = value.split(',').map(normalizeName).filter(Boolean);
        if (names.length === 0) return false;
        const known = new Set(knownAuthors.map(normalizeName));
        return names.some(name => !known.has(name));
    }

    function isNewPublisherValue(value) {
        const name = normalizeName(value);
        if (!name) return false;
        return !knownPublishers.map(normalizeName).includes(name);
    }

    function updateRelatedEntityFields() {
        const showAuthor = isNewAuthorValue(authorInput.value);
        const showPublisher = isNewPublisherValue(publisherInput.value);

        relatedEntitiesSection.classList.toggle('hidden', !showAuthor && !showPublisher);
        newAuthorFields.classList.toggle('hidden', !showAuthor);
        newPublisherFields.classList.toggle('hidden', !showPublisher);
        newAuthorHint.classList.toggle('hidden', !showAuthor);
        newPublisherHint.classList.toggle('hidden', !showPublisher);

        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    function setSavingState(isSaving) {
        const submitBtn = document.querySelector('button[type="submit"][form="bookForm"]');
        if (!submitBtn) return;
        submitBtn.disabled = isSaving;
        submitBtn.classList.toggle('opacity-70', isSaving);
        submitBtn.classList.toggle('cursor-not-allowed', isSaving);
        submitBtn.innerHTML = isSaving
            ? '<i data-lucide="loader-2" class="w-4 h-4 animate-spin"></i> Guardando...'
            : '<i data-lucide="save" class="w-4 h-4"></i> Guardar Libro';
        if (typeof lucide !== 'undefined') lucide.createIcons();
    }

    async function reloadBooksFromSource() {
        if (USE_API && typeof syncFromAPI === 'function') {
            await syncFromAPI();
        }
        currentBooks = getBooks();
        await loadKnownEntities();
        const query = searchInput.value.toLowerCase();
        const filtered = query
            ? currentBooks.filter(book =>
                book.title.toLowerCase().includes(query) ||
                String(book.author || '').toLowerCase().includes(query) ||
                String(book.isbn || '').includes(query)
            )
            : currentBooks;
        renderBooks(filtered);
    }

    function updateStats() {
        const total = currentBooks.length;
        const available = currentBooks.filter(b => Number(b.availableCopies || 0) > 0 && b.status === 'Disponible').length;
        const noCopies = currentBooks.filter(b => Number(b.totalCopies || 0) > 0 && Number(b.availableCopies || 0) === 0 && b.status !== 'Baja').length;
        const unavailable = currentBooks.filter(b => ['Baja', 'Dañado', 'Perdido'].includes(b.status)).length;

        document.getElementById('totalBooksCount').textContent = total;
        document.getElementById('perfectBooksCount').textContent = available;
        document.getElementById('minorDamageBooksCount').textContent = noCopies;
        document.getElementById('damagedBooksCount').textContent = unavailable;
    }

    function renderBooks(booksToRender) {
        tableBody.innerHTML = '';
        mobileContainer.innerHTML = '';
        updateStats();

        if (booksToRender.length === 0) {
            const emptyState = `
                <tr>
                  <td colspan="7" class="px-6 py-12 text-center">
                    <i data-lucide="book-open" class="w-12 h-12 text-slate-300 mx-auto mb-3"></i>
                    <p class="text-slate-600">No se encontraron libros</p>
                  </td>
                </tr>
            `;
            tableBody.innerHTML = emptyState;
            
            const emptyMobile = `
                <div class="bg-white rounded-lg shadow-md p-12 text-center">
                    <i data-lucide="book-open" class="w-12 h-12 text-slate-300 mx-auto mb-3"></i>
                    <p class="text-slate-600">No se encontraron libros</p>
                </div>
            `;
            mobileContainer.innerHTML = emptyMobile;
            lucide.createIcons();
            return;
        }

        booksToRender.forEach(book => {
            // Desktop Table Row
            const tr = document.createElement('tr');
            tr.className = 'hover:bg-slate-50 transition-colors';
            
            const conditionBadge = getConditionBadge(book.condition);
            const statusBadge = getStatusBadge(book.status);

            tr.innerHTML = `
                <td class="px-6 py-4">
                    <div class="w-12 h-16 bg-gradient-to-br from-[#F97316] to-[#EA580C] rounded flex items-center justify-center">
                        <i data-lucide="book-open" class="w-6 h-6 text-white opacity-50"></i>
                    </div>
                </td>
                <td class="px-6 py-4">
                    <div class="max-w-xs">
                        <p class="font-medium text-slate-800 line-clamp-2">${book.title}</p>
                        <p class="text-sm text-slate-500">${book.category}</p>
                    </div>
                </td>
                <td class="px-6 py-4">
                    <p class="text-slate-700 max-w-[200px] line-clamp-2">${book.author}</p>
                </td>
                <td class="px-6 py-4">
                    <p class="text-slate-700 font-mono text-sm">${book.isbn}</p>
                </td>
                <td class="px-6 py-4">
                    <span class="px-3 py-1 rounded-full text-xs font-medium ${statusBadge.class}">
                        ${book.status}
                    </span>
                    ${book.status === 'Disponible' ? `<p class="text-xs text-slate-500 mt-1">${book.availableCopies}/${book.totalCopies} disponibles</p>` : ''}
                </td>
                <td class="px-6 py-4">
                    <span class="px-3 py-1 rounded-full text-xs font-medium ${conditionBadge.class}">
                        ${book.condition}
                    </span>
                </td>
                <td class="px-6 py-4">
                    <div class="flex items-center gap-2">
                        <a href="book-details.html?id=${book.id}" class="p-2 text-slate-600 hover:text-primary hover:bg-slate-100 rounded-lg transition-colors" title="Ver Ficha">
                            <i data-lucide="eye" class="w-4 h-4"></i>
                        </a>
                        <button onclick="editBook('${book.id}')" class="p-2 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors" title="Editar">
                            <i data-lucide="edit" class="w-4 h-4"></i>
                        </button>
                        <button onclick="confirmDelete('${book.id}')" class="p-2 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Eliminar">
                            <i data-lucide="trash-2" class="w-4 h-4"></i>
                        </button>
                    </div>
                </td>
            `;
            tableBody.appendChild(tr);

            // Mobile Card
            const mobileCard = document.createElement('div');
            mobileCard.className = 'bg-white rounded-lg shadow-sm p-4 border border-slate-200';
            mobileCard.innerHTML = `
                <div class="flex gap-4">
                    <div class="w-16 h-24 bg-gradient-to-br from-[#F97316] to-[#EA580C] rounded flex items-center justify-center flex-shrink-0">
                        <i data-lucide="book-open" class="w-8 h-8 text-white opacity-50"></i>
                    </div>
                    <div class="flex-1 min-w-0">
                        <h3 class="font-semibold text-slate-800 mb-1 line-clamp-2">${book.title}</h3>
                        <p class="text-sm text-slate-600 mb-2 line-clamp-1">${book.author}</p>
                        <div class="flex flex-wrap gap-2 mb-2">
                            <span class="px-2 py-1 rounded-full text-xs font-medium ${statusBadge.class}">${book.status}</span>
                            <span class="px-2 py-1 rounded-full text-xs font-medium ${conditionBadge.class}">${book.condition}</span>
                        </div>
                        ${book.status === 'Disponible' ? `<p class="text-xs text-slate-500">${book.availableCopies}/${book.totalCopies} disponibles</p>` : ''}
                    </div>
                </div>
                <div class="flex gap-2 mt-4 pt-4 border-t border-slate-200">
                    <a href="book-details.html?id=${book.id}" class="flex-1 px-3 py-2 text-sm bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors flex items-center justify-center gap-2">
                        <i data-lucide="eye" class="w-4 h-4"></i> Ver
                    </a>
                    <button onclick="editBook('${book.id}')" class="flex-1 px-3 py-2 text-sm bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors flex items-center justify-center gap-2">
                        <i data-lucide="edit" class="w-4 h-4"></i> Editar
                    </button>
                    <button onclick="confirmDelete('${book.id}')" class="flex-1 px-3 py-2 text-sm bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors flex items-center justify-center gap-2">
                        <i data-lucide="trash-2" class="w-4 h-4"></i> Eliminar
                    </button>
                </div>
            `;
            mobileContainer.appendChild(mobileCard);
        });

        lucide.createIcons();
    }

    function getConditionBadge(condition) {
        const styles = {
            "Perfecto": "bg-green-100 text-green-800",
            "Daño Menor": "bg-yellow-100 text-yellow-800",
            "Dañado": "bg-orange-100 text-orange-800",
            "No Utilizable": "bg-red-100 text-red-800",
        };
        return { class: styles[condition] || "bg-slate-100 text-slate-800" };
    }

    function getStatusBadge(status) {
        const styles = {
            "Disponible": "bg-blue-100 text-blue-800",
            "Prestado": "bg-purple-100 text-purple-800",
            "Dañado": "bg-red-100 text-red-800",
            "Perdido": "bg-gray-100 text-gray-800",
        };
        return { class: styles[status] || "bg-slate-100 text-slate-800" };
    }

    await loadKnownEntities();

    authorInput.addEventListener('input', () => {
        updateRelatedEntityFields();
        renderAuthorSuggestions();
    });
    authorInput.addEventListener('focus', renderAuthorSuggestions);
    authorInput.addEventListener('blur', () => {
        setTimeout(() => authorSuggestions.classList.add('hidden'), 150);
    });

    publisherInput.addEventListener('input', () => {
        updateRelatedEntityFields();
        renderPublisherSuggestions();
    });
    publisherInput.addEventListener('focus', renderPublisherSuggestions);
    publisherInput.addEventListener('blur', () => {
        setTimeout(() => publisherSuggestions.classList.add('hidden'), 150);
    });

    // Initial render
    renderBooks(currentBooks);

    // Search functionality
    searchInput.addEventListener('input', (e) => {
        const query = e.target.value.toLowerCase();
        const filtered = currentBooks.filter(book => 
            book.title.toLowerCase().includes(query) ||
            book.author.toLowerCase().includes(query) ||
            book.isbn.includes(query)
        );
        renderBooks(filtered);
    });

    // Delete functionality
    window.confirmDelete = (id) => {
        bookToDeleteId = id;
        deleteModal.classList.remove('hidden');
    };

    document.getElementById('cancelDeleteBtn').addEventListener('click', () => {
        bookToDeleteId = null;
        deleteModal.classList.add('hidden');
    });

    document.getElementById('confirmDeleteBtn').addEventListener('click', async () => {
        if (bookToDeleteId) {
            try {
                if (USE_API) {
                    await apiFetch(`libros?id=${bookToDeleteId}`, 'DELETE');
                    await reloadBooksFromSource();
                } else {
                    currentBooks = currentBooks.filter(b => b.id !== bookToDeleteId);
                    saveBooks(currentBooks);
                    await loadKnownEntities();
                    renderBooks(currentBooks);
                }
                deleteModal.classList.add('hidden');
                showToast("Libro eliminado", "Se ha eliminado del catálogo exitosamente.", "success");
                bookToDeleteId = null;
            } catch (error) {
                showToast("No se pudo eliminar", error.message, "error");
            }
        }
    });

    // Add / Edit Modal functionality
    window.openAddModal = () => {
        editingBookId = null;
        document.getElementById('modalTitle').textContent = 'Agregar Nuevo Libro';
        bookForm.reset();
        document.getElementById('language').value = 'Español';
        document.getElementById('totalCopies').value = 1;
        document.getElementById('availableCopies').value = 1;
        document.getElementById('status').value = 'Disponible';
        document.getElementById('condition').value = 'Perfecto';
        updateRelatedEntityFields();
        bookModal.classList.remove('hidden');
    };

    window.editBook = (id) => {
        editingBookId = id;
        document.getElementById('modalTitle').textContent = 'Editar Libro';
        const book = currentBooks.find(b => String(b.id) === String(id));
        
        if (book) {
            document.getElementById('title').value = book.title;
            document.getElementById('author').value = book.author;
            document.getElementById('isbn').value = book.isbn;
            document.getElementById('publisher').value = book.publisher || '';
            document.getElementById('year').value = book.year;
            document.getElementById('category').value = book.category;
            document.getElementById('pages').value = book.pages;
            document.getElementById('language').value = book.language;
            document.getElementById('description').value = book.description || '';
            document.getElementById('totalCopies').value = book.totalCopies;
            document.getElementById('availableCopies').value = book.availableCopies;
            document.getElementById('status').value = book.status;
            document.getElementById('condition').value = book.condition;
            document.getElementById('location').value = book.location || '';
            document.getElementById('replacementPrice').value = book.replacementPrice || 0;
            document.getElementById('authorNationality').value = '';
            document.getElementById('publisherCountry').value = '';
            document.getElementById('publisherContact').value = '';
            updateRelatedEntityFields();
            
            bookModal.classList.remove('hidden');
        }
    };

    document.getElementById('closeBookModalBtn').addEventListener('click', () => {
        bookModal.classList.add('hidden');
    });

    document.getElementById('cancelBookModalBtn').addEventListener('click', () => {
        bookModal.classList.add('hidden');
    });

    bookForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        setSavingState(true);
        
        const newBook = {
            id: editingBookId || generateId(),
            title: document.getElementById('title').value,
            author: document.getElementById('author').value,
            isbn: document.getElementById('isbn').value,
            publisher: document.getElementById('publisher').value,
            year: parseInt(document.getElementById('year').value),
            category: document.getElementById('category').value,
            pages: parseInt(document.getElementById('pages').value) || 0,
            language: document.getElementById('language').value,
            description: document.getElementById('description').value,
            totalCopies: parseInt(document.getElementById('totalCopies').value) || 1,
            availableCopies: parseInt(document.getElementById('availableCopies').value) || 1,
            status: document.getElementById('status').value,
            condition: document.getElementById('condition').value,
            location: document.getElementById('location').value,
            replacementPrice: parseFloat(document.getElementById('replacementPrice').value) || 0,
            authorNationality: document.getElementById('authorNationality').value.trim(),
            publisherCountry: document.getElementById('publisherCountry').value.trim(),
            publisherContact: document.getElementById('publisherContact').value.trim(),
        };

        try {
            if (USE_API) {
                if (editingBookId) {
                    await apiFetch(`libros?id=${editingBookId}`, 'PUT', newBook);
                    showToast("Libro actualizado", "Los cambios han sido guardados.", "success");
                } else {
                    await apiFetch('libros', 'POST', newBook);
                    showToast("Libro agregado", "Ha sido añadido al catálogo.", "success");
                }
                await reloadBooksFromSource();
            } else {
                if (editingBookId) {
                    const index = currentBooks.findIndex(b => String(b.id) === String(editingBookId));
                    currentBooks[index] = newBook;
                    showToast("Libro actualizado", "Los cambios han sido guardados.", "success");
                } else {
                    currentBooks.unshift(newBook);
                    showToast("Libro agregado", "Ha sido añadido al catálogo.", "success");
                }

                saveBooks(currentBooks);
                await loadKnownEntities();
                renderBooks(currentBooks);
            }
            bookModal.classList.add('hidden');
        } catch (error) {
            showToast("No se pudo guardar", error.message, "error");
        } finally {
            setSavingState(false);
        }
    });
});
