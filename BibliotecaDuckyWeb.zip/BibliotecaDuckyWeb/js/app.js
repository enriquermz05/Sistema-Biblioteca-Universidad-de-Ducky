// Sidebar Toggle Logic
document.addEventListener('DOMContentLoaded', () => {
    if (typeof applyGlobalAuthUI === 'function') applyGlobalAuthUI();
    // Render sidebar icons immediately, before any async page JS runs
    if (typeof lucide !== 'undefined') lucide.createIcons();

    const mobileMenuBtn = document.getElementById('mobileMenuBtn');
    const closeSidebarBtn = document.getElementById('closeSidebarBtn');
    const sidebar = document.getElementById('sidebar');
    const mobileOverlay = document.getElementById('mobileOverlay');

    function toggleSidebar() {
        if (sidebar.classList.contains('-translate-x-full')) {
            // Open sidebar
            sidebar.classList.remove('-translate-x-full');
            mobileOverlay.classList.remove('hidden');
        } else {
            // Close sidebar
            sidebar.classList.add('-translate-x-full');
            mobileOverlay.classList.add('hidden');
        }
    }

    if (mobileMenuBtn) {
        mobileMenuBtn.addEventListener('click', toggleSidebar);
    }

    if (closeSidebarBtn) {
        closeSidebarBtn.addEventListener('click', toggleSidebar);
    }

    if (mobileOverlay) {
        mobileOverlay.addEventListener('click', toggleSidebar);
    }
});

// ============================================================
//  CHATBOT GLOBAL BIBLIOTECA DUCKY
//  Se muestra en todas las pantallas internas.
//  No se carga en index.html porque esa pantalla no incluye app.js.
// ============================================================
(function () {
    const CHAT_HISTORY_KEY = 'ducky_chatbot_history';
    const CHAT_OPEN_KEY = 'ducky_chatbot_open';

    function isLoginPage() {
        const path = window.location.pathname.toLowerCase();
        return path.endsWith('/index.html') || path.endsWith('/biblioteca/') || path.endsWith('/biblioteca');
    }

    function normalizeText(text) {
        return String(text || '')
            .toLowerCase()
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .replace(/[^a-z0-9ñáéíóúü\s]/gi, ' ')
            .replace(/\s+/g, ' ')
            .trim();
    }

    function getArrayFromStorage(key) {
        try {
            const data = JSON.parse(localStorage.getItem(key) || '[]');
            return Array.isArray(data) ? data : [];
        } catch (_) {
            return [];
        }
    }

    function safeGetBooks() {
        if (typeof getBooks === 'function') return getBooks();
        return getArrayFromStorage('ducky_books');
    }

    function safeGetUsers() {
        if (typeof getUsers === 'function') return getUsers();
        return getArrayFromStorage('ducky_users');
    }

    function safeGetLoans() {
        if (typeof getLoans === 'function') return getLoans();
        return getArrayFromStorage('ducky_loans');
    }

    function getCurrentSessionUserSafe() {
        try {
            if (typeof getCurrentUser === 'function') return getCurrentUser();
        } catch (_) {}
        return null;
    }

    function getFineFromLoan(loan) {
        const storedFine = Number(loan.fineAmount || loan.multa || loan.fine || 0);
        if (Number.isFinite(storedFine) && storedFine > 0) return storedFine;
        if (loan.dueDate && typeof calcFine === 'function') return calcFine(loan.dueDate);
        return 0;
    }

    function findCurrentUserRecord() {
        const sessionUser = getCurrentSessionUserSafe();
        if (!sessionUser) return null;
        const users = safeGetUsers();
        const sessionId = String(sessionUser.id || sessionUser.userId || '').trim();
        const sessionEmail = normalizeText(sessionUser.email || '');
        const sessionName = normalizeText(sessionUser.name || '');
        const sessionUniId = normalizeText(sessionUser.universityId || sessionUser.id_universitario || '');

        return users.find(user => {
            const userId = String(user.id || user.userId || '').trim();
            const userEmail = normalizeText(user.email || '');
            const userName = normalizeText(user.name || '');
            const userUniId = normalizeText(user.universityId || user.id_universitario || '');
            return (sessionId && userId && sessionId === userId)
                || (sessionEmail && userEmail && sessionEmail === userEmail)
                || (sessionUniId && userUniId && sessionUniId === userUniId)
                || (sessionName && userName && sessionName === userName);
        }) || sessionUser;
    }

    function getLoansForUser(user) {
        if (!user) return [];
        const loans = safeGetLoans();
        const userId = String(user.id || user.userId || '').trim();
        const email = normalizeText(user.email || '');
        const name = normalizeText(user.name || '');

        return loans.filter(loan => {
            const loanUserId = String(loan.userId || loan.usuario_id || '').trim();
            const loanEmail = normalizeText(loan.userEmail || loan.email || '');
            const loanName = normalizeText(loan.userName || loan.name || '');
            const status = normalizeText(loan.status || loan.estado || '');
            const activeStatus = !status || ['activo', 'vencido', 'prestado'].includes(status);
            return activeStatus && (
                (userId && loanUserId && userId === loanUserId)
                || (email && loanEmail && email === loanEmail)
                || (name && loanName && name === loanName)
            );
        });
    }

    function saveHistory(messages) {
        try {
            localStorage.setItem(CHAT_HISTORY_KEY, JSON.stringify(messages.slice(-30)));
        } catch (_) {}
    }

    function loadHistory() {
        try {
            const messages = JSON.parse(localStorage.getItem(CHAT_HISTORY_KEY) || '[]');
            return Array.isArray(messages) ? messages.slice(-30) : [];
        } catch (_) {
            return [];
        }
    }

    function injectChatbotStyles() {
        if (document.getElementById('ducky-chatbot-styles')) return;
        const style = document.createElement('style');
        style.id = 'ducky-chatbot-styles';
        style.textContent = `
            #duckyChatbotRoot, #duckyChatbotRoot * { box-sizing: border-box; }
            #duckyChatbotRoot { font-family: Inter, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; }
            .ducky-chatbot-button {
                position: fixed;
                right: 24px;
                bottom: 24px;
                width: 64px;
                height: 64px;
                border-radius: 999px;
                border: 0;
                color: #fff;
                background: linear-gradient(135deg, #F97316, #EA580C);
                display: flex;
                align-items: center;
                justify-content: center;
                box-shadow: 0 18px 35px rgba(249, 115, 22, .35), 0 8px 16px rgba(15, 23, 42, .18);
                cursor: pointer;
                z-index: 9999;
                transition: transform .2s ease, box-shadow .2s ease;
            }
            .ducky-chatbot-button:hover { transform: translateY(-2px) scale(1.03); box-shadow: 0 22px 42px rgba(249, 115, 22, .42), 0 10px 20px rgba(15, 23, 42, .2); }
            .ducky-chatbot-badge {
                position: absolute;
                top: 8px;
                right: 8px;
                width: 12px;
                height: 12px;
                border-radius: 999px;
                background: #22C55E;
                border: 2px solid #fff;
            }
            .ducky-chatbot-panel {
                position: fixed;
                right: 24px;
                bottom: 96px;
                width: min(390px, calc(100vw - 32px));
                height: min(620px, calc(100vh - 120px));
                background: #fff;
                border: 1px solid rgba(226, 232, 240, .95);
                border-radius: 24px;
                box-shadow: 0 30px 80px rgba(15, 23, 42, .22);
                z-index: 9998;
                overflow: hidden;
                display: flex;
                flex-direction: column;
                opacity: 0;
                transform: translateY(18px) scale(.96);
                pointer-events: none;
                transition: opacity .22s ease, transform .22s ease;
            }
            .ducky-chatbot-panel.ducky-chatbot-open { opacity: 1; transform: translateY(0) scale(1); pointer-events: auto; }
            .ducky-chatbot-header {
                background: linear-gradient(135deg, #1E293B, #334155);
                color: #fff;
                padding: 16px;
                display: flex;
                align-items: center;
                gap: 12px;
            }
            .ducky-chatbot-avatar {
                width: 42px;
                height: 42px;
                border-radius: 16px;
                display: flex;
                align-items: center;
                justify-content: center;
                background: rgba(249, 115, 22, .18);
                color: #FDBA74;
                flex-shrink: 0;
            }
            .ducky-chatbot-title { font-size: 15px; font-weight: 800; margin: 0; line-height: 1.15; }
            .ducky-chatbot-subtitle { font-size: 12px; color: #CBD5E1; margin-top: 2px; }
            .ducky-chatbot-close {
                margin-left: auto;
                width: 34px;
                height: 34px;
                border-radius: 999px;
                border: 0;
                color: #fff;
                background: rgba(255,255,255,.12);
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
            }
            .ducky-chatbot-close:hover { background: rgba(255,255,255,.2); }
            .ducky-chatbot-messages {
                flex: 1;
                overflow-y: auto;
                padding: 16px;
                background: linear-gradient(180deg, #F8FAFC, #FFFFFF);
            }
            .ducky-chat-message { display: flex; gap: 8px; margin-bottom: 12px; animation: duckyMessageIn .18s ease; }
            .ducky-chat-message.user { justify-content: flex-end; }
            .ducky-chat-bubble {
                max-width: 82%;
                padding: 10px 12px;
                border-radius: 16px;
                font-size: 13px;
                line-height: 1.45;
                white-space: pre-line;
                word-wrap: break-word;
            }
            .ducky-chat-message.bot .ducky-chat-bubble { background: #fff; color: #334155; border: 1px solid #E2E8F0; border-top-left-radius: 6px; }
            .ducky-chat-message.user .ducky-chat-bubble { background: #F97316; color: #fff; border-top-right-radius: 6px; }
            .ducky-chatbot-quick {
                display: flex;
                gap: 8px;
                overflow-x: auto;
                padding: 10px 14px;
                border-top: 1px solid #E2E8F0;
                background: #fff;
            }
            .ducky-chatbot-quick button {
                white-space: nowrap;
                border: 1px solid #FED7AA;
                color: #9A3412;
                background: #FFF7ED;
                padding: 7px 10px;
                border-radius: 999px;
                font-size: 12px;
                font-weight: 700;
                cursor: pointer;
            }
            .ducky-chatbot-quick button:hover { background: #FFEDD5; }
            .ducky-chatbot-input-area {
                display: flex;
                align-items: center;
                gap: 10px;
                padding: 12px;
                border-top: 1px solid #E2E8F0;
                background: #fff;
            }
            .ducky-chatbot-input {
                flex: 1;
                min-width: 0;
                border: 1px solid #CBD5E1;
                border-radius: 14px;
                padding: 11px 12px;
                font-size: 13px;
                outline: none;
            }
            .ducky-chatbot-input:focus { border-color: #F97316; box-shadow: 0 0 0 3px rgba(249,115,22,.16); }
            .ducky-chatbot-send {
                width: 42px;
                height: 42px;
                border: 0;
                border-radius: 14px;
                background: #F97316;
                color: #fff;
                display: flex;
                align-items: center;
                justify-content: center;
                cursor: pointer;
                flex-shrink: 0;
            }
            .ducky-chatbot-send:hover { background: #EA580C; }
            .ducky-typing { display: inline-flex; gap: 4px; align-items: center; }
            .ducky-typing span { width: 6px; height: 6px; border-radius: 999px; background: #94A3B8; animation: duckyTyping 1s infinite ease-in-out; }
            .ducky-typing span:nth-child(2) { animation-delay: .15s; }
            .ducky-typing span:nth-child(3) { animation-delay: .3s; }
            @keyframes duckyTyping { 0%, 80%, 100% { transform: translateY(0); opacity: .45; } 40% { transform: translateY(-4px); opacity: 1; } }
            @keyframes duckyMessageIn { from { opacity: 0; transform: translateY(6px); } to { opacity: 1; transform: translateY(0); } }
            @media (max-width: 640px) {
                .ducky-chatbot-button { right: 16px; bottom: 16px; width: 58px; height: 58px; }
                .ducky-chatbot-panel { right: 12px; bottom: 84px; width: calc(100vw - 24px); height: min(620px, calc(100vh - 98px)); border-radius: 20px; }
            }
        `;
        document.head.appendChild(style);
    }

    function createChatbotDOM() {
        const root = document.createElement('div');
        root.id = 'duckyChatbotRoot';
        root.innerHTML = `
            <section id="duckyChatbotPanel" class="ducky-chatbot-panel" role="dialog" aria-label="Chatbot Biblioteca Ducky" aria-live="polite">
                <header class="ducky-chatbot-header">
                    <div class="ducky-chatbot-avatar"><i data-lucide="bot" class="w-6 h-6"></i></div>
                    <div>
                        <p class="ducky-chatbot-title">Asistente Biblioteca Ducky</p>
                        <p class="ducky-chatbot-subtitle">Disponible para catálogo, préstamos y multas</p>
                    </div>
                    <button id="duckyChatbotClose" class="ducky-chatbot-close" type="button" aria-label="Cerrar chatbot">
                        <i data-lucide="x" class="w-5 h-5"></i>
                    </button>
                </header>
                <div id="duckyChatbotMessages" class="ducky-chatbot-messages"></div>
                <div class="ducky-chatbot-quick" aria-label="Preguntas rápidas">
                    <button type="button" data-ducky-prompt="¿Qué puedes hacer?">¿Qué puedes hacer?</button>
                    <button type="button" data-ducky-prompt="Reglas de préstamo">Reglas</button>
                    <button type="button" data-ducky-prompt="Buscar libro">Buscar libro</button>
                    <button type="button" data-ducky-prompt="Mis préstamos y multas">Mis préstamos</button>
                </div>
                <form id="duckyChatbotForm" class="ducky-chatbot-input-area">
                    <input id="duckyChatbotInput" class="ducky-chatbot-input" type="text" autocomplete="off" placeholder="Pregunta por libros, multas o renovaciones..." />
                    <button class="ducky-chatbot-send" type="submit" aria-label="Enviar mensaje">
                        <i data-lucide="send" class="w-5 h-5"></i>
                    </button>
                </form>
            </section>
            <button id="duckyChatbotButton" class="ducky-chatbot-button" type="button" aria-label="Abrir chatbot">
                <i data-lucide="message-circle" class="w-7 h-7"></i>
                <span class="ducky-chatbot-badge" aria-hidden="true"></span>
            </button>
        `;
        document.body.appendChild(root);
        if (typeof lucide !== 'undefined') lucide.createIcons();
        return root;
    }

    function formatBookLine(book, index) {
        const available = Number(book.availableCopies ?? book.copias_disponibles ?? 0);
        const total = Number(book.totalCopies ?? book.copias_totales ?? 0);
        const title = book.title || book.titulo || 'Sin título';
        const author = book.author || book.autor || 'Autor no registrado';
        const status = book.status || book.estado || (available > 0 ? 'Disponible' : 'No disponible');
        const location = book.location || book.ubicacion || 'Ubicación no registrada';
        const copiesText = total > 0 ? `${available}/${total} copias` : `${available} copias disponibles`;
        return `${index + 1}. ${title}\n   Autor: ${author}\n   Estado: ${status} | ${copiesText}\n   Ubicación: ${location}`;
    }

    function splitWords(text) {
        return normalizeText(text)
            .split(' ')
            .map(word => word.trim())
            .filter(word => word.length > 1);
    }

    function hasAny(normalizedMessage, keywords) {
        return keywords.some(keyword => normalizedMessage.includes(normalizeText(keyword)));
    }

    function hasRegex(normalizedMessage, patterns) {
        return patterns.some(pattern => pattern.test(normalizedMessage));
    }

    function levenshteinDistance(a, b) {
        a = normalizeText(a);
        b = normalizeText(b);
        if (a === b) return 0;
        if (!a.length) return b.length;
        if (!b.length) return a.length;

        const dp = Array.from({ length: a.length + 1 }, () => new Array(b.length + 1).fill(0));
        for (let i = 0; i <= a.length; i++) dp[i][0] = i;
        for (let j = 0; j <= b.length; j++) dp[0][j] = j;

        for (let i = 1; i <= a.length; i++) {
            for (let j = 1; j <= b.length; j++) {
                const cost = a[i - 1] === b[j - 1] ? 0 : 1;
                dp[i][j] = Math.min(
                    dp[i - 1][j] + 1,
                    dp[i][j - 1] + 1,
                    dp[i - 1][j - 1] + cost
                );
            }
        }
        return dp[a.length][b.length];
    }

    function fuzzyWordMatch(term, fieldWords) {
        if (term.length < 4) return fieldWords.includes(term);
        return fieldWords.some(word => {
            if (word.includes(term) || term.includes(word)) return true;
            const maxDistance = term.length <= 5 ? 1 : 2;
            return levenshteinDistance(term, word) <= maxDistance;
        });
    }

    function expandQueryAliases(text) {
        let expanded = ` ${normalizeText(text)} `;
        const aliases = [
            { pattern: /\bia\b/g, value: ' inteligencia artificial ' },
            { pattern: /\bai\b/g, value: ' inteligencia artificial ' },
            { pattern: /\bbd\b/g, value: ' bases de datos ' },
            { pattern: /\bdb\b/g, value: ' bases de datos ' },
            { pattern: /\bprogramacion\b/g, value: ' codigo limpio software ' },
            { pattern: /\balgoritmo\b/g, value: ' algoritmos ' },
            { pattern: /\bmate\b/g, value: ' matematicas ' },
            { pattern: /\bclean code\b/g, value: ' codigo limpio ' },
            { pattern: /\bdatabase\b/g, value: ' bases de datos ' },
            { pattern: /\bdatabases\b/g, value: ' bases de datos ' },
            { pattern: /\bartificial intelligence\b/g, value: ' inteligencia artificial ' },
            { pattern: /\bintroduction to algorithms\b/g, value: ' introduccion algoritmos ' }
        ];
        aliases.forEach(alias => {
            expanded = expanded.replace(alias.pattern, alias.value);
        });
        return expanded.replace(/\s+/g, ' ').trim();
    }

    function cleanBookQuery(rawQuery) {
        const normalized = expandQueryAliases(rawQuery);
        const stopWords = new Set([
            'a', 'al', 'algo', 'algun', 'alguna', 'algunas', 'algunos', 'alli', 'ahi', 'autor', 'autores',
            'biblioteca', 'buscar', 'busca', 'buscame', 'catalogo', 'catálogo', 'clave', 'como', 'con',
            'cual', 'cuales', 'cuantos', 'de', 'del', 'dentro', 'disponible', 'disponibles', 'disponibilidad',
            'donde', 'ducky', 'editorial', 'el', 'ella', 'ellos', 'en', 'encuentra', 'encontrar', 'esta',
            'estan', 'existe', 'externo', 'hay', 'isbn', 'la', 'las', 'libro', 'libros', 'lo', 'los', 'me',
            'mi', 'mis', 'necesito', 'para', 'por', 'prestamo', 'prestar', 'puedo', 'que', 'quiero', 'se',
            'si', 'sobre', 'tema', 'temas', 'teneis', 'tener', 'tengo', 'tienen', 'tienes', 'titulo', 'título',
            'un', 'una', 'unas', 'unos', 'ubicacion', 'ubicar', 'ver'
        ]);

        const terms = normalized
            .split(' ')
            .map(term => term.trim())
            .filter(term => term.length > 1 && !stopWords.has(term));

        return Array.from(new Set(terms)).join(' ');
    }

    function searchBooks(rawQuery) {
        const books = safeGetBooks();
        const query = cleanBookQuery(rawQuery);
        const rawExpanded = expandQueryAliases(rawQuery);

        if (query.length < 2 && rawExpanded.length < 2) return { query, results: [] };

        const terms = splitWords(query.length >= 2 ? query : rawExpanded);
        const results = books.map(book => {
            const fields = [
                book.title || book.titulo,
                book.author || book.autor,
                book.category || book.categoria,
                book.isbn,
                book.publisher || book.editorial,
                book.id,
                book.description || book.descripcion,
                book.location || book.ubicacion,
                book.status || book.estado,
            ].map(normalizeText);
            const joined = fields.join(' ');
            const fieldWords = splitWords(joined);
            let score = 0;

            if (query && fields[0]?.includes(query)) score += 12;
            if (query && fields[1]?.includes(query)) score += 8;
            if (query && fields[2]?.includes(query)) score += 5;
            if (query && fields[3]?.includes(query)) score += 6;
            if (query && fields[4]?.includes(query)) score += 5;
            if (query && joined.includes(query)) score += 4;

            terms.forEach(term => {
                if (fields[0]?.includes(term)) score += 4;
                else if (fields[1]?.includes(term)) score += 3;
                else if (fields[2]?.includes(term)) score += 2;
                else if (fields[3]?.includes(term)) score += 3;
                else if (fields[4]?.includes(term)) score += 2;
                else if (fuzzyWordMatch(term, fieldWords)) score += 1;
            });

            // Pequeño bono si varias palabras coinciden, para evitar resultados débiles.
            const matchedTerms = terms.filter(term => fuzzyWordMatch(term, fieldWords)).length;
            if (terms.length > 1 && matchedTerms >= Math.min(2, terms.length)) score += matchedTerms;

            return { book, score };
        })
        .filter(item => item.score > 0)
        .sort((a, b) => b.score - a.score)
        .slice(0, 5)
        .map(item => item.book);

        return { query, results };
    }

    function buildBookResponse(message) {
        const { query, results } = searchBooks(message);
        if (query.length < 2) {
            return 'Claro. Escribe el título, autor, tema, clave, ISBN o editorial del libro que quieres buscar.\n\nEjemplos:\n“¿Tienen Código Limpio?”\n“¿Dónde está el libro de IA?”\n“Libros de matemáticas”';
        }
        if (!results.length) {
            return `No encontré resultados para “${query}”. Puedes intentar con el título, autor, tema, clave, ISBN o editorial.`;
        }
        return `Encontré ${results.length} resultado(s) para “${query}”:\n\n${results.map(formatBookLine).join('\n\n')}`;
    }

    function buildRulesResponse() {
        return 'Reglas principales de préstamo:\n\nAlumnos:\n• Máximo 2 libros prestados actualmente.\n• No deben tener multas pendientes.\n• No deben tener préstamos vencidos.\n• Vigencia: 5 días hábiles.\n• Máximo 2 renovaciones.\n\nMaestros:\n• Vigencia: 10 días hábiles.\n• Máximo 3 renovaciones.\n• Multa diaria: $10 MXN.\n\nLos libros solo pueden salir si están disponibles y marcados como préstamo externo.';
    }

    function buildLoanAuthorizationResponse() {
        return 'Para autorizar un préstamo se revisa lo siguiente:\n\n• El alumno no debe tener multas.\n• No debe tener préstamos vencidos.\n• No debe tener más de 2 libros prestados actualmente.\n• El libro debe estar disponible.\n• El libro debe estar catalogado como préstamo externo.\n\nSi algo de eso no se cumple, el sistema debe bloquear o marcar el préstamo como no autorizado.';
    }

    function buildReturnResponse() {
        return 'Para devolver un libro, el bibliotecario debe registrar la devolución y revisar la fecha de vencimiento.\n\n• Si el préstamo todavía está vigente, se recibe el libro normalmente.\n• Si está vencido, se genera una multa de $10 MXN por cada día de retraso.\n• Después de registrar la devolución, el ejemplar vuelve a quedar disponible en el catálogo.';
    }

    function buildSuspensionResponse() {
        return 'En época de exámenes, la biblioteca genera una lista de alumnos deudores de libros o multas y da aviso a Servicios Escolares.\n\nLa idea es que esos alumnos regularicen sus adeudos antes de poder presentar exámenes.';
    }

    function parseSpanishNumber(text) {
        const normalized = normalizeText(text);
        const numberMatch = normalized.match(/\b(\d+)\b/);
        if (numberMatch) return Number(numberMatch[1]);

        const numbers = {
            uno: 1, un: 1, una: 1, dos: 2, tres: 3, cuatro: 4, cinco: 5, seis: 6, siete: 7, ocho: 8, nueve: 9, diez: 10,
            once: 11, doce: 12, trece: 13, catorce: 14, quince: 15, dieciseis: 16, dieciséis: 16, diecisiete: 17, dieciocho: 18, diecinueve: 19, veinte: 20,
            veintiuno: 21, veintidos: 22, veintidós: 22, veintitres: 23, veintitrés: 23, veinticuatro: 24, veinticinco: 25, veintiseis: 26, veintiséis: 26,
            veintisiete: 27, veintiocho: 28, veintinueve: 29, treinta: 30
        };

        const found = normalized.split(' ').find(word => Object.prototype.hasOwnProperty.call(numbers, word));
        return found ? numbers[found] : null;
    }

    function buildFineResponse(message) {
        const normalized = normalizeText(message);
        const daysMatch = normalized.match(/(\d+)\s*(dia|dias|días|dia\(s\)|dias\(s\)|retraso|atraso)/);
        const parsedDays = daysMatch ? Number(daysMatch[1]) : (hasAny(normalized, ['dia', 'dias', 'retraso', 'atraso', 'tarde']) ? parseSpanishNumber(normalized) : null);
        if (parsedDays && parsedDays > 0) {
            const days = parsedDays;
            return `La multa por ${days} día(s) de retraso sería de $${days * 10} MXN.\n\nCálculo: ${days} × $10 MXN por día.`;
        }

        const user = findCurrentUserRecord();
        const loans = getLoansForUser(user);
        const userFine = Number(user?.fines || user?.multas_total || 0);
        const loanFine = loans.reduce((sum, loan) => sum + getFineFromLoan(loan), 0);
        const totalFine = Math.max(userFine, loanFine);
        const overdueLoans = loans.filter(loan => normalizeText(loan.status || loan.estado).includes('vencido') || getFineFromLoan(loan) > 0);

        if (user && (loans.length || totalFine > 0)) {
            return `Estado de multas de ${user.name || 'tu usuario'}:\n\n• Multa total detectada: $${totalFine.toFixed(2)} MXN.\n• Préstamos activos/vencidos: ${loans.length}.\n• Préstamos vencidos detectados: ${overdueLoans.length}.\n\nRecuerda: la multa diaria es de $10 MXN por día de retraso. Si ya pagaste en Tesorería, repórtalo con el bibliotecario para actualizar el sistema.`;
        }

        return 'La multa diaria por retraso es de $10 MXN.\n\nSi el libro se pierde, se cobra el valor presente del libro, es decir, el precio de última compra en dólares al tipo de cambio actual.';
    }

    function buildLoanStatusResponse() {
        const user = findCurrentUserRecord();
        if (!user) {
            return 'Para revisar tus préstamos necesito que hayas iniciado sesión con un usuario válido.';
        }

        const loans = getLoansForUser(user);
        const activeLoans = Number(user.activeLoans || user.prestamos_activos || loans.length || 0);
        const fines = Number(user.fines || user.multas_total || loans.reduce((sum, loan) => sum + getFineFromLoan(loan), 0));
        const role = normalizeText(user.role || user.rol || 'alumno');
        const isTeacher = role.includes('profesor') || role.includes('maestro');
        const maxLoansText = isTeacher ? 'No se especifica límite de ejemplares en el documento para maestros.' : 'Máximo permitido para alumnos: 2 libros.';

        const loanLines = loans.slice(0, 4).map((loan, index) => {
            const title = loan.bookTitle || loan.title || loan.titulo || 'Libro sin título';
            const due = loan.dueDate || loan.fecha_limite || loan.fecha_vencimiento || 'Sin fecha registrada';
            const status = loan.status || loan.estado || 'Activo';
            return `${index + 1}. ${title}\n   Vence: ${due} | Estado: ${status}`;
        }).join('\n\n');

        return `Estado de ${user.name || 'tu usuario'}:\n\n• Rol: ${user.role || user.rol || 'Usuario'}\n• Préstamos activos: ${activeLoans}\n• Multas: $${fines.toFixed(2)} MXN\n• ${maxLoansText}\n\n${loanLines ? `Préstamos detectados:\n${loanLines}` : 'No encontré préstamos activos registrados para este usuario.'}`;
    }

    function buildRenewalResponse() {
        return 'Renovación de préstamo:\n\n• Alumnos: máximo 2 renovaciones.\n• Maestros: máximo 3 renovaciones.\n• La renovación depende de las políticas de la biblioteca y del estado del préstamo.\n\nPuedes ir al módulo “Préstamos” o “Devoluciones” si tu rol tiene permiso para gestionar la renovación.';
    }

    function buildLostBookResponse() {
        return 'Si el alumno reporta un libro como perdido, el administrador genera una multa, avisa a Servicios Escolares y Tesorería.\n\nEl costo de reposición es el valor presente del libro: precio de última compra en dólares al tipo de cambio actual.';
    }

    function buildHelpResponse() {
        return 'Puedo ayudarte aunque no escribas la pregunta exacta. Entiendo preguntas sobre:\n\n• Buscar libros: “¿Tienen Código Limpio?”, “libros de IA”, “dónde está matemáticas”.\n• Disponibilidad y ubicación de libros.\n• Reglas de préstamo: “¿cuántos libros puedo sacar?”, “¿por cuántos días?”.\n• Renovaciones: “quiero más tiempo”, “¿puedo extender el préstamo?”.\n• Multas: “me atrasé 4 días”, “¿cuánto debo pagar?”.\n• Tus préstamos y multas: “qué libros tengo”, “mi cuenta”, “qué debo”.\n• Libros perdidos: “perdí un libro”, “costo de reposición”.';
    }

    function getIntentScores(message) {
        const normalized = normalizeText(message);
        const scores = {
            help: 0,
            books: 0,
            rules: 0,
            authorization: 0,
            renewal: 0,
            lost: 0,
            fine: 0,
            loanStatus: 0,
            returnBook: 0,
            suspension: 0,
            schedule: 0,
        };

        if (hasRegex(normalized, [/\b(hola|buenas|hey|que onda|ayuda|opciones|menu)\b/])) scores.help += 3;
        if (hasAny(normalized, ['que puedes hacer', 'como me ayudas', 'para que sirves', 'que sabes hacer', 'ayudar'])) scores.help += 4;

        if (hasAny(normalized, ['libro', 'libros', 'catalogo', 'catálogo', 'titulo', 'título', 'autor', 'tema', 'isbn', 'editorial', 'disponible', 'disponibilidad', 'ubicacion', 'ubicación', 'estante', 'seccion', 'sección'])) scores.books += 3;
        if (hasAny(normalized, ['buscar', 'busca', 'buscame', 'encuentra', 'encontrar', 'tienen', 'tienes', 'hay', 'existe', 'donde esta', 'donde encuentro', 'quiero un libro', 'necesito un libro'])) scores.books += 4;
        if (searchBooks(message).results.length > 0) scores.books += 5;

        if (hasAny(normalized, ['regla', 'reglas', 'politica', 'política', 'politicas', 'políticas', 'requisito', 'requisitos', 'condiciones', 'prestamo externo', 'préstamo externo'])) scores.rules += 5;
        if (hasAny(normalized, ['cuantos libros', 'cuántos libros', 'cuanto tiempo', 'cuánto tiempo', 'cuantos dias', 'cuántos días', 'dias habiles', 'días hábiles', 'duracion', 'vigencia', 'puedo sacar', 'puedo pedir', 'puedo llevar', 'me puedo llevar', 'alumno', 'maestro', 'profesor'])) scores.rules += 4;

        if (hasAny(normalized, ['autorizar', 'autorizacion', 'autorización', 'permitir prestamo', 'permitir préstamo', 'bloquear prestamo', 'bloquear préstamo', 'aprobar prestamo', 'aprobar préstamo', 'puede sacar', 'puedo sacar'])) scores.authorization += 4;
        if (hasAny(normalized, ['si debo multa', 'con multa', 'prestamo vencido', 'préstamo vencido', 'mas de dos', 'más de dos'])) scores.authorization += 3;

        if (hasAny(normalized, ['renovar', 'renovacion', 'renovación', 'renovaciones', 'extender', 'ampliar', 'alargar', 'prorroga', 'prórroga', 'mas tiempo', 'más tiempo', 'otra vez el libro'])) scores.renewal += 6;

        if (hasAny(normalized, ['perdido', 'perdi', 'perdí', 'pierde', 'perder', 'extravio', 'extravío', 'robaron', 'robado', 'dañado', 'danado', 'roto', 'reposicion', 'reposición'])) scores.lost += 6;

        if (hasAny(normalized, ['multa', 'multas', 'deuda', 'deudas', 'adeudo', 'adeudos', 'deudor', 'debo', 'pagar', 'pago', 'tesoreria', 'tesorería', 'retraso', 'atraso', 'tarde', 'vencido', 'vencidos', 'me atrase', 'me atrasé', 'me pase', 'me pasé', 'cuanto pago', 'cuánto pago', 'no entregue', 'no entregué', 'no entrego', 'no devuelvo', 'si no devuelvo', 'si no entrego', 'devolver tarde'])) scores.fine += 6;
        if (/\b\d+\s*(dia|dias|días)\b/.test(normalized) && hasAny(normalized, ['multa', 'retraso', 'atraso', 'tarde', 'vencido', 'vencidos'])) scores.fine += 4;

        if (hasAny(normalized, ['mis prestamos', 'mis préstamos', 'mi prestamo', 'mi préstamo', 'mis libros', 'mi cuenta', 'mi estado', 'que libros tengo', 'qué libros tengo', 'tengo prestado', 'tengo prestamos', 'tengo préstamos', 'cuando vence', 'cuándo vence', 'fecha de vencimiento', 'que debo', 'qué debo'])) scores.loanStatus += 7;
        if ((hasAny(normalized, ['mi', 'mis', 'yo', 'tengo']) && hasAny(normalized, ['prestamo', 'préstamo', 'prestamos', 'préstamos', 'libros', 'multa', 'multas', 'debo', 'vencimiento']))) scores.loanStatus += 4;

        if (hasAny(normalized, ['devolver', 'devolucion', 'devolución', 'regresar libro', 'regreso el libro', 'entregar libro', 'recibir libro', 'retornar libro']) && !hasAny(normalized, ['tarde', 'retraso', 'atraso', 'multa'])) scores.returnBook += 5;

        if (hasAny(normalized, ['suspendido', 'suspendidos', 'suspension', 'suspensión', 'examenes', 'exámenes', 'lista de deudores', 'alumnos deudores'])) scores.suspension += 5;

        if (hasAny(normalized, ['horario', 'abre', 'cierran', 'cierra', 'hora', 'atencion', 'atención'])) scores.schedule += 5;

        return scores;
    }

    function shouldSearchBooks(message) {
        const scores = getIntentScores(message);
        return scores.books >= 4;
    }

    function bestIntent(scores) {
        return Object.entries(scores).sort((a, b) => b[1] - a[1])[0];
    }

    async function getBotResponse(message) {
        if (window.__dbReady && typeof window.__dbReady.then === 'function') {
            try { await window.__dbReady; } catch (_) {}
        }

        const normalized = normalizeText(message);
        if (!normalized) return 'Escribe una pregunta para ayudarte.';

        const scores = getIntentScores(message);
        const [intent, score] = bestIntent(scores);

        // Si menciona un libro real, priorizamos la búsqueda aunque la frase no sea exacta.
        if (scores.books >= 5) return buildBookResponse(message);
        if (intent === 'loanStatus' && score >= 4) return buildLoanStatusResponse();
        if (intent === 'fine' && score >= 4) return buildFineResponse(message);
        if (intent === 'returnBook' && score >= 4) return buildReturnResponse();
        if (intent === 'suspension' && score >= 4) return buildSuspensionResponse();
        if (intent === 'renewal' && score >= 4) return buildRenewalResponse();
        if (intent === 'lost' && score >= 4) return buildLostBookResponse();
        if (intent === 'authorization' && score >= 4) return buildLoanAuthorizationResponse();
        if (intent === 'rules' && score >= 4) return buildRulesResponse();
        if (intent === 'schedule' && score >= 4) return 'El horario de la biblioteca no está configurado en este sistema. Puedes agregarlo después para que el chatbot también lo responda.';
        if (intent === 'help' && score >= 3) return buildHelpResponse();

        // Último intento: buscar libros solo con el texto escrito, útil para frases como “Código Limpio”.
        const bookResults = searchBooks(message);
        if (bookResults.results.length > 0) return buildBookResponse(message);

        return 'No encontré una respuesta exacta, pero puedes preguntarme con lenguaje normal sobre catálogo, disponibilidad, reglas de préstamo, multas, renovaciones, libros perdidos o tus préstamos.\n\nEjemplos:\n“¿Tienen Código Limpio?”\n“¿Cuántos días puedo tener un libro?”\n“Me atrasé 3 días, ¿cuánto pago?”\n“¿Puedo renovar mi préstamo?”';
    }

    function appendMessage(container, role, text, shouldSave = true) {
        const row = document.createElement('div');
        row.className = `ducky-chat-message ${role}`;
        const bubble = document.createElement('div');
        bubble.className = 'ducky-chat-bubble';
        bubble.textContent = text;
        row.appendChild(bubble);
        container.appendChild(row);
        container.scrollTop = container.scrollHeight;

        if (shouldSave && role !== 'typing') {
            const current = loadHistory();
            current.push({ role, text, date: new Date().toISOString() });
            saveHistory(current);
        }
        return row;
    }

    function appendTyping(container) {
        const row = document.createElement('div');
        row.className = 'ducky-chat-message bot';
        row.id = 'duckyChatbotTyping';
        const bubble = document.createElement('div');
        bubble.className = 'ducky-chat-bubble';
        bubble.innerHTML = '<span class="ducky-typing"><span></span><span></span><span></span></span>';
        row.appendChild(bubble);
        container.appendChild(row);
        container.scrollTop = container.scrollHeight;
        return row;
    }

    function initializeDuckyChatbot() {
        if (isLoginPage() || document.getElementById('duckyChatbotRoot')) return;
        if (typeof getCurrentUser === 'function' && !getCurrentUser()) return;

        injectChatbotStyles();
        createChatbotDOM();

        const panel = document.getElementById('duckyChatbotPanel');
        const button = document.getElementById('duckyChatbotButton');
        const closeButton = document.getElementById('duckyChatbotClose');
        const form = document.getElementById('duckyChatbotForm');
        const input = document.getElementById('duckyChatbotInput');
        const messages = document.getElementById('duckyChatbotMessages');

        const history = loadHistory();
        if (history.length) {
            history.forEach(msg => appendMessage(messages, msg.role, msg.text, false));
        } else {
            const user = getCurrentSessionUserSafe();
            appendMessage(messages, 'bot', `Hola${user?.name ? `, ${user.name}` : ''}. Soy el asistente de Biblioteca Ducky. Pregúntame por libros, préstamos, renovaciones o multas.`, true);
        }

        function setOpen(open) {
            panel.classList.toggle('ducky-chatbot-open', open);
            localStorage.setItem(CHAT_OPEN_KEY, open ? '1' : '0');
            if (open) setTimeout(() => input.focus(), 120);
        }

        button.addEventListener('click', () => setOpen(!panel.classList.contains('ducky-chatbot-open')));
        closeButton.addEventListener('click', () => setOpen(false));

        form.addEventListener('submit', async event => {
            event.preventDefault();
            const text = input.value.trim();
            if (!text) return;
            appendMessage(messages, 'user', text, true);
            input.value = '';
            const typing = appendTyping(messages);
            const response = await getBotResponse(text);
            typing.remove();
            appendMessage(messages, 'bot', response, true);
        });

        document.querySelectorAll('[data-ducky-prompt]').forEach(btn => {
            btn.addEventListener('click', () => {
                const prompt = btn.getAttribute('data-ducky-prompt') || '';
                input.value = prompt;
                form.requestSubmit();
            });
        });

        setOpen(localStorage.getItem(CHAT_OPEN_KEY) === '1');
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initializeDuckyChatbot);
    } else {
        initializeDuckyChatbot();
    }
})();
