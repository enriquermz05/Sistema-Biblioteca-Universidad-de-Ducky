document.addEventListener('DOMContentLoaded', async () => { await window.__dbReady;
    if (!requirePermission('consultarCatalogo')) return;
    // Parse URL parameters
    const urlParams = new URLSearchParams(window.location.search);
    const bookId = urlParams.get('id');
    const books = getBooks();
    
    const book = books.find(b => String(b.id) === String(bookId));
    
    const errorContainer = document.getElementById('errorContainer');
    const detailContainer = document.getElementById('detailContainer');
    
    // If book is not found
    if (!book) {
        detailContainer.classList.add('hidden');
        errorContainer.classList.remove('hidden');
        lucide.createIcons();
        return;
    }
    
    // Fill data
    document.getElementById('b-title').textContent = book.title;
    document.getElementById('b-author').textContent = book.author;
    document.getElementById('b-category').textContent = book.category;
    document.getElementById('b-language-badge').textContent = book.language;
    document.getElementById('b-description').textContent = book.description || 'Sin descripción detallada.';
    
    document.getElementById('b-isbn').textContent = book.isbn;
    document.getElementById('b-year').textContent = book.year;
    document.getElementById('b-publisher').textContent = book.publisher || 'N/A';
    document.getElementById('b-pages').textContent = book.pages || 'N/A';
    document.getElementById('b-language').textContent = book.language;
    document.getElementById('b-location').textContent = book.location || 'N/A';
    document.getElementById('b-replacementPrice').textContent = '$' + (book.replacementPrice || 0).toFixed(2) + ' MXN';
    
    // Status and Conditions
    const currentStatusEl = document.getElementById('b-current-status');
    const conditionEl = document.getElementById('b-condition');
    const inventoryTextEl = document.getElementById('b-inventory-text');
    
    currentStatusEl.textContent = book.status;
    conditionEl.textContent = book.condition;
    
    // Apply styling based on status
    const stylesStatus = {
        "Disponible": "bg-green-100 text-green-800",
        "Prestado": "bg-yellow-100 text-yellow-800",
        "Dañado": "bg-red-100 text-red-800",
        "Perdido": "bg-gray-100 text-gray-800",
    };
    currentStatusEl.className = `inline-block px-3 py-1 rounded-full text-xs font-medium mt-1 ${stylesStatus[book.status] || "bg-slate-100 text-slate-800"}`;
    
    // Icon for status
    const statusIconEl = document.getElementById('b-status-icon');
    let sIcon = "alert-circle";
    let sColor = "text-slate-600";
    if(book.status === "Disponible") { sIcon = "check-circle"; sColor = "text-green-600"; }
    else if(book.status === "Prestado") { sIcon = "clock"; sColor = "text-yellow-600"; }
    else if(book.status === "Dañado") { sIcon = "alert-circle"; sColor = "text-red-600"; }
    statusIconEl.setAttribute("data-lucide", sIcon);
    statusIconEl.className = `w-6 h-6 ${sColor}`;

    // Condition 
    const stylesCond = {
        "Perfecto": "bg-green-100 text-green-800",
        "Daño Menor": "bg-yellow-100 text-yellow-800",
        "Dañado": "bg-orange-100 text-orange-800",
        "No Utilizable": "bg-red-100 text-red-800",
    };
    conditionEl.className = `inline-block px-3 py-1 rounded-full text-xs font-medium ${stylesCond[book.condition] || "bg-slate-100 text-slate-800"}`;

    if (book.status === 'Disponible') {
        const p = document.createElement('p');
        p.className = 'text-sm text-slate-600';
        p.innerHTML = `<span class="font-medium text-slate-800">${book.availableCopies}</span> de <span class="font-medium text-slate-800">${book.totalCopies}</span> copias disponibles`;
        inventoryTextEl.appendChild(p);
    }

    // Action Buttons
    const requestBtn = document.getElementById('requestLoanBtn');
    const reserveBtn = document.getElementById('reserveBtn');

    if (book.status === "Disponible" && book.availableCopies > 0) {
        requestBtn.className = "flex-1 px-6 py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2 text-sm md:text-base bg-primary text-white hover:bg-primaryHover";
        requestBtn.removeAttribute('disabled');
        requestBtn.addEventListener('click', () => {
            showToast("Solicitud enviada", `Se ha solicitado el préstamo de "${book.title}".`, "success");
            // Here we could deduct inventory and simulate a loan
            book.availableCopies -= 1;
            if(book.availableCopies === 0) {
                book.status = "Prestado";
            }
            saveBooks(books);
            setTimeout(() => window.location.reload(), 1500);
        });
    } else {
        requestBtn.className = "flex-1 px-6 py-3 rounded-lg font-medium flex items-center justify-center gap-2 text-sm md:text-base bg-slate-200 text-slate-400 cursor-not-allowed";
        requestBtn.setAttribute('disabled', 'true');
        requestBtn.addEventListener('click', () => {
             // Disabled logic
        });
    }

    if (book.status === "Prestado") {
        reserveBtn.className = "flex-1 px-6 py-3 rounded-lg font-medium transition-colors flex items-center justify-center gap-2 text-sm md:text-base bg-[#1E293B] text-white hover:bg-[#334155]";
        reserveBtn.removeAttribute('disabled');
        reserveBtn.addEventListener('click', () => {
            showToast("Reserva realizada", `Te notificaremos cuando "${book.title}" esté disponible.`, "success");
        });
    } else {
        reserveBtn.className = "flex-1 px-6 py-3 rounded-lg font-medium flex items-center justify-center gap-2 text-sm md:text-base bg-slate-200 text-slate-400 cursor-not-allowed";
        reserveBtn.setAttribute('disabled', 'true');
    }

    // Related Books
    const relatedContainer = document.getElementById('relatedBooksContainer');
    const relatedWrapper = document.getElementById('relatedBooksWrapper');
    
    const related = books.filter(b => b.category === book.category && b.id !== book.id && b.status === "Disponible").slice(0, 3);
    
    if (related.length > 0) {
        related.forEach(r => {
            const card = document.createElement('a');
            card.href = `book-details.html?id=${r.id}`;
            card.className = "bg-white rounded-lg shadow-sm border border-slate-200 hover:shadow-md transition-shadow overflow-hidden group hover:-translate-y-1 block";
            card.innerHTML = `
                <div class="h-32 md:h-40 bg-gradient-to-br from-[#F97316] to-[#EA580C] flex items-center justify-center">
                    <i data-lucide="book-open" class="w-12 h-12 md:w-16 md:h-16 text-white opacity-50"></i>
                </div>
                <div class="p-4">
                    <h3 class="text-sm md:text-base font-semibold text-slate-800 mb-2 line-clamp-2 group-hover:text-primary transition-colors">${r.title}</h3>
                    <div class="flex items-center gap-2 text-xs md:text-sm text-slate-600 mb-2">
                        <i data-lucide="user" class="w-4 h-4 flex-shrink-0"></i>
                        <span class="line-clamp-1">${r.author}</span>
                    </div>
                    <span class="inline-block px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">${r.status}</span>
                </div>
            `;
            relatedContainer.appendChild(card);
        });
    } else {
        relatedWrapper.classList.add('hidden');
    }

    // Dynamic Back Button Logic
    const backText = document.getElementById('backText');
    const referrer = document.referrer.toLowerCase();
    
    if (referrer.includes('catalogo.html')) {
        backText.textContent = 'Volver al Catálogo';
        window.goBack = () => window.location.href = 'catalogo.html';
    } else if (referrer.includes('dashboard.html')) {
        backText.textContent = 'Volver al Tablero';
        window.goBack = () => window.location.href = 'dashboard.html';
    } else {
        backText.textContent = 'Volver a Libros';
        window.goBack = () => window.location.href = 'books.html';
    }

    lucide.createIcons();
});
