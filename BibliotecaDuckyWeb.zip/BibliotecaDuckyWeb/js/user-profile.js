document.addEventListener('DOMContentLoaded', async () => { await window.__dbReady;
    if (!requireLogin()) return;
    const canSuspendUsers = hasPermission('suspenderUsuarios');
    const urlParams = new URLSearchParams(window.location.search);
    const userId = urlParams.get('id');
    const allUsers = getUsers();
    
    const user = allUsers.find(u => String(u.id) === String(userId));
    
    const errorContainer = document.getElementById('errorContainer');
    const profileContainer = document.getElementById('profileContainer');
    
    if (!user) {
        profileContainer.classList.add('hidden');
        errorContainer.classList.remove('hidden');
        lucide.createIcons();
        return;
    }
    
    // Header & Summary
    document.getElementById('u-name').textContent = user.name;
    document.getElementById('u-universityId').textContent = user.universityId;
    
    const activeFinesContainer = document.getElementById('u-active-fines-container');
    const activeFinesCount = user.bookFines ? user.bookFines.filter(f => f.status === "Pendiente").length : 0;
    
    if (activeFinesCount > 0) {
        document.getElementById('u-active-fines-count').textContent = activeFinesCount;
        const totalFines = user.bookFines
            .filter(f => f.status === "Pendiente")
            .reduce((sum, f) => sum + (f.replacementPrice || 0), 0);
        document.getElementById('u-active-fines-total').textContent = `$${totalFines.toFixed(2)} MXN`;
    } else {
        activeFinesContainer.classList.add('hidden');
    }
    
    // Action Buttons
    const suspendBtnContainer = document.getElementById('suspendBtnContainer');
    if (canSuspendUsers && user.status !== "Suspendido") {
        suspendBtnContainer.innerHTML = `
            <button onclick="openSuspendModal()" class="w-full sm:w-auto px-4 py-2 border border-red-600 text-red-600 bg-white hover:bg-red-50 rounded-lg transition-colors flex items-center justify-center gap-2 text-sm font-medium">
                <i data-lucide="ban" class="w-4 h-4"></i> Suspender Usuario
            </button>
        `;
    }
    
    // User Info Details
    document.getElementById('u-role').textContent = user.role;
    document.getElementById('u-role').className = `inline-flex px-3 py-1 border text-sm font-medium rounded-full ${getRoleColor(user.role)}`;
    
    document.getElementById('u-status').textContent = user.status;
    document.getElementById('u-status').className = `inline-flex px-3 py-1 border text-sm font-medium rounded-full ${getStatusColor(user.status)}`;
    
    document.getElementById('u-email').textContent = user.email;
    document.getElementById('u-phone').textContent = user.phone || 'N/A';
    
    const deptContainer = document.getElementById('u-department-container');
    if (user.department) {
        document.getElementById('u-department').textContent = user.department;
    } else {
        deptContainer.classList.add('hidden');
    }
    
    document.getElementById('u-joinedDate').textContent = user.joinedDate || 'N/A';
    document.getElementById('u-activeLoans').textContent = user.activeLoans || 0;
    
    const finesEl = document.getElementById('u-finesTotal');
    finesEl.textContent = `$${(user.fines || 0).toFixed(2)}`;
    if(user.fines > 0) {
        finesEl.classList.remove('text-green-600');
        finesEl.classList.add('text-red-600');
    }
    
    // Active Loans Table
    const loansBody = document.getElementById('loansTableBody');
    const loansObj = user.loans || [];
    if (loansObj.length > 0) {
        loansObj.forEach(loan => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="px-6 py-4 font-medium text-[#111827]">${loan.bookTitle}</td>
                <td class="px-6 py-4 text-slate-600">${loan.borrowDate}</td>
                <td class="px-6 py-4 text-slate-600">${loan.dueDate}</td>
                <td class="px-6 py-4">
                    <span class="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium border ${getLoanStatusColor(loan.status)}">
                        ${loan.status}
                    </span>
                </td>
            `;
            loansBody.appendChild(tr);
        });
    } else {
        loansBody.innerHTML = `<tr><td colspan="4" class="px-6 py-8 text-center text-slate-500">Sin préstamos activos</td></tr>`;
    }
    
    // Book Fines Table
    const bookFinesBody = document.getElementById('bookFinesTableBody');
    const bookFinesObj = user.bookFines || [];
    if (bookFinesObj.length > 0) {
        bookFinesObj.forEach(fine => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="px-6 py-4 font-medium text-[#111827]">${fine.bookTitle}</td>
                <td class="px-6 py-4 text-slate-600">${fine.reason}</td>
                <td class="px-6 py-4 font-semibold text-red-600">$${(fine.replacementPrice || 0).toFixed(2)} MXN</td>
                <td class="px-6 py-4">
                    <span class="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium border ${getFineStatusColor(fine.status)}">
                        ${fine.status}
                    </span>
                </td>
            `;
            bookFinesBody.appendChild(tr);
        });
    } else {
        bookFinesBody.innerHTML = `<tr><td colspan="4" class="px-6 py-8 text-center text-slate-500">Sin multas por libros</td></tr>`;
    }
    
    // General Fine History Table
    const historyBody = document.getElementById('historyTableBody');
    const historyObj = user.fineHistory || [];
    if (historyObj.length > 0) {
        historyObj.forEach(fine => {
            const tr = document.createElement('tr');
            tr.innerHTML = `
                <td class="px-6 py-4 text-slate-600">${fine.date}</td>
                <td class="px-6 py-4 text-[#111827]">${fine.reason}</td>
                <td class="px-6 py-4 font-semibold text-red-600">$${(fine.amount || 0).toFixed(2)}</td>
                <td class="px-6 py-4">
                    <span class="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium border ${getFineStatusColor(fine.status)}">
                        ${fine.status}
                    </span>
                </td>
            `;
            historyBody.appendChild(tr);
        });
    } else {
        historyBody.innerHTML = `<tr><td colspan="4" class="px-6 py-8 text-center text-slate-500">Sin historial de multas</td></tr>`;
    }
    
    // Suspend Modal Logic
    const suspendModal = document.getElementById('suspendModal');
    
    window.openSuspendModal = () => {
        if (!canSuspendUsers) return;
        document.getElementById('sm-name').textContent = user.name;
        document.getElementById('sm-universityId').textContent = user.universityId;
        document.getElementById('sm-fines').textContent = `$${(user.fines || 0).toFixed(2)}`;
        suspendModal.classList.remove('hidden');
    };
    
    window.closeSuspendModal = () => {
        suspendModal.classList.add('hidden');
    };
    
    document.getElementById('confirmSuspendBtn').addEventListener('click', () => {
        if (!canSuspendUsers) return;
        user.status = "Suspendido";
        saveUsers(allUsers);
        showToast("Usuario suspendido exitosamente", `La cuenta de ${user.name} ha sido suspendida.`, "success");
        closeSuspendModal();
        setTimeout(() => window.location.reload(), 1500);
    });

    lucide.createIcons();

    // Helpers
    function getRoleColor(role) {
        switch (role) {
            case "Administrador": return "bg-purple-100 text-purple-700 border-purple-300";
            case "Bibliotecario": return "bg-blue-100 text-blue-700 border-blue-300";
            case "Profesor": return "bg-orange-100 text-orange-700 border-orange-300";
            case "Alumno": return "bg-emerald-100 text-emerald-700 border-emerald-300";
            case "Colaborador": return "bg-amber-100 text-amber-700 border-amber-300";
            default: return "bg-slate-100 text-slate-700 border-slate-300";
        }
    }

    function getStatusColor(status) {
        switch (status) {
            case "Activo": return "bg-green-100 text-green-700 border-green-300";
            case "Suspendido": return "bg-red-100 text-red-700 border-red-300";
            case "Inactivo": return "bg-slate-100 text-slate-700 border-slate-300";
            default: return "bg-slate-100 text-slate-700 border-slate-300";
        }
    }

    function getLoanStatusColor(status) {
        switch (status) {
            case "Activo": return "bg-blue-100 text-blue-700 border-blue-300";
            case "Vencido": return "bg-red-100 text-red-700 border-red-300";
            case "Devuelto": return "bg-green-100 text-green-700 border-green-300";
            default: return "bg-slate-100 text-slate-700 border-slate-300";
        }
    }

    function getFineStatusColor(status) {
        switch (status) {
            case "Pendiente": return "bg-red-100 text-red-700 border-red-300";
            case "Pagado": return "bg-green-100 text-green-700 border-green-300";
            default: return "bg-slate-100 text-slate-700 border-slate-300";
        }
    }
});
