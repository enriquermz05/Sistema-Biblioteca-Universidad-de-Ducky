document.addEventListener('DOMContentLoaded', async () => { await window.__dbReady;
    if (!requirePermission('registrarDevolucion')) return;
    const searchInput      = document.getElementById('searchInput');
    const loansList        = document.getElementById('loansList');
    const emptyState       = document.getElementById('emptyState');
    const activeLoansBadge = document.getElementById('activeLoansBadge');
    const returnedTableBody = document.getElementById('returnedTableBody');
    const returnModal      = document.getElementById('returnModal');

    let allLoans = getLoans();
    let pendingLoans = [];
    let selectedLoan = null;

    // ─── Obtener préstamos pendientes (activos o vencidos) ───────────
    function getPendingLoans() {
        return allLoans.filter(l => l.status !== 'Devuelto');
    }

    // ─── Render lista de préstamos pendientes ────────────────────────
    function renderPendingLoans(loans) {
        loansList.innerHTML = '';
        activeLoansBadge.textContent = loans.length;

        if (loans.length === 0) {
            emptyState.classList.remove('hidden');
            return;
        }
        emptyState.classList.add('hidden');

        loans.forEach(loan => {
            const fine     = calcFine(loan.dueDate);
            const isOverdue = fine > 0;
            const borderCls = isOverdue ? 'border-red-300 bg-red-50' : 'border-slate-200 bg-white';
            const statusBadge = isOverdue
                ? 'bg-red-100 text-red-800'
                : 'bg-blue-100 text-blue-800';
            const statusLabel = isOverdue ? 'Vencido' : 'Activo';

            const card = document.createElement('div');
            card.className = `rounded-xl border ${borderCls} shadow-sm p-4 md:p-5 transition-all`;
            card.innerHTML = `
                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div class="flex-1 min-w-0">
                        <div class="flex items-center gap-3 mb-2 flex-wrap">
                            <span class="px-2.5 py-0.5 rounded-full text-xs font-medium ${statusBadge}">${statusLabel}</span>
                            <span class="text-xs text-slate-400">ID: ${loan.id}</span>
                        </div>
                        <h3 class="font-semibold text-slate-800 mb-1 line-clamp-2">${loan.bookTitle}</h3>
                        <div class="grid grid-cols-2 gap-x-4 gap-y-1 text-sm text-slate-600 mt-2">
                            <div><span class="font-medium">Usuario:</span> ${loan.userName}</div>
                            <div><span class="font-medium">Préstamo:</span> ${loan.borrowDate}</div>
                            <div class="${isOverdue ? 'text-red-700 font-medium' : ''}">
                                <span class="font-medium">Límite:</span> ${loan.dueDate}
                            </div>
                            ${isOverdue ? `<div class="text-red-700 font-semibold">Multa: $${fine.toFixed(2)} MXN</div>` : '<div></div>'}
                        </div>
                    </div>
                    <button onclick="openReturnModal('${loan.id}')"
                        class="flex-shrink-0 px-5 py-2.5 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg transition-colors flex items-center gap-2">
                        <i data-lucide="archive-restore" class="w-4 h-4"></i>
                        Procesar Devolución
                    </button>
                </div>
            `;
            loansList.appendChild(card);
        });

        lucide.createIcons();
    }

    // ─── Render tabla devoluciones recientes ─────────────────────────
    function renderReturned() {
        const returned = allLoans
            .filter(l => l.status === 'Devuelto' && l.returnDate)
            .sort((a, b) => {
                // Orden descendente por returnDate (dd/mm/yyyy)
                const parse = s => { const [d,m,y] = s.split('/'); return new Date(`${y}-${m}-${d}`); };
                return parse(b.returnDate) - parse(a.returnDate);
            })
            .slice(0, 10);

        returnedTableBody.innerHTML = '';

        if (returned.length === 0) {
            returnedTableBody.innerHTML = `
                <tr><td colspan="4" class="px-6 py-8 text-center text-slate-400 text-sm">Sin devoluciones registradas</td></tr>`;
            return;
        }

        returned.forEach(loan => {
            const tr = document.createElement('tr');
            tr.className = 'hover:bg-slate-50';
            tr.innerHTML = `
                <td class="px-6 py-3 text-slate-700">${loan.userName}</td>
                <td class="px-6 py-3 text-slate-700 max-w-xs">
                    <p class="line-clamp-2">${loan.bookTitle}</p>
                </td>
                <td class="px-6 py-3 text-slate-600">${loan.returnDate}</td>
                <td class="px-6 py-3 font-medium ${loan.fineAmount > 0 ? 'text-red-600' : 'text-green-600'}">
                    ${loan.fineAmount > 0 ? '$' + loan.fineAmount.toFixed(2) : 'Sin multa'}
                </td>
            `;
            returnedTableBody.appendChild(tr);
        });
    }

    // ─── Búsqueda ────────────────────────────────────────────────────
    function filterAndRender() {
        const query = searchInput.value.toLowerCase();
        pendingLoans = getPendingLoans();
        const filtered = query
            ? pendingLoans.filter(l =>
                l.userName.toLowerCase().includes(query) ||
                l.bookTitle.toLowerCase().includes(query))
            : pendingLoans;
        renderPendingLoans(filtered);
    }

    window.clearSearch = () => {
        searchInput.value = '';
        filterAndRender();
    };

    searchInput.addEventListener('input', filterAndRender);

    // ─── Modal devolución ────────────────────────────────────────────
    window.openReturnModal = (loanId) => {
        selectedLoan = allLoans.find(l => String(l.id) === String(loanId));
        if (!selectedLoan) return;

        const fine    = calcFine(selectedLoan.dueDate);
        const daysLate = Math.max(0, daysBetween(selectedLoan.dueDate, todayStr()));

        document.getElementById('rm-user').textContent   = selectedLoan.userName;
        document.getElementById('rm-book').textContent   = selectedLoan.bookTitle;
        document.getElementById('rm-borrow').textContent = selectedLoan.borrowDate;
        document.getElementById('rm-due').textContent    = selectedLoan.dueDate;
        document.getElementById('rm-today').textContent  = todayStr();
        const conditionInput = document.getElementById('rm-condition');
        const notesInput = document.getElementById('rm-notes');
        if (conditionInput) conditionInput.value = 'Bueno';
        if (notesInput) notesInput.value = '';

        const fineAlert   = document.getElementById('fineAlert');
        const noFineAlert = document.getElementById('noFineAlert');

        if (fine > 0) {
            document.getElementById('rm-days-late').textContent = daysLate;
            document.getElementById('rm-fine').textContent = '$' + fine.toFixed(2) + ' MXN';
            fineAlert.classList.remove('hidden');
            noFineAlert.classList.add('hidden');
        } else {
            fineAlert.classList.add('hidden');
            noFineAlert.classList.remove('hidden');
        }

        returnModal.classList.remove('hidden');
        lucide.createIcons();
    };

    window.closeReturnModal = () => {
        returnModal.classList.add('hidden');
        selectedLoan = null;
    };

    document.getElementById('confirmReturnBtn').addEventListener('click', async () => {
        if (!selectedLoan) return;

        const fine        = calcFine(selectedLoan.dueDate);
        const condition   = document.getElementById('rm-condition')?.value || 'Bueno';
        const notes       = document.getElementById('rm-notes')?.value || '';

        if (USE_API) {
            try {
                const result = await apiFetch('devoluciones', 'POST', {
                    loanId:    selectedLoan.id,
                    condition,
                    notes,
                });
                await syncFromAPI();
                allLoans = getLoans();
                closeReturnModal();
                filterAndRender();
                renderReturned();

                const delayFine       = Number(result.fine ?? 0);
                const replacementFine = Number(result.replacementFine ?? 0);
                const isLost          = (result.condition || '').toLowerCase() === 'perdido';
                const totalFine       = delayFine + replacementFine;

                let msg, type;
                if (isLost) {
                    const parts = [];
                    if (delayFine > 0)       parts.push(`retraso $${delayFine.toFixed(2)} MXN`);
                    if (replacementFine > 0) parts.push(`reposición $${replacementFine.toFixed(2)} MXN`);
                    msg  = parts.length > 0
                        ? `Libro marcado como perdido. Multas aplicadas: ${parts.join(' + ')}.`
                        : 'Libro marcado como perdido. Se aplicará cargo de reposición.';
                    type = 'warning';
                } else if (totalFine > 0) {
                    msg  = `Devolución registrada. Multa de $${totalFine.toFixed(2)} MXN aplicada.`;
                    type = 'warning';
                } else {
                    msg  = 'Devolución registrada sin multa.';
                    type = 'success';
                }
                showToast('Devolución exitosa', msg, type);
            } catch (err) {
                showToast('Error', err.message, 'error');
            }
            return;
        }

        // ── localStorage path ────────────────────────────────────────
        const li = allLoans.findIndex(l => String(l.id) === String(selectedLoan.id));
        allLoans[li].status     = 'Devuelto';
        allLoans[li].returnDate = todayStr();
        allLoans[li].fineAmount = fine;
        saveLoans(allLoans);

        const books = getBooks();
        const bi = books.findIndex(b => String(b.id) === String(selectedLoan.bookId));
        if (bi >= 0) {
            books[bi].availableCopies = Math.min(books[bi].totalCopies, books[bi].availableCopies + 1);
            if (books[bi].availableCopies > 0) books[bi].status = 'Disponible';
            saveBooks(books);
        }

        const users = getUsers();
        const ui = users.findIndex(u => String(u.id) === String(selectedLoan.userId));
        if (ui >= 0) {
            users[ui].activeLoans = Math.max(0, (users[ui].activeLoans || 1) - 1);
            if (fine > 0) {
                users[ui].fines = (users[ui].fines || 0) + fine;
                users[ui].fineHistory = users[ui].fineHistory || [];
                users[ui].fineHistory.unshift({
                    id:     'F' + generateId(),
                    amount: fine,
                    reason: `Devolución tardía - ${selectedLoan.bookTitle}`,
                    date:   todayStr(),
                    status: 'Pendiente'
                });
            }
            saveUsers(users);
        }

        closeReturnModal();
        allLoans = getLoans();
        filterAndRender();
        renderReturned();

        const msg = fine > 0
            ? `Devolución registrada. Multa de $${fine.toFixed(2)} MXN aplicada.`
            : 'Devolución registrada sin multa.';
        showToast('Devolución exitosa', msg, fine > 0 ? 'warning' : 'success');
    });

    // ─── Auto-seleccionar préstamo desde URL (?loanId=xxx) ───────────
    const urlParams = new URLSearchParams(window.location.search);
    const loanIdParam = urlParams.get('loanId');
    if (loanIdParam) {
        setTimeout(() => openReturnModal(loanIdParam), 300);
    }

    // ─── Inicio ──────────────────────────────────────────────────────
    pendingLoans = getPendingLoans();
    filterAndRender();
    renderReturned();
    lucide.createIcons();
});
