document.addEventListener('DOMContentLoaded', async () => { await window.__dbReady;
    if (!requirePermission('registrarPrestamo')) return;
    const canRegisterReturn = hasPermission('registrarDevolucion');
    const tableBody = document.getElementById('loansTableBody');
    const mobileContainer = document.getElementById('loansMobileContainer');
    const searchInput = document.getElementById('searchInput');
    const statusFilter = document.getElementById('statusFilter');
    const resultsCount = document.getElementById('resultsCount');

    let allLoans = getLoans();
    let loanToCancel = null;

    // ─── Helpers visuales ───────────────────────────────────────────
    function getStatusBadge(status) {
        switch (status) {
            case 'Activo':    return 'bg-blue-100 text-blue-800';
            case 'Vencido':   return 'bg-red-100 text-red-800';
            case 'Devuelto':  return 'bg-green-100 text-green-800';
            case 'Cancelado': return 'bg-slate-100 text-slate-500';
            default:          return 'bg-slate-100 text-slate-700';
        }
    }

    // Recalcula si un préstamo activo está vencido
    function resolveStatus(loan) {
        const s = (loan.status || '').toLowerCase();
        if (s === 'devuelto')  return 'Devuelto';
        if (s === 'cancelado') return 'Cancelado';
        const fine = calcFine(loan.dueDate);
        return fine > 0 ? 'Vencido' : 'Activo';
    }

    // ─── Estadísticas ────────────────────────────────────────────────
    function updateStats() {
        const total    = allLoans.length;
        const active   = allLoans.filter(l => resolveStatus(l) === 'Activo').length;
        const overdue  = allLoans.filter(l => resolveStatus(l) === 'Vencido').length;
        const returned = allLoans.filter(l => l.status === 'Devuelto').length;

        document.getElementById('stat-total').textContent    = total;
        document.getElementById('stat-active').textContent   = active;
        document.getElementById('stat-overdue').textContent  = overdue;
        document.getElementById('stat-returned').textContent = returned;
    }

    // ─── Render ──────────────────────────────────────────────────────
    function renderLoans(loans) {
        tableBody.innerHTML = '';
        mobileContainer.innerHTML = '';
        resultsCount.textContent = `Mostrando ${loans.length} de ${allLoans.length} préstamos`;

        if (loans.length === 0) {
            tableBody.innerHTML = `
                <tr><td colspan="7" class="px-6 py-12 text-center">
                    <i data-lucide="calendar-check" class="w-12 h-12 text-slate-300 mx-auto mb-3"></i>
                    <p class="text-slate-600">No se encontraron préstamos</p>
                </td></tr>`;
            lucide.createIcons();
            return;
        }

        loans.forEach(loan => {
            const status = resolveStatus(loan);
            const fine   = status === 'Vencido' ? calcFine(loan.dueDate) : 0;
            const badge  = getStatusBadge(status);

            // Desktop row
            const tr = document.createElement('tr');
            tr.className = 'hover:bg-slate-50 transition-colors';
            tr.innerHTML = `
                <td class="px-6 py-4">
                    <p class="font-medium text-slate-800">${loan.userName}</p>
                    <p class="text-xs text-slate-500">${loan.userEmail}</p>
                </td>
                <td class="px-6 py-4">
                    <p class="font-medium text-slate-800 max-w-xs line-clamp-2">${loan.bookTitle}</p>
                    <p class="text-xs text-slate-500">ISBN: ${loan.bookIsbn || '—'}</p>
                </td>
                <td class="px-6 py-4 text-slate-600 text-sm">${loan.borrowDate}</td>
                <td class="px-6 py-4 text-slate-600 text-sm">${loan.dueDate}</td>
                <td class="px-6 py-4">
                    <span class="px-3 py-1 rounded-full text-xs font-medium ${badge}">${status}</span>
                </td>
                <td class="px-6 py-4 text-sm font-medium ${fine > 0 ? 'text-red-600' : 'text-slate-500'}">
                    ${fine > 0 ? '$' + fine.toFixed(2) + ' MXN' : '—'}
                </td>
                <td class="px-6 py-4">
                    <div class="flex items-center gap-2">
                        ${(status !== 'Devuelto' && status !== 'Cancelado') && canRegisterReturn ? `
                        <a href="devoluciones.html?loanId=${loan.id}" class="p-2 text-green-600 hover:bg-green-50 rounded-lg transition-colors" title="Procesar Devolución">
                            <i data-lucide="archive-restore" class="w-4 h-4"></i>
                        </a>
                        <button onclick="openCancelModal('${loan.id}')" class="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors" title="Cancelar">
                            <i data-lucide="x-circle" class="w-4 h-4"></i>
                        </button>` : `<span class="text-xs text-slate-400">Finalizado</span>`}
                    </div>
                </td>
            `;
            tableBody.appendChild(tr);

            // Mobile card
            const card = document.createElement('div');
            card.className = 'bg-white rounded-lg shadow-sm p-4 border border-slate-200';
            card.innerHTML = `
                <div class="flex justify-between items-start mb-3">
                    <div>
                        <p class="font-semibold text-slate-800">${loan.userName}</p>
                        <p class="text-xs text-slate-500 line-clamp-2 mt-0.5">${loan.bookTitle}</p>
                    </div>
                    <span class="px-2 py-1 rounded-full text-xs font-medium ${badge} ml-2 flex-shrink-0">${status}</span>
                </div>
                <div class="grid grid-cols-2 gap-2 text-xs text-slate-500 mb-3">
                    <div><span class="font-medium">Préstamo:</span> ${loan.borrowDate}</div>
                    <div><span class="font-medium">Límite:</span> ${loan.dueDate}</div>
                    ${fine > 0 ? `<div class="col-span-2 text-red-600 font-medium">Multa estimada: $${fine.toFixed(2)} MXN</div>` : ''}
                </div>
                ${(status !== 'Devuelto' && status !== 'Cancelado') ? `
                <div class="flex gap-2 pt-3 border-t border-slate-100">
                    ${canRegisterReturn ? `<a href="devoluciones.html?loanId=${loan.id}" class="flex-1 px-3 py-1.5 text-sm font-medium text-green-700 bg-green-50 rounded hover:bg-green-100 flex items-center justify-center gap-1">
                        <i data-lucide="archive-restore" class="w-3 h-3"></i> Devolver
                    </a>` : ''}
                    <button onclick="openCancelModal('${loan.id}')" class="flex-1 px-3 py-1.5 text-sm font-medium text-red-600 bg-red-50 rounded hover:bg-red-100 flex items-center justify-center gap-1">
                        <i data-lucide="x-circle" class="w-3 h-3"></i> Cancelar
                    </button>
                </div>` : ''}
            `;
            mobileContainer.appendChild(card);
        });

        lucide.createIcons();
    }

    // ─── Filtrado ────────────────────────────────────────────────────
    function filterLoans() {
        const query  = searchInput.value.toLowerCase();
        const status = statusFilter.value;

        const filtered = allLoans.filter(l => {
            const matchSearch = l.userName.toLowerCase().includes(query) ||
                                l.bookTitle.toLowerCase().includes(query);
            const currentStatus = resolveStatus(l);
            const matchStatus = status === 'all' || currentStatus === status;
            return matchSearch && matchStatus;
        });

        renderLoans(filtered);
    }

    searchInput.addEventListener('input', filterLoans);
    statusFilter.addEventListener('change', filterLoans);

    // ─── Modal Nuevo Préstamo ────────────────────────────────────────
    const loanModal = document.getElementById('loanModal');
    const loanForm  = document.getElementById('loanForm');

    // ─── Búsqueda de usuario/libro (combobox) ────────────────────────
    const userSearchEl  = document.getElementById('loan-userSearch');
    const userDropEl    = document.getElementById('loan-userDropdown');
    const userIdEl      = document.getElementById('loan-userId');
    const userSelectedEl= document.getElementById('loan-userSelected');
    const bookSearchEl  = document.getElementById('loan-bookSearch');
    const bookDropEl    = document.getElementById('loan-bookDropdown');
    const bookIdEl      = document.getElementById('loan-bookId');
    const bookSelectedEl= document.getElementById('loan-bookSelected');

    // Calcula fecha saltando fines de semana
    function addBusinessDays(numDays) {
        const date = new Date();
        let added = 0;
        while (added < numDays) {
            date.setDate(date.getDate() + 1);
            const dow = date.getDay();
            if (dow !== 0 && dow !== 6) added++;
        }
        return date.toISOString().split('T')[0];
    }

    // Seleccionar usuario desde dropdown
    window.selectLoanUser = (userId) => {
        const u = getUsers().find(x => String(x.id) === String(userId));
        if (!u) return;
        userIdEl.value    = u.id;
        userSearchEl.value = u.name;
        userDropEl.classList.add('hidden');

        const role = (u.role || '').toLowerCase();
        const isAlumno = role === 'alumno';
        const days  = isAlumno ? 5 : 10;
        const label = isAlumno ? '5 días hábiles (alumno)' : '10 días hábiles (profesor / personal)';

        document.getElementById('loan-dueDate').value = addBusinessDays(days);
        document.getElementById('loan-policyNote').innerHTML =
            `Plazo: <strong>${label}</strong>. Multa por retraso: <strong>$10.00 MXN por día</strong>.`;

        const hasFine = Number(u.fines || 0) > 0;
        userSelectedEl.textContent = `${u.matricula || u.role} · ${u.email || ''}${hasFine ? ' · ⚠ Multa pendiente' : ''}`;
        userSelectedEl.classList.remove('hidden');
    };

    // Seleccionar libro desde dropdown
    window.selectLoanBook = (bookId) => {
        const b = getBooks().find(x => String(x.id) === String(bookId));
        if (!b) return;
        bookIdEl.value     = b.id;
        bookSearchEl.value = b.title;
        bookDropEl.classList.add('hidden');
        bookSelectedEl.textContent = `ISBN: ${b.isbn || '—'} · ${b.availableCopies} copia(s) disponible(s)`;
        bookSelectedEl.classList.remove('hidden');
    };

    // Búsqueda de usuario
    userSearchEl.addEventListener('input', () => {
        const q = userSearchEl.value.toLowerCase().trim();
        userIdEl.value = '';
        userSelectedEl.classList.add('hidden');
        if (!q) { userDropEl.classList.add('hidden'); return; }

        const matches = getUsers()
            .filter(u => (u.status || '').toLowerCase() === 'activo')
            .filter(u =>
                (u.name || '').toLowerCase().includes(q) ||
                (u.matricula || '').toLowerCase().includes(q)
            )
            .slice(0, 8);

        if (!matches.length) { userDropEl.classList.add('hidden'); return; }

        userDropEl.innerHTML = matches.map(u => {
            const hasFine = Number(u.fines || 0) > 0;
            const fineTag = hasFine
                ? '<span class="ml-1 text-amber-600 font-medium">· ⚠ Multa pendiente</span>'
                : '';
            return `<div class="px-4 py-2.5 cursor-pointer hover:bg-slate-50 border-b border-slate-100 last:border-0"
                         onclick="selectLoanUser('${u.id}')">
                <p class="text-sm font-medium text-slate-800">${u.name}${fineTag}</p>
                <p class="text-xs text-slate-500">${u.matricula || '—'} · ${u.role}</p>
            </div>`;
        }).join('');
        userDropEl.classList.remove('hidden');
    });

    // Búsqueda de libro
    bookSearchEl.addEventListener('input', () => {
        const q = bookSearchEl.value.toLowerCase().trim();
        bookIdEl.value = '';
        bookSelectedEl.classList.add('hidden');
        if (!q) { bookDropEl.classList.add('hidden'); return; }

        const matches = getBooks()
            .filter(b => (b.availableCopies || 0) > 0)
            .filter(b =>
                (b.title || '').toLowerCase().includes(q) ||
                (b.isbn  || '').toLowerCase().includes(q)
            )
            .slice(0, 8);

        if (!matches.length) { bookDropEl.classList.add('hidden'); return; }

        bookDropEl.innerHTML = matches.map(b =>
            `<div class="px-4 py-2.5 cursor-pointer hover:bg-slate-50 border-b border-slate-100 last:border-0"
                  onclick="selectLoanBook('${b.id}')">
                <p class="text-sm font-medium text-slate-800 line-clamp-1">${b.title}</p>
                <p class="text-xs text-slate-500">ISBN: ${b.isbn || '—'} · ${b.availableCopies} disp.</p>
            </div>`
        ).join('');
        bookDropEl.classList.remove('hidden');
    });

    // Cerrar dropdowns al hacer clic fuera
    document.addEventListener('click', (e) => {
        if (!e.target.closest('#loan-userSearch') && !e.target.closest('#loan-userDropdown')) {
            userDropEl.classList.add('hidden');
        }
        if (!e.target.closest('#loan-bookSearch') && !e.target.closest('#loan-bookDropdown')) {
            bookDropEl.classList.add('hidden');
        }
    });

    window.openLoanModal = () => {
        if (!hasPermission('registrarPrestamo')) return;
        loanForm.reset();

        // Limpiar búsqueda
        userSearchEl.value = '';
        bookSearchEl.value = '';
        userIdEl.value     = '';
        bookIdEl.value     = '';
        userDropEl.classList.add('hidden');
        bookDropEl.classList.add('hidden');
        userSelectedEl.classList.add('hidden');
        bookSelectedEl.classList.add('hidden');

        // Fecha mínima hoy; sin default hasta seleccionar usuario
        const today = new Date().toISOString().split('T')[0];
        const dueDateInput = document.getElementById('loan-dueDate');
        dueDateInput.min   = today;
        dueDateInput.value = '';

        document.getElementById('loan-policyNote').innerHTML =
            'Selecciona un usuario para ver el plazo asignado. Multa por retraso: <strong>$10.00 MXN por día</strong>.';

        loanModal.classList.remove('hidden');
        lucide.createIcons();
    };

    window.closeLoanModal = () => loanModal.classList.add('hidden');

    loanForm.addEventListener('submit', async e => {
        e.preventDefault();

        const userId     = document.getElementById('loan-userId').value;
        const bookId     = document.getElementById('loan-bookId').value;
        const dueDateRaw = document.getElementById('loan-dueDate').value;

        if (!userId)     { showToast('Campo requerido', 'Selecciona un usuario.',            'error'); return; }
        if (!bookId)     { showToast('Campo requerido', 'Selecciona un libro.',              'error'); return; }
        if (!dueDateRaw) { showToast('Campo requerido', 'Indica la fecha de devolución.',    'error'); return; }

        const user = getUsers().find(u => String(u.id) === String(userId));
        const book = getBooks().find(b => String(b.id) === String(bookId));

        if (!user || !book || book.availableCopies <= 0) {
            showToast('Error', 'El libro ya no está disponible.', 'error');
            return;
        }

        if (USE_API) {
            try {
                await apiFetch('prestamos', 'POST', { userId, bookId, dueDate: dueDateRaw });
                await syncFromAPI();
                allLoans = getLoans();
                closeLoanModal();
                updateStats();
                filterLoans();
                showToast('Préstamo registrado', `"${book.title}" prestado a ${user.name}.`, 'success');
            } catch (err) {
                showToast('Error', err.message, 'error');
            }
            return;
        }

        // ── localStorage path ────────────────────────────────────────
        const [y, m, d] = dueDateRaw.split('-');
        const dueDate    = `${d}/${m}/${y}`;
        const borrowDate = todayStr();

        const newLoan = {
            id:        'L' + generateId(),
            bookId:    book.id,
            bookTitle: book.title,
            bookIsbn:  book.isbn,
            userId:    user.id,
            userName:  user.name,
            userEmail: user.email,
            borrowDate,
            dueDate,
            status:    'Activo',
            returnDate: null,
            fineAmount: 0
        };

        const books = getBooks();
        const bi = books.findIndex(b => String(b.id) === String(book.id));
        books[bi].availableCopies--;
        if (books[bi].availableCopies <= 0) books[bi].status = 'Prestado';
        saveBooks(books);

        const users = getUsers();
        const ui = users.findIndex(u => String(u.id) === String(user.id));
        users[ui].activeLoans = (users[ui].activeLoans || 0) + 1;
        users[ui].loans = users[ui].loans || [];
        users[ui].loans.unshift({ id: newLoan.id, bookTitle: book.title, borrowDate, dueDate, status: 'Activo' });
        saveUsers(users);

        allLoans.unshift(newLoan);
        saveLoans(allLoans);

        closeLoanModal();
        updateStats();
        filterLoans();
        showToast('Préstamo registrado', `"${book.title}" prestado a ${user.name}.`, 'success');
    });

    // ─── Modal Cancelar Préstamo ─────────────────────────────────────
    const cancelModal = document.getElementById('cancelModal');

    window.openCancelModal = (loanId) => {
        loanToCancel = loanId;
        cancelModal.classList.remove('hidden');
    };

    document.getElementById('cancelCancelBtn').addEventListener('click', () => {
        loanToCancel = null;
        cancelModal.classList.add('hidden');
    });

    document.getElementById('confirmCancelBtn').addEventListener('click', async () => {
        if (!loanToCancel) return;
        const loan = allLoans.find(l => String(l.id) === String(loanToCancel));
        if (!loan) return;

        if (USE_API) {
            try {
                await apiFetch(`prestamos?id=${loanToCancel}`, 'DELETE');
                await syncFromAPI();
                allLoans = getLoans();
                loanToCancel = null;
                cancelModal.classList.add('hidden');
                updateStats();
                filterLoans();
                showToast('Préstamo cancelado', 'El libro volvió al inventario.', 'success');
            } catch (err) {
                showToast('Error', err.message, 'error');
            }
            return;
        }

        // ── localStorage path ────────────────────────────────────────
        const books = getBooks();
        const bi = books.findIndex(b => String(b.id) === String(loan.bookId));
        if (bi >= 0) {
            books[bi].availableCopies++;
            if (books[bi].availableCopies > 0) books[bi].status = 'Disponible';
            saveBooks(books);
        }

        const users = getUsers();
        const ui = users.findIndex(u => String(u.id) === String(loan.userId));
        if (ui >= 0) {
            users[ui].activeLoans = Math.max(0, (users[ui].activeLoans || 1) - 1);
            saveUsers(users);
        }

        const li = allLoans.findIndex(l => String(l.id) === String(loanToCancel));
        allLoans[li].status     = 'Devuelto';
        allLoans[li].returnDate = todayStr();
        saveLoans(allLoans);

        loanToCancel = null;
        cancelModal.classList.add('hidden');
        updateStats();
        filterLoans();
        showToast('Préstamo cancelado', 'El libro volvió al inventario.', 'success');
    });

    // ─── Inicio ──────────────────────────────────────────────────────
    updateStats();
    renderLoans(allLoans);
    lucide.createIcons();

    // ═══════════════════════════════════════════════════════════════
    //  TABS
    // ═══════════════════════════════════════════════════════════════
    window.switchTab = (tab) => {
        const isPrestamos = tab === 'prestamos';

        document.getElementById('panel-prestamos').classList.toggle('hidden', !isPrestamos);
        document.getElementById('panel-solicitudes').classList.toggle('hidden', isPrestamos);
        document.getElementById('newLoanBtn').classList.toggle('hidden', !isPrestamos);

        const tabPrestamos   = document.getElementById('tab-prestamos');
        const tabSolicitudes = document.getElementById('tab-solicitudes');

        if (isPrestamos) {
            tabPrestamos.classList.add('bg-white', 'text-slate-800', 'shadow-sm');
            tabPrestamos.classList.remove('text-slate-600', 'hover:text-slate-800');
            tabSolicitudes.classList.remove('bg-white', 'text-slate-800', 'shadow-sm');
            tabSolicitudes.classList.add('text-slate-600', 'hover:text-slate-800');
        } else {
            tabSolicitudes.classList.add('bg-white', 'text-slate-800', 'shadow-sm');
            tabSolicitudes.classList.remove('text-slate-600', 'hover:text-slate-800');
            tabPrestamos.classList.remove('bg-white', 'text-slate-800', 'shadow-sm');
            tabPrestamos.classList.add('text-slate-600', 'hover:text-slate-800');
            loadReservations();
        }
        lucide.createIcons();
    };

    // ═══════════════════════════════════════════════════════════════
    //  SOLICITUDES DE RESERVA
    // ═══════════════════════════════════════════════════════════════
    let allReservations     = [];
    let currentResFilter    = 'activa';
    let pendingApproveId    = null;
    let pendingRejectId     = null;

    async function loadReservations() {
        document.getElementById('reservationsLoading').classList.remove('hidden');
        document.getElementById('reservationsContainer').classList.add('hidden');
        document.getElementById('reservationsEmpty').classList.add('hidden');

        try {
            const rows = await apiFetch('reservas', 'GET');
            allReservations = Array.isArray(rows) ? rows : [];
        } catch (e) {
            showToast('Error', 'No se pudieron cargar las solicitudes.', 'error');
            allReservations = [];
        }

        // Actualizar badge con activas
        const activas = allReservations.filter(r => r.estado === 'activa').length;
        const badge   = document.getElementById('solicitudesBadge');
        if (activas > 0) {
            badge.textContent = activas;
            badge.classList.remove('hidden');
        } else {
            badge.classList.add('hidden');
        }

        document.getElementById('reservationsLoading').classList.add('hidden');
        renderReservations();
    }

    function renderReservations() {
        const container = document.getElementById('reservationsContainer');
        const empty     = document.getElementById('reservationsEmpty');

        const filtered = currentResFilter === 'todas'
            ? allReservations
            : allReservations.filter(r => r.estado === currentResFilter);

        container.innerHTML = '';

        if (filtered.length === 0) {
            container.classList.add('hidden');
            empty.classList.remove('hidden');
            lucide.createIcons();
            return;
        }

        empty.classList.add('hidden');
        container.classList.remove('hidden');

        filtered.forEach(r => {
            const isActiva = r.estado === 'activa';
            const hayCopiasDisponibles = (r.copiasDisponibles || 0) > 0;

            const estadoBadge = {
                activa:    'bg-blue-100 text-blue-800',
                atendida:  'bg-green-100 text-green-800',
                cancelada: 'bg-slate-100 text-slate-600',
                expirada:  'bg-red-100 text-red-700',
            }[r.estado] || 'bg-slate-100 text-slate-600';

            const estadoLabel = {
                activa:    'Activa',
                atendida:  'Atendida',
                cancelada: 'Cancelada',
                expirada:  'Expirada',
            }[r.estado] || r.estado;

            const copiasColor = hayCopiasDisponibles ? 'text-green-700' : 'text-red-600';
            const copiasText  = hayCopiasDisponibles
                ? `${r.copiasDisponibles} copia(s) disponible(s)`
                : 'Sin copias disponibles';

            const card = document.createElement('div');
            card.className = 'bg-white rounded-lg border border-slate-200 shadow-sm p-4 md:p-5';
            card.innerHTML = `
                <div class="flex flex-col sm:flex-row sm:items-start gap-4">
                    <!-- Info usuario y libro -->
                    <div class="flex-1 space-y-3">
                        <div class="flex items-center gap-2 flex-wrap">
                            <span class="px-2.5 py-0.5 rounded-full text-xs font-medium ${estadoBadge}">${estadoLabel}</span>
                            <span class="text-xs text-slate-400">Solicitado: ${r.fechaReserva}</span>
                            ${r.fechaExpiracion ? `<span class="text-xs text-slate-400">Expira: ${r.fechaExpiracion}</span>` : ''}
                        </div>
                        <div class="grid sm:grid-cols-2 gap-3">
                            <div class="flex items-start gap-3">
                                <div class="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                                    <i data-lucide="user" class="w-4 h-4 text-primary"></i>
                                </div>
                                <div>
                                    <p class="font-semibold text-slate-800 text-sm">${r.userName}</p>
                                    <p class="text-xs text-slate-500">${r.userEmail}</p>
                                    <p class="text-xs text-slate-400">${r.userMatricula || ''} · ${r.userRole || ''}</p>
                                </div>
                            </div>
                            <div class="flex items-start gap-3">
                                <div class="w-9 h-9 rounded-lg bg-orange-50 flex items-center justify-center flex-shrink-0">
                                    <i data-lucide="book-open" class="w-4 h-4 text-primary"></i>
                                </div>
                                <div>
                                    <p class="font-semibold text-slate-800 text-sm line-clamp-2">${r.bookTitle}</p>
                                    <p class="text-xs text-slate-500">ISBN: ${r.bookIsbn || '—'}</p>
                                    <p class="text-xs font-medium ${copiasColor} mt-0.5">${copiasText}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Acciones (solo si activa) -->
                    ${isActiva ? `
                    <div class="flex sm:flex-col gap-2 sm:min-w-[130px]">
                        <button onclick="openApproveModal(${r.id})"
                            class="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-lg transition-colors ${!hayCopiasDisponibles ? 'opacity-50 cursor-not-allowed' : ''}"
                            ${!hayCopiasDisponibles ? 'disabled title="No hay copias disponibles"' : ''}>
                            <i data-lucide="check" class="w-4 h-4"></i> Aprobar
                        </button>
                        <button onclick="openRejectModal(${r.id})"
                            class="flex-1 sm:flex-none flex items-center justify-center gap-1.5 px-3 py-2 bg-white hover:bg-red-50 text-red-600 border border-red-200 text-sm font-medium rounded-lg transition-colors">
                            <i data-lucide="x" class="w-4 h-4"></i> Rechazar
                        </button>
                    </div>` : ''}
                </div>
            `;
            container.appendChild(card);
        });

        lucide.createIcons();
    }

    window.filterReservations = (estado) => {
        currentResFilter = estado;
        document.querySelectorAll('.res-filter-btn').forEach(btn => {
            const isActive = btn.dataset.resFilter === estado;
            btn.classList.toggle('bg-primary',     isActive);
            btn.classList.toggle('text-white',     isActive);
            btn.classList.toggle('border-primary', isActive);
            btn.classList.toggle('bg-white',       !isActive);
            btn.classList.toggle('text-slate-600', !isActive);
            btn.classList.toggle('border-slate-300', !isActive);
        });
        renderReservations();
    };

    // ─── Modal Aprobar ───────────────────────────────────────────────
    const approveModal = document.getElementById('approveModal');

    window.openApproveModal = (reservaId) => {
        const r = allReservations.find(x => x.id === reservaId || String(x.id) === String(reservaId));
        if (!r) return;

        pendingApproveId = reservaId;

        document.getElementById('approve-userName').textContent  = r.userName;
        document.getElementById('approve-userEmail').textContent = r.userEmail;
        document.getElementById('approve-bookTitle').textContent = r.bookTitle;
        document.getElementById('approve-bookIsbn').textContent  = `ISBN: ${r.bookIsbn || '—'}`;

        const copiasEl = document.getElementById('approve-copiasInfo');
        copiasEl.textContent = `${r.copiasDisponibles || 0} copia(s) disponible(s)`;
        copiasEl.className   = `text-xs font-medium mt-1 ${(r.copiasDisponibles || 0) > 0 ? 'text-green-700' : 'text-red-600'}`;

        const tieneMulta = (r.multasPendientes || 0) > 0;
        document.getElementById('approve-multaAlert').classList.toggle('hidden', !tieneMulta);
        document.getElementById('approve-dueDateSection').classList.toggle('hidden', tieneMulta);
        document.getElementById('approve-multaMsg').textContent = tieneMulta
            ? `Este usuario tiene $${Number(r.multasPendientes).toFixed(2)} MXN en multas pendientes.`
            : '';
        document.querySelector('#approveModal button[onclick="confirmApprove()"]')
            .toggleAttribute('disabled', tieneMulta);

        const today      = new Date();
        const minDate    = today.toISOString().split('T')[0];
        const defaultDue = new Date(today.setDate(today.getDate() + 15)).toISOString().split('T')[0];
        const dueDateEl  = document.getElementById('approve-dueDate');
        dueDateEl.min    = minDate;
        dueDateEl.value  = defaultDue;

        approveModal.classList.remove('hidden');
        lucide.createIcons();
    };

    window.closeApproveModal = () => {
        approveModal.classList.add('hidden');
        pendingApproveId = null;
    };

    window.confirmApprove = async () => {
        if (!pendingApproveId) return;

        const dueDate = document.getElementById('approve-dueDate').value;
        if (!dueDate) {
            showToast('Error', 'Selecciona una fecha de devolución.', 'error');
            return;
        }

        const currentUser = getCurrentUser();
        const librarianId = currentUser?.id ?? 1;

        try {
            await apiFetch('reservas', 'PUT', {
                id:          pendingApproveId,
                action:      'aprobar',
                dueDate,
                librarianId,
            });

            closeApproveModal();
            await syncFromAPI();
            allLoans = getLoans();
            updateStats();
            filterLoans();
            showToast('Préstamo creado', 'La reserva fue aprobada y el préstamo registrado.', 'success');
            loadReservations();
        } catch (err) {
            showToast('Error', err.message, 'error');
        }
    };

    // ─── Modal Rechazar ──────────────────────────────────────────────
    const rejectModal = document.getElementById('rejectModal');

    window.openRejectModal = (reservaId) => {
        const r = allReservations.find(x => x.id === reservaId || String(x.id) === String(reservaId));
        if (!r) return;

        pendingRejectId = reservaId;
        document.getElementById('reject-userName').textContent  = r.userName;
        document.getElementById('reject-bookTitle').textContent = r.bookTitle;

        rejectModal.classList.remove('hidden');
    };

    window.closeRejectModal = () => {
        rejectModal.classList.add('hidden');
        pendingRejectId = null;
    };

    window.confirmReject = async () => {
        if (!pendingRejectId) return;

        try {
            await apiFetch('reservas', 'PUT', { id: pendingRejectId, action: 'rechazar' });
            closeRejectModal();
            showToast('Solicitud rechazada', 'La reserva fue cancelada.', 'warning');
            loadReservations();
        } catch (err) {
            showToast('Error', err.message, 'error');
        }
    };

    // Cargar badge de solicitudes activas al arrancar
    if (USE_API) {
        apiFetch('reservas', 'GET').then(rows => {
            if (!Array.isArray(rows)) return;
            const activas = rows.filter(r => r.estado === 'activa').length;
            const badge   = document.getElementById('solicitudesBadge');
            if (activas > 0) {
                badge.textContent = activas;
                badge.classList.remove('hidden');
            }
        }).catch(() => {});
    }
});
