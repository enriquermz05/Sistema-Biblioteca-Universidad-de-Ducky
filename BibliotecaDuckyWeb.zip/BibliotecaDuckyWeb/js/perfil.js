document.addEventListener('DOMContentLoaded', async () => {
    await window.__dbReady;
    if (!requireLogin()) return;

    const sessionUser = getCurrentUser();
    if (!sessionUser) return;

    const allUsers = getUsers();
    const user = allUsers.find(u => String(u.id) === String(sessionUser.id)) || sessionUser;

    // Initials
    const nameParts = (user.name || 'U').trim().split(/\s+/);
    const initials = nameParts.length >= 2
        ? (nameParts[0][0] + nameParts[nameParts.length - 1][0]).toUpperCase()
        : (nameParts[0] || 'U').substring(0, 2).toUpperCase();

    document.getElementById('p-initials').textContent = initials;
    document.getElementById('p-name').textContent = user.name || '—';
    document.getElementById('p-matricula').textContent = user.universityId || user.matricula || '—';
    document.getElementById('p-email').textContent = user.email || '—';

    const isActive = (user.status || '').toLowerCase() === 'activo';

    const roleBadge = document.getElementById('p-role-badge');
    roleBadge.textContent = user.role || '—';

    const statusBadge = document.getElementById('p-status-badge');
    statusBadge.textContent = user.status || '—';
    statusBadge.className = isActive
        ? 'px-3 py-1 rounded-full text-xs font-semibold bg-green-500/20 border border-green-400/40 text-green-200'
        : 'px-3 py-1 rounded-full text-xs font-semibold bg-red-500/20 border border-red-400/40 text-red-200';

    // Loans for this user
    const allLoans = getLoans();
    const userLoans = allLoans.filter(l => String(l.userId) === String(user.id));
    const activeLoans = userLoans.filter(l => {
        const s = (l.status || '').toLowerCase();
        return s !== 'devuelto' && s !== 'returned';
    });
    const perms = getCurrentPermissions();

    // Info card
    document.getElementById('p-info-name').textContent = user.name || '—';
    document.getElementById('p-info-email').textContent = user.email || '—';
    document.getElementById('p-info-matricula').textContent = user.universityId || user.matricula || '—';
    document.getElementById('p-info-role').textContent = user.role || '—';

    const infoStatus = document.getElementById('p-info-status');
    infoStatus.textContent = user.status || '—';
    infoStatus.className = isActive
        ? 'text-sm font-medium text-green-600'
        : 'text-sm font-medium text-red-500';

    // Permissions list
    const permissionLabels = {
        crearUsuarios: 'Crear Usuarios',
        suspenderUsuarios: 'Suspender Usuarios',
        registrarPrestamo: 'Registrar Préstamo',
        registrarDevolucion: 'Registrar Devolución',
        renovarPrestamo: 'Renovar Préstamo',
        gestionarCatalogo: 'Gestionar Catálogo',
        buscarLibros: 'Buscar Libros',
        consultarCatalogo: 'Consultar Catálogo',
        verReportes: 'Ver Reportes',
    };

    document.getElementById('p-permissions-list').innerHTML = Object.entries(permissionLabels).map(([key, label]) => {
        const granted = !!perms[key];
        return `
            <div class="flex items-center gap-2 px-3 py-2 rounded-lg ${granted ? 'bg-green-50' : 'bg-slate-50'}">
                <i data-lucide="${granted ? 'check-circle' : 'x-circle'}" class="w-4 h-4 flex-shrink-0 ${granted ? 'text-green-600' : 'text-slate-300'}"></i>
                <span class="text-sm ${granted ? 'text-slate-700' : 'text-slate-400'}">${label}</span>
            </div>
        `;
    }).join('');

    // Loans table
    const loansBody = document.getElementById('p-loans-body');
    if (activeLoans.length === 0) {
        loansBody.innerHTML = `<tr><td colspan="4" class="px-6 py-8 text-center text-sm text-slate-400">No tienes préstamos activos</td></tr>`;
    } else {
        const statusClass = { activo: 'bg-blue-100 text-blue-800', vencido: 'bg-red-100 text-red-800', renovado: 'bg-purple-100 text-purple-800' };
        loansBody.innerHTML = activeLoans.map(loan => {
            const key = (loan.status || '').toLowerCase();
            const badge = statusClass[key] || 'bg-slate-100 text-slate-700';
            return `
                <tr class="hover:bg-slate-50">
                    <td class="px-6 py-3 text-sm text-slate-700">${loan.bookTitle || '—'}</td>
                    <td class="px-6 py-3 text-sm text-slate-500">${loan.borrowDate || '—'}</td>
                    <td class="px-6 py-3 text-sm text-slate-500">${loan.dueDate || '—'}</td>
                    <td class="px-6 py-3"><span class="px-2 py-0.5 rounded-full text-xs font-medium ${badge}">${loan.status || '—'}</span></td>
                </tr>
            `;
        }).join('');
    }

    // Fines table
    const finesBody = document.getElementById('p-fines-body');
    const fineHistory = Array.isArray(user.fineHistory) ? user.fineHistory : [];
    if (fineHistory.length === 0) {
        finesBody.innerHTML = `<tr><td colspan="4" class="px-6 py-8 text-center text-sm text-slate-400">Sin historial de multas</td></tr>`;
    } else {
        finesBody.innerHTML = fineHistory.map(fine => {
            const pending = (fine.status || '').toLowerCase() === 'pendiente';
            return `
                <tr class="hover:bg-slate-50">
                    <td class="px-6 py-3 text-sm text-slate-500">${fine.date || '—'}</td>
                    <td class="px-6 py-3 text-sm text-slate-700">${fine.reason || '—'}</td>
                    <td class="px-6 py-3 text-sm font-semibold text-slate-800">$${toNumber(fine.amount).toFixed(2)}</td>
                    <td class="px-6 py-3"><span class="px-2 py-0.5 rounded-full text-xs font-medium ${pending ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}">${fine.status || '—'}</span></td>
                </tr>
            `;
        }).join('');
    }

    lucide.createIcons();
});
