document.addEventListener('DOMContentLoaded', async () => { await window.__dbReady;
    if (!requireLogin()) return;
    const canCreateUsers = hasPermission('crearUsuarios');
    const canSuspendUsers = hasPermission('suspenderUsuarios');
    const tableBody = document.getElementById('usersTableBody');
    const mobileContainer = document.getElementById('usersMobileContainer');
    const searchInput = document.getElementById('searchInput');
    const roleFilter = document.getElementById('roleFilter');
    const statusFilter = document.getElementById('statusFilter');
    const resultsCount = document.getElementById('resultsCount');
    const suspendModal = document.getElementById('suspendModal');
    const suspendReason = document.getElementById('suspendReason');
    const suspendUserName = document.getElementById('suspendUserName');
    const confirmSuspendBtn = document.getElementById('confirmSuspendBtn');

    let allUsers = getUsers();
    let userToSuspendId = null;

    async function reloadUsersFromSource() {
        if (USE_API && typeof syncFromAPI === 'function') {
            await syncFromAPI();
        }
        allUsers = getUsers();
        renderStats();
        filterData();
    }

    function renderStats() {
        const usersWithFines = allUsers.filter(u => u.fines > 0).length;
        const suspendedUsers = allUsers.filter(u => u.status === "Suspendido").length;
        const usersWithActiveLoans = allUsers.filter(u => u.activeLoans > 0).length;
        
        // Mock new users (since we don't strictly have a joinedDate parse logic, just hardcoding mock or a rough est)
        const newUsers = Math.floor(allUsers.length * 0.1); 

        document.getElementById('stat-fines').textContent = usersWithFines;
        document.getElementById('stat-suspended').textContent = suspendedUsers;
        document.getElementById('stat-loans').textContent = usersWithActiveLoans;
        document.getElementById('stat-new').textContent = newUsers;
    }

    function renderUsers(usersToRender) {
        tableBody.innerHTML = '';
        mobileContainer.innerHTML = '';
        
        resultsCount.textContent = `Mostrando ${usersToRender.length} de ${allUsers.length} usuarios`;

        if (usersToRender.length === 0) {
            const emptyState = `
                <tr>
                  <td colspan="7" class="px-6 py-12 text-center">
                    <i data-lucide="users" class="w-12 h-12 text-slate-300 mx-auto mb-3"></i>
                    <p class="text-slate-600">No se encontraron usuarios</p>
                  </td>
                </tr>
            `;
            tableBody.innerHTML = emptyState;
            mobileContainer.innerHTML = emptyState; // Just generic empty state for mobile too
            lucide.createIcons();
            return;
        }

        usersToRender.forEach(user => {
            const roleColor = getRoleColor(user.role);
            const statusColor = getStatusColor(user.status);
            const finesClass = user.fines > 0 ? "text-red-600" : "text-green-600";

            // Desktop Row
            const tr = document.createElement('tr');
            tr.className = 'hover:bg-slate-50 cursor-pointer transition-colors';
            // Click row to view profile
            tr.onclick = (e) => {
                if(!e.target.closest('button')) {
                    window.location.href = `user-profile.html?id=${user.id}`;
                }
            };

            const suspendBtn = canSuspendUsers && user.status !== "Suspendido"
                ? `<button onclick="event.stopPropagation(); suspendUser('${user.id}')" class="p-2 text-red-600 hover:text-red-700 hover:bg-red-50 rounded-md transition-colors" title="Suspender">
                        <i data-lucide="ban" class="w-4 h-4"></i>
                   </button>`
                : canSuspendUsers
                    ? `<button onclick="event.stopPropagation(); reactivateUser('${user.id}')" class="p-2 text-green-600 hover:text-green-700 hover:bg-green-50 rounded-md transition-colors" title="Quitar suspensión">
                            <i data-lucide="user-check" class="w-4 h-4"></i>
                       </button>`
                : '';

            tr.innerHTML = `
                <td class="px-6 py-4">
                    <div>
                        <div class="font-medium text-[#111827]">${user.name}</div>
                        <div class="text-sm text-slate-500">${user.email}</div>
                    </div>
                </td>
                <td class="px-6 py-4 text-slate-600">${user.universityId}</td>
                <td class="px-6 py-4">
                    <span class="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium border ${roleColor}">${user.role}</span>
                </td>
                <td class="px-6 py-4">
                    <span class="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColor}">${user.status}</span>
                </td>
                <td class="px-6 py-4 text-[#111827] font-medium">${user.activeLoans}</td>
                <td class="px-6 py-4 font-medium ${finesClass}">$${user.fines.toFixed(2)}</td>
                <td class="px-6 py-4">
                    <div class="flex items-center justify-end gap-1">
                        ${suspendBtn}
                    </div>
                </td>
            `;
            tableBody.appendChild(tr);

            // Mobile Card
            const card = document.createElement('div');
            card.className = "bg-white rounded-lg shadow-sm p-4 border border-slate-200";
            card.innerHTML = `
                <div class="flex justify-between items-start mb-3" onclick="window.location.href='user-profile.html?id=${user.id}'">
                    <div>
                        <h3 class="font-medium text-slate-900">${user.name}</h3>
                        <p class="text-sm text-slate-500">${user.universityId}</p>
                    </div>
                    <span class="inline-block px-2.5 py-0.5 rounded-full text-xs font-medium border ${statusColor}">${user.status}</span>
                </div>
                <div class="grid grid-cols-2 gap-2 text-sm mb-3" onclick="window.location.href='user-profile.html?id=${user.id}'">
                    <div>
                        <span class="text-slate-500">Rol:</span> 
                        <span class="inline-block px-2 py-0.5 mt-1 rounded text-[10px] font-medium border ${roleColor}">${user.role}</span>
                    </div>
                    <div>
                        <span class="text-slate-500">Multas:</span> 
                        <span class="font-medium ${finesClass}">$${user.fines.toFixed(2)}</span>
                    </div>
                </div>
                <div class="flex gap-2 pt-3 border-t border-slate-100">
                    ${canSuspendUsers && user.status !== "Suspendido" ? `
                    <button onclick="event.stopPropagation(); suspendUser('${user.id}')" class="flex-1 px-3 py-1.5 text-sm font-medium text-red-600 bg-red-50 rounded hover:bg-red-100 transition-colors flex items-center justify-center gap-1">
                        <i data-lucide="ban" class="w-3 h-3"></i> Suspender
                    </button>` : canSuspendUsers && user.status === "Suspendido" ? `
                    <button onclick="event.stopPropagation(); reactivateUser('${user.id}')" class="flex-1 px-3 py-1.5 text-sm font-medium text-green-700 bg-green-50 rounded hover:bg-green-100 transition-colors flex items-center justify-center gap-1">
                        <i data-lucide="user-check" class="w-3 h-3"></i> Quitar suspensión
                    </button>` : `<span class="flex-1 text-center text-xs text-slate-400 py-1.5">Sin acciones disponibles</span>`}
                </div>
            `;
            mobileContainer.appendChild(card);
        });

        lucide.createIcons();
    }

    function getRoleColor(role) {
        switch (role) {
            case "Administrador": return "bg-purple-100 text-purple-700 border-purple-300";
            case "Bibliotecario": return "bg-blue-100 text-blue-700 border-blue-300";
            case "Profesor": return "bg-orange-100 text-orange-700 border-orange-300";
            case "Alumno": return "bg-emerald-100 text-emerald-700 border-emerald-300";
            case "Colaborador": return "bg-amber-100 text-amber-700 border-amber-300";
            default: return "bg-slate-100 text-slate-700 border-slate-300";
        }
    }

    function getStatusColor(status) {
        switch (status) {
            case "Activo": return "bg-green-100 text-green-700 border-green-300";
            case "Suspendido": return "bg-red-100 text-red-700 border-red-300";
            case "Inactivo": return "bg-slate-100 text-slate-700 border-slate-300";
            default: return "bg-slate-100 text-slate-700 border-slate-300";
        }
    }

    function filterData() {
        const query = searchInput.value.toLowerCase();
        const role = roleFilter.value;
        const status = statusFilter.value;

        const filtered = allUsers.filter(u => {
            const matchesSearch = u.name.toLowerCase().includes(query) || 
                                  u.email.toLowerCase().includes(query) || 
                                  u.universityId.toLowerCase().includes(query);
            const matchesRole = role === 'all' || u.role === role;
            const matchesStatus = status === 'all' || u.status === status;

            return matchesSearch && matchesRole && matchesStatus;
        });

        renderUsers(filtered);
    }

    searchInput.addEventListener('input', filterData);
    roleFilter.addEventListener('change', filterData);
    statusFilter.addEventListener('change', filterData);

    // Initial render
    renderStats();
    renderUsers(allUsers);


    // IMPORT MODAL
    const importModal = document.getElementById('importModal');
    const importTableSection = document.getElementById('importTableSection');
    const importTableBody = document.getElementById('importTableBody');
    const btnExecuteImport = document.getElementById('btnExecuteImport');
    const importCount = document.getElementById('importCount');
    const selectAllImport = document.getElementById('selectAllImport');
    
    let mockExternalUsers = [];
    
    window.openImportModal = () => {
        importTableSection.classList.add('hidden');
        btnExecuteImport.disabled = true;
        importCount.textContent = '0';
        selectAllImport.checked = false;
        importModal.classList.remove('hidden');
    };
    
    window.closeImportModal = () => importModal.classList.add('hidden');
    
    let currentExternalEntity = null;
    let currentExternalMicrocontroller = null;

    function getExternalType(origin) {
        if (origin === 'Escolar') return 'escolar';
        if (origin === 'CapitalHumano') return 'recursos_humanos';
        return 'tesoreria';
    }

    function getOriginBadgeClass(type) {
        if (type === 'escolar') return 'bg-blue-100 text-blue-700 text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wide ml-2 border border-blue-200';
        if (type === 'recursos_humanos') return 'bg-orange-100 text-orange-700 text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wide ml-2 border border-orange-200';
        return 'bg-emerald-100 text-emerald-700 text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wide ml-2 border border-emerald-200';
    }

    function getOriginLabel(type, entity, microcontroller) {
        const mcuCode = microcontroller?.codigo ? ` · ${microcontroller.codigo}` : '';
        if (type === 'escolar') return `${entity?.nombre || 'Sistema Escolar'} (Alumnos)${mcuCode}`;
        if (type === 'recursos_humanos') return `${entity?.nombre || 'Recursos Humanos'} (Personal)${mcuCode}`;
        return `${entity?.nombre || 'Tesorería'} (Pagos y multas)${mcuCode}`;
    }

    window.simulateFetchOrigin = async (origin) => {
        const type = getExternalType(origin);
        const badge = document.getElementById('importOriginBadge');
        importTableSection.classList.remove('hidden');
        importTableBody.innerHTML = `
            <tr>
                <td colspan="4" class="px-4 py-8 text-center text-slate-500">
                    Consultando microcontrolador de integración...
                </td>
            </tr>
        `;
        btnExecuteImport.disabled = true;
        importCount.textContent = '0';
        selectAllImport.checked = false;

        try {
            const response = await fetch(`api/entidades_externas.php?tipo=${encodeURIComponent(type)}`);
            const data = await response.json();
            if (!response.ok) throw new Error(data.error || 'No se pudo consultar la entidad externa');

            currentExternalEntity = data.entity;
            currentExternalMicrocontroller = data.microcontroller;
            mockExternalUsers = Array.isArray(data.records) ? data.records : [];

            badge.textContent = getOriginLabel(type, currentExternalEntity, currentExternalMicrocontroller);
            badge.className = getOriginBadgeClass(type);
            renderImportTable();
        } catch (error) {
            mockExternalUsers = [];
            currentExternalEntity = null;
            currentExternalMicrocontroller = null;
            badge.textContent = 'Error de integración';
            badge.className = 'bg-red-100 text-red-700 text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wide ml-2 border border-red-200';
            importTableBody.innerHTML = `
                <tr>
                    <td colspan="4" class="px-4 py-8 text-center text-red-600">
                        ${error.message}
                    </td>
                </tr>
            `;
            showToast('Error de integración', error.message, 'error');
        }
    };
    
    function renderImportTable() {
        selectAllImport.checked = false;
        updateImportCounter();

        if (mockExternalUsers.length === 0) {
            importTableBody.innerHTML = `
                <tr>
                    <td colspan="4" class="px-4 py-8 text-center text-slate-500">
                        No hay usuarios para importar desde esta entidad.
                    </td>
                </tr>
            `;
            return;
        }
        
        importTableBody.innerHTML = mockExternalUsers.map(user => {
            const role = (user.role || '').toLowerCase();
            const roleLabel = role === 'alumno' ? 'Alumno' : role === 'colaborador' ? 'Colaborador' : 'Profesor';
            const roleClass = role === 'alumno'
                ? 'bg-emerald-100 text-emerald-700 border border-emerald-200'
                : role === 'colaborador'
                    ? 'bg-amber-100 text-amber-700 border border-amber-200'
                    : 'bg-orange-100 text-orange-700 border border-orange-200';
            return `
                <tr class="hover:bg-slate-50 transition-colors">
                    <td class="px-4 py-2 text-center border-b border-slate-100">
                        <input type="checkbox" value="${user.id}" class="import-checkbox rounded border-slate-300 text-primary w-4 h-4 cursor-pointer" onchange="updateImportCounter()">
                    </td>
                    <td class="px-4 py-2 border-b border-slate-100 text-slate-800 font-medium">${user.name}</td>
                    <td class="px-4 py-2 border-b border-slate-100">
                        <span class="inline-block px-2 text-xs font-medium rounded-full ${roleClass}">${roleLabel}</span>
                    </td>
                    <td class="px-4 py-2 border-b border-slate-100 text-slate-600 text-sm">${user.department || 'Sin área'}</td>
                </tr>
            `;
        }).join('');
    }
    
    window.toggleAllImportCheckboxes = (source) => {
        const checkboxes = document.querySelectorAll('.import-checkbox');
        checkboxes.forEach(cb => cb.checked = source.checked);
        updateImportCounter();
    };
    
    window.updateImportCounter = () => {
        const checkboxes = document.querySelectorAll('.import-checkbox:checked');
        const count = checkboxes.length;
        importCount.textContent = count;
        btnExecuteImport.disabled = count === 0;
        
        // Update select all state
        const allCheckboxes = document.querySelectorAll('.import-checkbox');
        if(allCheckboxes.length > 0) {
            selectAllImport.checked = (count === allCheckboxes.length);
        }
    };
    
    window.executeImportSelection = async () => {
        const selectedIds = Array.from(document.querySelectorAll('.import-checkbox:checked')).map(cb => cb.value);
        if(selectedIds.length === 0) return;
        if(!currentExternalEntity) {
            showToast('Entidad externa requerida', 'Primero consulta una entidad externa activa.', 'error');
            return;
        }
        if(currentExternalEntity.tipo === 'tesoreria') {
            showToast('Tesorería sincronizada', 'Tesorería valida pagos y multas; no genera usuarios para importar.', 'success');
            return;
        }
        
        const selectedUsers = mockExternalUsers.filter(u => selectedIds.includes(String(u.id)) || selectedIds.includes(String(u.externalId)));
        btnExecuteImport.disabled = true;

        let imported = 0;
        try {
            for (const u of selectedUsers) {
                const payload = {
                    name: u.name,
                    universityId: u.universityId,
                    email: u.email,
                    department: u.department,
                    role: u.role,
                    status: 'Activo',
                    password: 'temporal123',
                    entityExternalId: currentExternalEntity.id,
                    externalRecordId: u.id,
                };

                const response = await fetch('api/usuarios.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload),
                });
                const result = await response.json();
                if (!response.ok) throw new Error(result.error || `No se pudo importar ${u.name}`);
                imported += 1;
            }

            if (typeof syncFromAPI === 'function') await syncFromAPI();
            allUsers = getUsers();
            renderStats();
            filterData();
            closeImportModal();
            showToast('Usuarios importados', `Se importaron ${imported} usuarios desde ${currentExternalEntity.nombre}.`, 'success');
        } catch (error) {
            updateImportCounter();
            showToast('Error al importar', error.message, 'error');
        }
    };
    window.exportData = () => {
        showToast("Exportando...", "Generando archivo CSV.", "success");
    }

    function closeSuspendModal() {
        userToSuspendId = null;
        suspendReason.value = '';
        suspendModal.classList.add('hidden');
    }

    window.suspendUser = (id) => {
        if (!canSuspendUsers) return;
        const u = allUsers.find(x => String(x.id) === String(id));
        if (!u) return;
        userToSuspendId = id;
        suspendUserName.textContent = `${u.name} · ${u.universityId || u.email}`;
        suspendReason.value = '';
        suspendModal.classList.remove('hidden');
        suspendReason.focus();
        lucide.createIcons();
    };

    window.reactivateUser = async (id) => {
        if (!canSuspendUsers) return;
        const u = allUsers.find(x => String(x.id) === String(id));
        if (!u) return;

        try {
            if (USE_API) {
                await apiFetch(`usuarios?id=${id}`, 'PUT', { action: 'reactivate' });
                await reloadUsersFromSource();
            } else {
                u.status = "Activo";
                saveUsers(allUsers);
                renderStats();
                filterData();
            }
            showToast("Suspensión retirada", `${u.name} vuelve a estar activo.`, "success");
        } catch (error) {
            showToast("No se pudo reactivar", error.message, "error");
        }
    };

    document.getElementById('closeSuspendModalBtn').addEventListener('click', closeSuspendModal);
    document.getElementById('cancelSuspendBtn').addEventListener('click', closeSuspendModal);

    confirmSuspendBtn.addEventListener('click', async () => {
        const reason = suspendReason.value.trim();
        if (!reason) {
            showToast("Motivo requerido", "Escribe el motivo de la suspensión.", "error");
            suspendReason.focus();
            return;
        }

        const u = allUsers.find(x => String(x.id) === String(userToSuspendId));
        if (!u) return;

        confirmSuspendBtn.disabled = true;
        confirmSuspendBtn.classList.add('opacity-70', 'cursor-not-allowed');

        try {
            if (USE_API) {
                await apiFetch(`usuarios?id=${userToSuspendId}`, 'PUT', { action: 'suspend', reason });
                await reloadUsersFromSource();
            } else {
                u.status = "Suspendido";
                u.suspensionReason = reason;
                saveUsers(allUsers);
                renderStats();
                filterData();
            }
            closeSuspendModal();
            showToast("Usuario suspendido", `${u.name} ha sido suspendido.`, "success");
        } catch (error) {
            showToast("No se pudo suspender", error.message, "error");
        } finally {
            confirmSuspendBtn.disabled = false;
            confirmSuspendBtn.classList.remove('opacity-70', 'cursor-not-allowed');
        }
    });

});
