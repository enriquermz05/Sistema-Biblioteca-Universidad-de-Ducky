document.addEventListener('DOMContentLoaded', async () => { await window.__dbReady;
    if (!requirePermission('verReportes')) return;

    const books = getBooks();
    const users = getUsers();
    const loans = getLoans();

    // ─── Fecha del reporte ────────────────────────────────────────────
    const opts = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
    document.getElementById('reportDate').textContent =
        'Generado el ' + new Date().toLocaleDateString('es-MX', opts);

    // ─── Helpers ─────────────────────────────────────────────────────
    function loanStatus(loan) {
        if (loan.status === 'Devuelto') return 'Devuelto';
        return calcFine(loan.dueDate) > 0 ? 'Vencido' : 'Activo';
    }

    // ─── KPIs ────────────────────────────────────────────────────────
    const totalLoans   = loans.length;
    const activeLoans  = loans.filter(l => loanStatus(l) === 'Activo').length;
    const overdueLoans = loans.filter(l => loanStatus(l) === 'Vencido').length;
    const totalFines   = users.reduce((s, u) => s + (u.fines || 0), 0);

    document.getElementById('kpi-total-loans').textContent  = totalLoans;
    document.getElementById('kpi-active-loans').textContent = activeLoans;
    document.getElementById('kpi-overdue').textContent      = overdueLoans;
    document.getElementById('kpi-fines').textContent        = '$' + totalFines.toFixed(2);

    document.getElementById('kpi-books').textContent    = books.length;
    document.getElementById('kpi-available').textContent =
        books.filter(b => b.status === 'Disponible').length;
    document.getElementById('kpi-users').textContent     = users.length;
    document.getElementById('kpi-suspended').textContent =
        users.filter(u => u.status === 'Suspendido').length;

    // ─── Gráfica estado de préstamos ─────────────────────────────────
    const statusData = [
        { label: 'Activos',   count: activeLoans,                 color: 'bg-blue-500' },
        { label: 'Vencidos',  count: overdueLoans,                color: 'bg-red-500'  },
        { label: 'Devueltos', count: loans.filter(l => l.status === 'Devuelto').length, color: 'bg-green-500' },
    ];
    const maxStatus = Math.max(...statusData.map(s => s.count), 1);
    const chartEl = document.getElementById('loanStatusChart');
    chartEl.innerHTML = statusData.map(s => `
        <div class="flex items-center gap-4">
            <div class="w-24 text-sm text-slate-600 text-right flex-shrink-0">${s.label}</div>
            <div class="flex-1 bg-slate-100 rounded-full h-6 overflow-hidden">
                <div class="${s.color} h-6 rounded-full transition-all duration-700 flex items-center justify-end pr-2"
                     style="width: ${totalLoans > 0 ? (s.count / maxStatus * 100) : 0}%">
                    ${s.count > 0 ? `<span class="text-white text-xs font-bold">${s.count}</span>` : ''}
                </div>
            </div>
            <div class="w-12 text-sm font-semibold text-slate-700 flex-shrink-0">
                ${totalLoans > 0 ? Math.round(s.count / totalLoans * 100) : 0}%
            </div>
        </div>
    `).join('');

    // ─── Top libros más prestados ─────────────────────────────────────
    const bookLoanCount = {};
    loans.forEach(l => {
        bookLoanCount[l.bookId] = (bookLoanCount[l.bookId] || { title: l.bookTitle, count: 0 });
        bookLoanCount[l.bookId].count++;
    });
    const topBooksData = Object.values(bookLoanCount)
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

    const maxBookLoans = Math.max(...topBooksData.map(b => b.count), 1);
    document.getElementById('topBooks').innerHTML = topBooksData.length > 0
        ? topBooksData.map((b, i) => `
            <div class="flex items-center gap-3">
                <span class="w-6 h-6 rounded-full bg-primary text-white text-xs font-bold flex items-center justify-center flex-shrink-0">${i + 1}</span>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-slate-800 line-clamp-1">${b.title}</p>
                    <div class="mt-1 bg-slate-100 rounded-full h-2">
                        <div class="bg-primary h-2 rounded-full" style="width: ${b.count / maxBookLoans * 100}%"></div>
                    </div>
                </div>
                <span class="text-sm font-bold text-primary flex-shrink-0">${b.count}</span>
            </div>`)
          .join('')
        : '<p class="text-sm text-slate-400 text-center py-4">Sin datos de préstamos</p>';

    // ─── Top usuarios más activos ─────────────────────────────────────
    const userLoanCount = {};
    loans.forEach(l => {
        userLoanCount[l.userId] = (userLoanCount[l.userId] || { name: l.userName, count: 0 });
        userLoanCount[l.userId].count++;
    });
    const topUsersData = Object.values(userLoanCount)
        .sort((a, b) => b.count - a.count)
        .slice(0, 5);

    const maxUserLoans = Math.max(...topUsersData.map(u => u.count), 1);
    document.getElementById('topUsers').innerHTML = topUsersData.length > 0
        ? topUsersData.map((u, i) => `
            <div class="flex items-center gap-3">
                <span class="w-6 h-6 rounded-full bg-[#1E293B] text-white text-xs font-bold flex items-center justify-center flex-shrink-0">${i + 1}</span>
                <div class="flex-1 min-w-0">
                    <p class="text-sm font-medium text-slate-800 line-clamp-1">${u.name}</p>
                    <div class="mt-1 bg-slate-100 rounded-full h-2">
                        <div class="bg-[#1E293B] h-2 rounded-full" style="width: ${u.count / maxUserLoans * 100}%"></div>
                    </div>
                </div>
                <span class="text-sm font-bold text-slate-700 flex-shrink-0">${u.count}</span>
            </div>`)
          .join('')
        : '<p class="text-sm text-slate-400 text-center py-4">Sin datos</p>';

    // ─── Tabla multas pendientes ──────────────────────────────────────
    const usersWithFines = users
        .filter(u => u.fines > 0)
        .sort((a, b) => b.fines - a.fines);

    const finesBody = document.getElementById('finesTableBody');
    finesBody.innerHTML = usersWithFines.length > 0
        ? usersWithFines.map(u => `
            <tr class="hover:bg-slate-50">
                <td class="px-6 py-3">
                    <p class="font-medium text-slate-800">${u.name}</p>
                    <p class="text-xs text-slate-500">${u.email}</p>
                </td>
                <td class="px-6 py-3 text-slate-600">${u.role}</td>
                <td class="px-6 py-3 text-slate-600">${u.activeLoans}</td>
                <td class="px-6 py-3 font-bold text-red-600">$${u.fines.toFixed(2)} MXN</td>
            </tr>`).join('')
        : `<tr><td colspan="4" class="px-6 py-8 text-center text-slate-400 text-sm">
               Sin multas pendientes
           </td></tr>`;

    // ─── Inventario por categoría ─────────────────────────────────────
    const catMap = {};
    books.forEach(b => {
        if (!catMap[b.category]) catMap[b.category] = { total: 0, available: 0 };
        catMap[b.category].total++;
        if (b.status === 'Disponible') catMap[b.category].available++;
    });

    const catData = Object.entries(catMap).sort((a, b) => b[1].total - a[1].total);
    const maxCat  = Math.max(...catData.map(([, v]) => v.total), 1);

    document.getElementById('categoryChart').innerHTML = catData.map(([cat, val]) => `
        <div class="flex items-center gap-4">
            <div class="w-44 text-sm text-slate-600 text-right flex-shrink-0 truncate" title="${cat}">${cat}</div>
            <div class="flex-1 bg-slate-100 rounded-full h-5 overflow-hidden relative">
                <div class="bg-slate-400 h-5 rounded-full absolute top-0 left-0 transition-all"
                     style="width: ${val.total / maxCat * 100}%"></div>
                <div class="bg-green-500 h-5 rounded-full absolute top-0 left-0 transition-all"
                     style="width: ${val.available / maxCat * 100}%"></div>
            </div>
            <div class="w-24 text-xs text-slate-600 flex-shrink-0">
                <span class="font-semibold text-green-600">${val.available}</span>
                <span class="text-slate-400"> / ${val.total} disp.</span>
            </div>
        </div>
    `).join('');

    lucide.createIcons();

    // ─── Imprimir ─────────────────────────────────────────────────────
    window.printReport = () => window.print();
});
