document.addEventListener('DOMContentLoaded', async () => { await window.__dbReady;
    if (!requirePermission('crearUsuarios')) return;
    
    // Core Data
    const roles = ["Administrador", "Bibliotecario", "Profesor", "Alumno", "Colaborador"];
    
    // Ordered permission keys and labels
    const permissionMap = [
        { key: "crearUsuarios", label: "Crear Usuarios" },
        { key: "suspenderUsuarios", label: "Suspender Usuarios" },
        { key: "registrarPrestamo", label: "Registrar Préstamo" },
        { key: "registrarDevolucion", label: "Registrar Devolución" },
        { key: "renovarPrestamo", label: "Renovar Préstamo" },
        { key: "gestionarCatalogo", label: "Gestionar Catálogo" },
        { key: "buscarLibros", label: "Buscar Libros" },
        { key: "consultarCatalogo", label: "Consultar Catálogo" },
        { key: "verReportes", label: "Ver Reportes" }
    ];

    const defaultPermissions = DEFAULT_DUCKY_PERMISSIONS;

    // Application state
    let currentRole = "Administrador";
    let permissions = JSON.parse(localStorage.getItem('ducky_permissions'));
    if(!permissions) {
        permissions = JSON.parse(JSON.stringify(defaultPermissions)); // Deep copy
        localStorage.setItem('ducky_permissions', JSON.stringify(permissions));
    }
    let hasChanges = false;


    // Elements
    const heroRoleName = document.getElementById('heroRoleName');
    
    const matrixHeader = document.getElementById('matrixHeader');
    const matrixBody = document.getElementById('matrixBody');
    
    const mobileSelectedRoleBadge = document.getElementById('mobileSelectedRoleBadge');
    const mobilePermissionsList = document.getElementById('mobilePermissionsList');
    const mobileOtherRolesList = document.getElementById('mobileOtherRolesList');

    const unsavedChangesNotice = document.getElementById('unsavedChangesNotice');
    const saveChangesBtn = document.getElementById('saveChangesBtn');
    const resetPermsBtn = document.getElementById('resetPermsBtn');

    // UI Initializers
    function init() {
        renderMatrixHeader();
        updateView();
    }

    // Handlers
    window.selectRole = (role) => {
        currentRole = role;
        updateView();
    };

    window.togglePermission = (role, permissionKey) => {
        permissions[role][permissionKey] = !permissions[role][permissionKey];
        setChanges(true);
        updateView();
    };

    function setChanges(changed) {
        hasChanges = changed;
        if(changed) {
            unsavedChangesNotice.classList.remove('hidden');
            saveChangesBtn.className = "flex-1 px-4 md:px-6 py-2.5 md:py-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2 text-sm md:text-base bg-primary text-white hover:bg-primaryHover shadow-md";
            saveChangesBtn.disabled = false;
        } else {
            unsavedChangesNotice.classList.add('hidden');
            saveChangesBtn.className = "flex-1 px-4 md:px-6 py-2.5 md:py-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2 text-sm md:text-base bg-slate-200 text-slate-400 cursor-not-allowed";
            saveChangesBtn.disabled = true;
        }
    }

    saveChangesBtn.addEventListener('click', () => {
        if(!hasChanges) return;
        localStorage.setItem('ducky_permissions', JSON.stringify(permissions));
        setChanges(false);
        showToast("Cambios guardados", "Los permisos han sido actualizados exitosamente.", "success");
    });

    resetPermsBtn.addEventListener('click', () => {
        permissions = JSON.parse(JSON.stringify(defaultPermissions));
        localStorage.setItem('ducky_permissions', JSON.stringify(permissions));
        setChanges(false);
        updateView();
        showToast("Permisos restablecidos", "Se han restaurado los permisos predeterminados.", "success");
    });

    // Render Logic
    function getRoleBadgeColor(role) {
        switch (role) {
            case "Administrador": return "bg-red-100 text-red-800";
            case "Bibliotecario": return "bg-blue-100 text-blue-800";
            case "Profesor": return "bg-purple-100 text-purple-800";
            case "Alumno": return "bg-green-100 text-green-800";
            case "Colaborador": return "bg-orange-100 text-orange-800";
            default: return "bg-slate-100 text-slate-700";
        }
    }

    function renderMatrixHeader() {
        let thead = `<tr><th class="px-6 py-4 text-left text-sm font-semibold text-slate-700 sticky left-0 bg-slate-50 z-10">Rol</th>`;
        permissionMap.forEach(perm => {
            thead += `<th class="px-6 py-4 text-center text-sm font-semibold text-slate-700 whitespace-nowrap">${perm.label}</th>`;
        });
        thead += `</tr>`;
        matrixHeader.innerHTML = thead;
    }

    function renderMatrixBody() {
        matrixBody.innerHTML = roles.map(role => {
            const isSelected = role === currentRole;
            const bgClass = isSelected ? "bg-orange-50" : "hover:bg-slate-50";
            
            let row = `<tr onclick="selectRole('${role}')" class="transition-colors cursor-pointer ${bgClass}">
                <td class="px-6 py-4 sticky left-0 bg-inherit z-10 border-r border-slate-100">
                    <span class="px-3 py-1 rounded-full text-sm font-medium ${getRoleBadgeColor(role)}">${role}</span>
                </td>`;
            
            permissionMap.forEach(perm => {
                const isChecked = permissions[role][perm.key];
                // Tailwind-based pure UI toggle switch
                const toggleBg = isChecked ? "bg-primary" : "bg-slate-200";
                const translate = isChecked ? "translate-x-5" : "translate-x-1";
                
                row += `
                    <td class="px-6 py-4 text-center">
                        <div class="flex justify-center">
                            <button onclick="togglePermission('${role}', '${perm.key}')" type="button" class="${toggleBg} relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none">
                                <span class="${translate} pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out"></span>
                            </button>
                        </div>
                    </td>
                `;
            });
            return row + `</tr>`;
        }).join('');
    }

    function renderMobileViews() {
        mobileSelectedRoleBadge.textContent = currentRole;
        mobileSelectedRoleBadge.className = `px-3 py-1 rounded-full text-sm font-medium ${getRoleBadgeColor(currentRole)}`;
        
        // Mobile Current Role Perms
        mobilePermissionsList.innerHTML = permissionMap.map(perm => {
            const isChecked = permissions[currentRole][perm.key];
            const toggleBg = isChecked ? "bg-primary" : "bg-slate-200";
            const translate = isChecked ? "translate-x-5" : "translate-x-1";
            const icon = isChecked 
                ? `<i data-lucide="check-circle" class="w-5 h-5 text-green-600 flex-shrink-0"></i>`
                : `<i data-lucide="x-circle" class="w-5 h-5 text-slate-300 flex-shrink-0"></i>`;
                
            return `
                <div class="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <div class="flex items-center gap-3">
                        ${icon}
                        <span class="text-sm md:text-base text-slate-700">${perm.label}</span>
                    </div>
                    <button onclick="togglePermission('${currentRole}', '${perm.key}')" type="button" class="${toggleBg} relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out">
                        <span class="${translate} pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow transition duration-200 ease-in-out"></span>
                    </button>
                </div>
            `;
        }).join('');

        // Mobile Other Roles Summary
        const otherRoles = roles.filter(r => r !== currentRole);
        mobileOtherRolesList.innerHTML = otherRoles.map(role => {
            const activeCount = Object.values(permissions[role]).filter(Boolean).length;
            return `
                <button onclick="selectRole('${role}')" class="w-full flex items-center justify-between p-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors">
                    <span class="px-3 py-1 rounded-full text-sm font-medium ${getRoleBadgeColor(role)}">${role}</span>
                    <span class="text-xs text-slate-500">${activeCount} permisos activos</span>
                </button>
            `;
        }).join('');
    }

    function renderStats() {
        const activeCount = Object.values(permissions[currentRole]).filter(Boolean).length;
        const totalPerms = permissionMap.length;
        
        document.getElementById('stat-active-perms').textContent = activeCount;
        document.getElementById('stat-inactive-perms').textContent = totalPerms - activeCount;
        document.getElementById('stat-total-roles').textContent = roles.length;
        document.getElementById('stat-system-perms').textContent = totalPerms;
    }

    function updateView() {
        heroRoleName.textContent = currentRole;
        renderMatrixBody();
        renderMobileViews();
        renderStats();
        lucide.createIcons();
    }

    // Start
    init();
});
