document.addEventListener('DOMContentLoaded', async () => { await window.__dbReady;
    if (!requirePermission('consultarCatalogo')) return;
    const allBooks = getBooks();
    
    // Elements
    const heroTotalBooks = document.getElementById('hero-total-books');
    const searchInput = document.getElementById('searchInput');
    const searchForm = document.getElementById('searchForm');
    
    const searchResultsGrid = document.getElementById('searchResultsGrid');
    const searchEmptyState = document.getElementById('searchEmptyState');
    
    // Computed Values
    const popularBooks = allBooks.filter(book => book.status === "Disponible").slice(0, 6);
    const categoriesSet = new Set(allBooks.map(book => book.category));
    const categories = Array.from(categoriesSet);
    let currentResults = [];
    
    // Initialization
    function init() {
        heroTotalBooks.textContent = allBooks.length;
        initSidebarCategories();
        window.applyFiltersAndSearch();
    }

    // Render Helpers
    function renderBookCard(book) {
        const isAvailable = book.status === "Disponible";
        const statusClass = isAvailable ? "bg-green-100 text-green-800"
                          : book.status === "Prestado" ? "bg-yellow-100 text-yellow-800"
                          : book.status === "Perdido"  ? "bg-red-100 text-red-800"
                          : book.status === "Dañado"   ? "bg-orange-100 text-orange-800"
                          : "bg-gray-100 text-gray-800";
                          
        return `
            <div onclick="window.location.href='book-details.html?id=${book.id}'" class="bg-white rounded-lg shadow-sm border border-slate-200 hover:shadow-lg transition-shadow overflow-hidden group cursor-pointer">
                <div class="h-40 md:h-48 bg-gradient-to-br from-[#F97316] to-[#EA580C] flex items-center justify-center">
                    <i data-lucide="book-open" class="w-16 md:w-20 h-16 md:h-20 text-white opacity-50"></i>
                </div>
                <div class="p-4 md:p-5">
                    <h3 class="font-semibold text-base md:text-lg text-slate-800 mb-2 line-clamp-2 group-hover:text-primary transition-colors">
                        ${book.title}
                    </h3>
                    <div class="flex items-center gap-2 text-sm text-slate-600 mb-3">
                        <i data-lucide="user" class="w-4 h-4 flex-shrink-0"></i>
                        <span class="line-clamp-1">${book.author}</span>
                    </div>
                    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2">
                        <span class="px-3 py-1 rounded-full text-xs font-medium inline-block w-max ${statusClass}">
                            ${book.status}
                        </span>
                        ${isAvailable ? `<span class="text-xs text-slate-500">${book.availableCopies} de ${book.totalCopies} disp.</span>` : ''}
                    </div>
                </div>
            </div>
        `;
    }

    function renderPopularBooks() {
        const grid = document.getElementById('popularBooksGrid');
        grid.innerHTML = popularBooks.map(renderBookCard).join('');
    }

    function renderCategories() {
        const grid = document.getElementById('categoriesGrid');
        grid.innerHTML = categories.slice(0, 8).map(cat => {
            const count = allBooks.filter(b => b.category === cat).length;
            return `
                <button onclick="quickFilter('category', '${cat}')" class="bg-white rounded-lg shadow-sm border border-slate-200 p-4 md:p-6 hover:shadow-md hover:border-primary transition-all text-left">
                    <div class="flex items-center gap-3 mb-2">
                        <div class="w-10 h-10 bg-orange-50 rounded-lg flex items-center justify-center flex-shrink-0">
                            <i data-lucide="book-open" class="w-6 h-6 text-primary"></i>
                        </div>
                    </div>
                    <h3 class="font-semibold text-slate-800 mb-1 text-sm md:text-base">${cat}</h3>
                    <p class="text-xs md:text-sm text-slate-500">${count} libros</p>
                </button>
            `;
        }).join('');
    }

    function renderStats() {
        document.getElementById('stat-total').textContent = allBooks.length;
        document.getElementById('stat-available').textContent = allBooks.filter(b => b.status === "Disponible").length;
        document.getElementById('stat-borrowed').textContent = allBooks.filter(b => b.status === "Prestado").length;
        document.getElementById('stat-categories').textContent = categories.length;
    }

    let activeFilters = {
        q: '',
        category: null,
        status: null,
        year: null
    };
    
    // UI Helpers for Active Filters
    function updateActiveFiltersUI() {
        const container = document.getElementById('activeFiltersContainer');
        const list = document.getElementById('activeFiltersList');
        list.innerHTML = '';
        
        let hasFilters = false;
        
        if(activeFilters.q) {
            hasFilters = true;
            list.innerHTML += `<span class="px-2 md:px-3 py-1 bg-primary text-white rounded-full text-xs md:text-sm flex items-center gap-2">
                Búsqueda: "${activeFilters.q}"
                <button onclick="removeFilter('q')"><i data-lucide="x" class="w-3 h-3 md:w-4 md:h-4"></i></button>
            </span>`;
        }
        if(activeFilters.category) {
            hasFilters = true;
            list.innerHTML += `<span class="px-2 md:px-3 py-1 bg-primary text-white rounded-full text-xs md:text-sm flex items-center gap-2">
                Categoría: ${activeFilters.category}
                <button onclick="removeFilter('category')"><i data-lucide="x" class="w-3 h-3 md:w-4 md:h-4"></i></button>
            </span>`;
        }
        if(activeFilters.status) {
            hasFilters = true;
            list.innerHTML += `<span class="px-2 md:px-3 py-1 bg-primary text-white rounded-full text-xs md:text-sm flex items-center gap-2">
                Estado: ${activeFilters.status}
                <button onclick="removeFilter('status')"><i data-lucide="x" class="w-3 h-3 md:w-4 md:h-4"></i></button>
            </span>`;
        }
        if(activeFilters.year) {
            hasFilters = true;
            list.innerHTML += `<span class="px-2 md:px-3 py-1 bg-primary text-white rounded-full text-xs md:text-sm flex items-center gap-2">
                Año ≥ ${activeFilters.year}
                <button onclick="removeFilter('year')"><i data-lucide="x" class="w-3 h-3 md:w-4 md:h-4"></i></button>
            </span>`;
        }
        
        if(hasFilters) {
            container.classList.remove('hidden');
        } else {
            container.classList.add('hidden');
        }
        lucide.createIcons();
    }

    function updateSidebarHighlights() {
        // Categories
        document.querySelectorAll('.sidebar-cat-btn').forEach(btn => {
            if(btn.dataset.val === activeFilters.category) {
                btn.classList.add('bg-primary', 'text-white');
                btn.classList.remove('hover:bg-slate-100', 'text-slate-700');
            } else {
                btn.classList.remove('bg-primary', 'text-white');
                btn.classList.add('hover:bg-slate-100', 'text-slate-700');
            }
        });
        // Status
        document.querySelectorAll('.sidebar-status-btn').forEach(btn => {
            if(btn.dataset.val === activeFilters.status) {
                btn.classList.add('bg-primary', 'text-white');
                btn.classList.remove('hover:bg-slate-100', 'text-slate-700');
            } else {
                btn.classList.remove('bg-primary', 'text-white');
                btn.classList.add('hover:bg-slate-100', 'text-slate-700');
            }
        });
        // Year
        document.querySelectorAll('.sidebar-year-btn').forEach(btn => {
            if(btn.dataset.val === activeFilters.year) {
                btn.classList.add('bg-primary', 'text-white');
                btn.classList.remove('hover:bg-slate-100', 'text-slate-700');
            } else {
                btn.classList.remove('bg-primary', 'text-white');
                btn.classList.add('hover:bg-slate-100', 'text-slate-700');
            }
        });
    }

    // Build sidebar categories dynamically
    function initSidebarCategories() {
        const catContainer = document.getElementById('sidebarFilterCategories');
        catContainer.innerHTML = categories.map(cat => {
            const count = allBooks.filter(b => b.category === cat).length;
            return `
                <button onclick="toggleFilter('category', '${cat}')" class="sidebar-cat-btn w-full text-left px-2 md:px-3 py-2 rounded-lg text-xs md:text-sm transition-colors hover:bg-slate-100 text-slate-700" data-val="${cat}">
                    <span class="line-clamp-2">${cat} <span class="text-xs ml-1 opacity-70">(${count})</span></span>
                </button>
            `;
        }).join('');
    }

    window.toggleSidebarFilters = () => {
        const sidebar = document.getElementById('filtersSidebar');
        const overlay = document.getElementById('filtersOverlay');
        const isHidden = sidebar.classList.contains('translate-x-full');
        
        if (isHidden) {
            sidebar.classList.remove('translate-x-full');
            sidebar.classList.add('translate-x-0');
            overlay.classList.remove('hidden');
        } else {
            sidebar.classList.add('translate-x-full');
            sidebar.classList.remove('translate-x-0');
            overlay.classList.add('hidden');
        }
    };

    window.toggleFilter = (key, value) => {
        if(activeFilters[key] === value) {
            activeFilters[key] = null; // Uncheck
        } else {
            activeFilters[key] = value;
        }
        applyFiltersAndSearch();
    };

    window.removeFilter = (key) => {
        if(key === 'q') searchInput.value = '';
        activeFilters[key] = null;
        applyFiltersAndSearch();
    };

    window.applyFiltersAndSearch = () => {
        let results = [...allBooks];
        
        // 1. Search Query
        if(activeFilters.q) {
            const lowerQ = activeFilters.q.toLowerCase();
            results = results.filter(b => 
                b.title.toLowerCase().includes(lowerQ) || 
                b.author.toLowerCase().includes(lowerQ) || 
                b.category.toLowerCase().includes(lowerQ) ||
                (b.isbn && b.isbn.includes(lowerQ))
            );
        }
        
        // 2. Category
        if(activeFilters.category) {
            results = results.filter(b => b.category === activeFilters.category);
        }
        
        // 3. Status
        if(activeFilters.status) {
            results = results.filter(b => b.status === activeFilters.status);
        }
        
        // 4. Year
        if(activeFilters.year) {
            const minYear = parseInt(activeFilters.year);
            results = results.filter(b => parseInt(b.year || b.publicationYear || 0) >= minYear);
        }
        
        // 5. Sorting
        const sortMode = document.getElementById('sortSelect').value;
        results.sort((a, b) => {
            switch(sortMode) {
                case 'title': return a.title.localeCompare(b.title);
                case 'author': return a.author.localeCompare(b.author);
                case 'year': 
                    const yearA = parseInt(a.year || a.publicationYear || 0);
                    const yearB = parseInt(b.year || b.publicationYear || 0);
                    return yearB - yearA;
                case 'availability':
                    if (a.status === "Disponible" && b.status !== "Disponible") return -1;
                    if (a.status !== "Disponible" && b.status === "Disponible") return 1;
                    return 0;
                default: return 0;
            }
        });

        currentResults = results;

        // Update UI
        updateActiveFiltersUI();
        updateSidebarHighlights();
        document.getElementById('resultsCount').textContent = results.length;

        if(results.length > 0) {
            searchResultsGrid.classList.remove('hidden');
            searchEmptyState.classList.add('hidden');
            document.getElementById('printBtn').removeAttribute('disabled');
            searchResultsGrid.innerHTML = results.map(renderBookCard).join('');
        } else {
            searchResultsGrid.classList.add('hidden');
            searchEmptyState.classList.remove('hidden');
            document.getElementById('printBtn').setAttribute('disabled', 'true');
        }
        lucide.createIcons();
    };

    searchForm.addEventListener('submit', (e) => {
        e.preventDefault();
        activeFilters.q = searchInput.value.trim();
        applyFiltersAndSearch();
    });

    searchInput.addEventListener('input', (e) => {
        activeFilters.q = e.target.value.trim();
        applyFiltersAndSearch();
    });

    window.quickFilter = (type, value) => {
        searchInput.value = '';
        activeFilters = { q: '', category: null, status: null, year: null };
        activeFilters[type] = value;
        applyFiltersAndSearch();
    };

    window.clearSearch = () => {
        searchInput.value = '';
        activeFilters = { q: '', category: null, status: null, year: null };
        applyFiltersAndSearch();
    };

    window.showAllBooks = () => {
        searchInput.value = '';
        activeFilters = { q: '', category: null, status: null, year: null };
        applyFiltersAndSearch();
    };

    // Print Logic
    window.openPrintModal = () => {
        if(currentResults.length === 0) return;
        
        const tbody = document.getElementById('printTableBody');
        tbody.innerHTML = currentResults.map((book, index) => {
            const isAvailable = book.status === "Disponible";
            const statusClass = isAvailable ? "bg-green-100 text-green-800" 
                              : book.status === "Prestado" ? "bg-yellow-100 text-yellow-800" 
                              : book.status === "Dañado" ? "bg-red-100 text-red-800"
                              : "bg-gray-100 text-gray-800";
                              
            const bg = index % 2 === 0 ? 'bg-white' : 'bg-slate-50/50';

            return `
                <tr class="border-b border-slate-100 ${bg}">
                    <td class="px-3 py-2 text-slate-700">${book.title}</td>
                    <td class="px-3 py-2 text-slate-600">${book.author}</td>
                    <td class="px-3 py-2 text-slate-600">${book.publisher || 'N/A'}</td>
                    <td class="px-3 py-2 text-slate-600">${book.category}</td>
                    <td class="px-3 py-2">
                        <span class="px-2 py-0.5 rounded-full text-xs font-medium ${statusClass}">
                            ${book.status}
                        </span>
                    </td>
                </tr>
            `;
        }).join('');

        document.getElementById('printTotalResults').textContent = currentResults.length;
        
        const options = { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' };
        document.getElementById('printDate').textContent = "Generado el: " + new Date().toLocaleDateString('es-MX', options);

        document.getElementById('printModal').classList.remove('hidden');
        lucide.createIcons();
    };

    window.closePrintModal = () => {
        document.getElementById('printModal').classList.add('hidden');
    };

    window.executePrint = () => {
        document.getElementById('printModal').classList.add('hidden');
        
        // Use a slight delay to ensure the modal closes visually before printing
        setTimeout(() => {
            // Only print what we want. We can hide UI elements during print using CSS, 
            // but the tailwind classes already handle standard print hiding well.
            // A more robust approach would be to open a new window and write table HTML to it.
            
            const printWindow = window.open('', '_blank');
            printWindow.document.write(`
                <html>
                    <head>
                        <title>Imprimir Catálogo</title>
                        <script src="https://cdn.tailwindcss.com"></script>
                        <style>
                            @media print {
                                body { p { margin: 0; } }
                            }
                        </style>
                    </head>
                    <body class="p-8 font-sans">
                        <h1 class="text-2xl font-bold mb-2">Catálogo de Libros - Resultados de Búsqueda</h1>
                        <p class="text-gray-500 mb-6 font-medium">Generado el: ${new Date().toLocaleDateString('es-MX')}</p>
                        
                        <table class="w-full text-left text-sm border-collapse">
                            <thead>
                                <tr class="bg-gray-100 border-b-2 border-gray-300">
                                    <th class="p-3">Título</th>
                                    <th class="p-3">Autor</th>
                                    <th class="p-3">Categoría</th>
                                    <th class="p-3">Disponibilidad</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${currentResults.map(book => `
                                    <tr class="border-b border-gray-200">
                                        <td class="p-3 font-medium text-gray-800">${book.title}</td>
                                        <td class="p-3 text-gray-600">${book.author}</td>
                                        <td class="p-3 text-gray-600">${book.category}</td>
                                        <td class="p-3 text-gray-800">${book.status}</td>
                                    </tr>
                                `).join('')}
                            </tbody>
                        </table>
                        
                        <div class="mt-8 text-gray-500 text-sm">
                            <p><strong>Total de resultados:</strong> ${currentResults.length}</p>
                        </div>
                        
                        <script>
                            window.onload = function() {
                                window.print();
                                window.onafterprint = function() {
                                    window.close();
                                }
                            }
                        </script>
                    </body>
                </html>
            `);
            printWindow.document.close();
        }, 100);
    };

    // Load
    init();
});
