// ============================================================
//  MODO DE BASE DE DATOS
//  Cambia USE_API a true y configura API_BASE_URL para
//  conectar al backend PHP en lugar de localStorage.
// ============================================================
const USE_API = true;
const API_BASE_URL = 'api'; // ruta relativa a los archivos PHP

// ============================================================
//  DATOS MOCK (usados cuando USE_API = false)
// ============================================================

const mockBooks = [
  {
    id: "1",
    title: "Sistemas de Bases de Datos: El Libro Completo",
    author: "Hector Garcia-Molina, Jeffrey D. Ullman",
    isbn: "978-0131873254",
    category: "Ciencias de la Computación",
    year: 2008,
    publisher: "Pearson",
    pages: 1248,
    language: "Español",
    status: "Disponible",
    condition: "Perfecto",
    coverImage: "database-systems-book",
    description: "Una introducción completa a los sistemas de bases de datos.",
    location: "Sección A - Estante 15",
    totalCopies: 5,
    availableCopies: 2,
    replacementPrice: 850.00,
  },
  {
    id: "2",
    title: "Inteligencia Artificial: Un Enfoque Moderno",
    author: "Stuart Russell, Peter Norvig",
    isbn: "978-0136042594",
    category: "Ciencias de la Computación",
    year: 2020,
    publisher: "Pearson",
    pages: 1152,
    language: "Español",
    status: "Disponible",
    condition: "Perfecto",
    coverImage: "ai-modern-approach",
    description: "El texto líder en el campo de la inteligencia artificial.",
    location: "Sección A - Estante 18",
    totalCopies: 4,
    availableCopies: 3,
    replacementPrice: 920.00,
  },
  {
    id: "3",
    title: "Código Limpio",
    author: "Robert C. Martin",
    isbn: "978-0132350884",
    category: "Ciencias de la Computación",
    year: 2008,
    publisher: "Prentice Hall",
    pages: 464,
    language: "Español",
    status: "Prestado",
    condition: "Perfecto",
    coverImage: "clean-code",
    description: "Manual de estilo para el desarrollo ágil de software.",
    location: "Sección A - Estante 12",
    totalCopies: 6,
    availableCopies: 0,
    replacementPrice: 450.00,
  },
  {
    id: "4",
    title: "Introducción a Algoritmos",
    author: "Thomas H. Cormen, Charles E. Leiserson",
    isbn: "978-0262033848",
    category: "Ciencias de la Computación",
    year: 2009,
    publisher: "MIT Press",
    pages: 1312,
    language: "Español",
    status: "Disponible",
    condition: "Perfecto",
    coverImage: "algorithms-book",
    description: "Texto completo sobre algoritmos y estructuras de datos.",
    location: "Sección A - Estante 10",
    totalCopies: 8,
    availableCopies: 5,
    replacementPrice: 980.00,
  },
  {
    id: "5",
    title: "Matemáticas Avanzadas para Ingeniería",
    author: "Erwin Kreyszig",
    isbn: "978-0470458365",
    category: "Matemáticas",
    year: 2011,
    publisher: "Wiley",
    pages: 1264,
    language: "Español",
    status: "Disponible",
    condition: "Perfecto",
    coverImage: "advanced-engineering-math",
    description: "Texto completo de matemáticas para ingeniería.",
    location: "Sección B - Estante 5",
    totalCopies: 10,
    availableCopies: 7,
    replacementPrice: 750.00,
  }
];

const mockUsers = [
  {
    id: "1",
    name: "Sarah Johnson",
    universityId: "EST-2024-001",
    role: "Alumno",
    status: "Activo",
    activeLoans: 3,
    fines: 465.50,
    email: "sarah.johnson@universidad.edu",
    phone: "+1 (555) 123-4567",
    department: "Ciencias de la Computación",
    joinedDate: "15/01/2024",
    loans: [
      { id: "L001", bookTitle: "Sistemas de Bases de Datos: El Libro Completo", borrowDate: "20/02/2026", dueDate: "20/03/2026", status: "Activo" },
      { id: "L002", bookTitle: "Inteligencia Artificial: Un Enfoque Moderno", borrowDate: "25/02/2026", dueDate: "25/03/2026", status: "Activo" },
      { id: "L003", bookTitle: "Código Limpio", borrowDate: "01/03/2026", dueDate: "31/03/2026", status: "Activo" },
    ],
    fineHistory: [
      { id: "F001", amount: 15.50, reason: "Devolución tardía - Introducción a Algoritmos", date: "15/02/2026", status: "Pendiente" },
    ],
    bookFines: [
      { id: "BF001", bookTitle: "Código Limpio", reason: "Libro perdido", replacementPrice: 450.00, status: "Pendiente" },
    ],
  },
  {
    id: "2",
    name: "Michael Chen",
    universityId: "PRF-2022-045",
    role: "Profesor",
    status: "Activo",
    activeLoans: 1,
    fines: 0,
    email: "m.chen@universidad.edu",
    phone: "+1 (555) 234-5678",
    department: "Ingeniería",
    joinedDate: "01/09/2022",
    loans: [
      { id: "L004", bookTitle: "Matemáticas Avanzadas para Ingeniería", borrowDate: "10/01/2026", dueDate: "10/04/2026", status: "Activo" },
    ],
    fineHistory: [],
    bookFines: [],
  },
  {
    id: "3",
    name: "Emma Williams",
    universityId: "BIB-2023-012",
    role: "Bibliotecario",
    status: "Activo",
    activeLoans: 0,
    fines: 0,
    email: "e.williams@universidad.edu",
    phone: "+1 (555) 345-6789",
    department: "Biblioteca",
    joinedDate: "15/03/2023",
    loans: [],
    fineHistory: [],
    bookFines: [],
  }
];

const mockLoans = [
  {
    id: "L001",
    bookId: "1",
    bookTitle: "Sistemas de Bases de Datos: El Libro Completo",
    bookIsbn: "978-0131873254",
    userId: "1",
    userName: "Sarah Johnson",
    userEmail: "sarah.johnson@universidad.edu",
    borrowDate: "20/02/2026",
    dueDate: "20/03/2026",
    status: "Vencido",
    returnDate: null,
    fineAmount: 0
  },
  {
    id: "L002",
    bookId: "2",
    bookTitle: "Inteligencia Artificial: Un Enfoque Moderno",
    bookIsbn: "978-0136042594",
    userId: "1",
    userName: "Sarah Johnson",
    userEmail: "sarah.johnson@universidad.edu",
    borrowDate: "25/02/2026",
    dueDate: "25/03/2026",
    status: "Vencido",
    returnDate: null,
    fineAmount: 0
  },
  {
    id: "L003",
    bookId: "3",
    bookTitle: "Código Limpio",
    bookIsbn: "978-0132350884",
    userId: "1",
    userName: "Sarah Johnson",
    userEmail: "sarah.johnson@universidad.edu",
    borrowDate: "01/03/2026",
    dueDate: "31/03/2026",
    status: "Vencido",
    returnDate: null,
    fineAmount: 0
  },
  {
    id: "L004",
    bookId: "5",
    bookTitle: "Matemáticas Avanzadas para Ingeniería",
    bookIsbn: "978-0470458365",
    userId: "2",
    userName: "Michael Chen",
    userEmail: "m.chen@universidad.edu",
    borrowDate: "10/01/2026",
    dueDate: "10/04/2026",
    status: "Activo",
    returnDate: null,
    fineAmount: 0
  }
];


function toNumber(value, fallback = 0) {
  const number = Number(value);
  return Number.isFinite(number) ? number : fallback;
}

function normalizeApiBook(book) {
  return {
    ...book,
    year: toNumber(book.year, null),
    pages: toNumber(book.pages),
    totalCopies: toNumber(book.totalCopies),
    availableCopies: toNumber(book.availableCopies),
    replacementPrice: toNumber(book.replacementPrice),
  };
}

function normalizeApiUser(user) {
  return {
    ...user,
    activeLoans: toNumber(user.activeLoans),
    fines: toNumber(user.fines),
    loans: Array.isArray(user.loans) ? user.loans : [],
    fineHistory: Array.isArray(user.fineHistory)
      ? user.fineHistory.map(fine => ({ ...fine, amount: toNumber(fine.amount) }))
      : [],
    bookFines: Array.isArray(user.bookFines)
      ? user.bookFines.map(fine => ({ ...fine, replacementPrice: toNumber(fine.replacementPrice) }))
      : [],
  };
}

function normalizeApiLoan(loan) {
  return {
    ...loan,
    fineAmount: toNumber(loan.fineAmount),
    renewals: toNumber(loan.renewals),
  };
}

// ============================================================
//  SINCRONIZACIÓN DESDE API → localStorage
//  Cuando USE_API=true, descarga los datos de MySQL y los
//  guarda en localStorage para que el resto del código funcione.
// ============================================================
async function syncFromAPI() {
  try {
    const [books, users, loans] = await Promise.all([
      fetch(`${API_BASE_URL}/libros.php`).then(r => r.json()),
      fetch(`${API_BASE_URL}/usuarios.php`).then(r => r.json()),
      fetch(`${API_BASE_URL}/prestamos.php`).then(r => r.json()),
    ]);
    if (Array.isArray(books)) localStorage.setItem('ducky_books', JSON.stringify(books.map(normalizeApiBook)));
    if (Array.isArray(users)) localStorage.setItem('ducky_users', JSON.stringify(users.map(normalizeApiUser)));
    if (Array.isArray(loans)) localStorage.setItem('ducky_loans', JSON.stringify(loans.map(normalizeApiLoan)));
    console.log('[DB] Datos sincronizados desde MySQL ✓');
  } catch (e) {
    console.warn('[DB] API no disponible, usando datos locales:', e.message);
  }
}

// Promesa global: las páginas la esperan antes de renderizar
window.__dbReady = USE_API ? syncFromAPI() : Promise.resolve();

// Exponer syncFromAPI para que los módulos puedan refrescar después de escribir
window.syncFromAPI = syncFromAPI;

// ============================================================
//  INICIALIZACIÓN localStorage (solo cuando USE_API=false)
// ============================================================
function initDB() {
  if (USE_API) return; // con API los datos vienen de MySQL
  if (!localStorage.getItem("ducky_books")) {
    localStorage.setItem("ducky_books", JSON.stringify(mockBooks));
  }
  if (!localStorage.getItem("ducky_users")) {
    localStorage.setItem("ducky_users", JSON.stringify(mockUsers));
  }
  if (!localStorage.getItem("ducky_loans")) {
    localStorage.setItem("ducky_loans", JSON.stringify(mockLoans));
  }
}

// ============================================================
//  FUNCIONES DE ACCESO A DATOS (localStorage)
// ============================================================
function getBooks() {
  return JSON.parse(localStorage.getItem("ducky_books")) || [];
}
function saveBooks(books) {
  localStorage.setItem("ducky_books", JSON.stringify(books));
}

function getUsers() {
  return JSON.parse(localStorage.getItem("ducky_users")) || [];
}
function saveUsers(users) {
  localStorage.setItem("ducky_users", JSON.stringify(users));
}

function getLoans() {
  return JSON.parse(localStorage.getItem("ducky_loans")) || [];
}
function saveLoans(loans) {
  localStorage.setItem("ducky_loans", JSON.stringify(loans));
}

// ============================================================
//  FUNCIONES API (cuando USE_API = true)
//  Estas funciones reemplazan las de localStorage al conectar
//  al backend PHP+MySQL.
//
//  Uso:
//    const books = await apiFetch('libros');
//    await apiFetch('libros', 'POST', newBook);
//    await apiFetch('libros?id=1', 'PUT', updatedBook);
//    await apiFetch('libros?id=1', 'DELETE');
// ============================================================
async function apiFetch(endpoint, method = 'GET', body = null) {
  const [path, query] = String(endpoint).split('?');
  const url = `${API_BASE_URL}/${path}.php${query ? `?${query}` : ''}`;
  const options = {
    method,
    headers: { 'Content-Type': 'application/json' }
  };
  if (body) options.body = JSON.stringify(body);
  const res = await fetch(url, options);
  if (!res.ok) {
    let msg = `Error ${res.status}: ${res.statusText}`;
    try { const d = await res.json(); if (d?.error) msg = d.error; } catch (_) {}
    throw new Error(msg);
  }
  return res.json();
}


// ============================================================
//  SESIÓN Y PERMISOS
// ============================================================
const SESSION_KEY = 'ducky_session';
const PERMISSIONS_KEY = 'ducky_permissions';

const DEFAULT_DUCKY_PERMISSIONS = {
  Administrador: { crearUsuarios: true, suspenderUsuarios: true, registrarPrestamo: true, registrarDevolucion: true, renovarPrestamo: true, gestionarCatalogo: true, buscarLibros: true, consultarCatalogo: true, verReportes: true },
  Bibliotecario: { crearUsuarios: false, suspenderUsuarios: false, registrarPrestamo: true, registrarDevolucion: true, renovarPrestamo: true, gestionarCatalogo: true, buscarLibros: true, consultarCatalogo: true, verReportes: true },
  Profesor: { crearUsuarios: false, suspenderUsuarios: false, registrarPrestamo: false, registrarDevolucion: false, renovarPrestamo: false, gestionarCatalogo: false, buscarLibros: true, consultarCatalogo: true, verReportes: false },
  Alumno: { crearUsuarios: false, suspenderUsuarios: false, registrarPrestamo: false, registrarDevolucion: false, renovarPrestamo: false, gestionarCatalogo: false, buscarLibros: true, consultarCatalogo: true, verReportes: false },
  Colaborador: { crearUsuarios: false, suspenderUsuarios: false, registrarPrestamo: false, registrarDevolucion: false, renovarPrestamo: false, gestionarCatalogo: false, buscarLibros: true, consultarCatalogo: true, verReportes: false },
};

function normalizeRoleName(role) {
  const key = String(role || '').trim().toLowerCase();
  const map = {
    admin: 'Administrador',
    administrador: 'Administrador',
    bibliotecario: 'Bibliotecario',
    profesor: 'Profesor',
    alumno: 'Alumno',
    estudiante: 'Alumno',
    colaborador: 'Colaborador',
  };
  return map[key] || (key ? key.charAt(0).toUpperCase() + key.slice(1) : 'Alumno');
}

function ensurePermissionsStore() {
  const saved = JSON.parse(localStorage.getItem(PERMISSIONS_KEY) || 'null') || {};
  const merged = JSON.parse(JSON.stringify(DEFAULT_DUCKY_PERMISSIONS));
  Object.keys(saved).forEach(role => {
    const normalizedRole = normalizeRoleName(role);
    merged[normalizedRole] = { ...(merged[normalizedRole] || {}), ...saved[role] };
  });
  localStorage.setItem(PERMISSIONS_KEY, JSON.stringify(merged));
  return merged;
}

function saveSession(user, permissions = []) {
  const normalizedUser = { ...user, role: normalizeRoleName(user.role), status: user.status || 'Activo' };
  localStorage.setItem(SESSION_KEY, JSON.stringify({ user: normalizedUser, dbPermissions: permissions }));
}

function getSession() {
  return JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
}

function getCurrentUser() {
  return getSession()?.user || null;
}

function getCurrentRole() {
  return normalizeRoleName(getCurrentUser()?.role);
}

function getCurrentPermissions() {
  const role = getCurrentRole();
  const matrix = ensurePermissionsStore();
  return matrix[role] || {};
}

function hasPermission(permissionKey) {
  return !!getCurrentPermissions()[permissionKey];
}

function requireLogin() {
  const isLoginPage = /(^|\/)index\.html$/.test(window.location.pathname) || window.location.pathname.endsWith('/biblioteca/');
  if (!isLoginPage && !getCurrentUser()) {
    window.location.href = 'index.html';
    return false;
  }
  return true;
}

function requirePermission(permissionKey, redirectTo = 'dashboard.html') {
  if (!requireLogin()) return false;
  if (!hasPermission(permissionKey)) {
    showToast('Acceso restringido', 'Tu rol no tiene permiso para abrir este módulo.', 'error');
    setTimeout(() => { window.location.href = redirectTo; }, 800);
    return false;
  }
  return true;
}

function logout() {
  localStorage.removeItem(SESSION_KEY);
  window.location.href = 'index.html';
}

function applyPermissionVisibility(root = document) {
  root.querySelectorAll('[data-permission]').forEach(el => {
    const permission = el.getAttribute('data-permission');
    el.classList.toggle('hidden', !hasPermission(permission));
  });
}

function applyGlobalAuthUI() {
  ensurePermissionsStore();
  if (!requireLogin()) return;

  const user = getCurrentUser();
  if (user) {
    document.querySelectorAll('[data-current-user-name]').forEach(el => { el.textContent = user.name || 'Usuario'; });
    document.querySelectorAll('[data-current-user-role]').forEach(el => { el.textContent = user.role || ''; });
  }

  const navPermissions = {
    'users.html': 'crearUsuarios',
    'books.html': 'gestionarCatalogo',
    'prestamos.html': 'registrarPrestamo',
    'devoluciones.html': 'registrarDevolucion',
    'reportes.html': 'verReportes',
    'roles.html': 'crearUsuarios',
  };

  Object.entries(navPermissions).forEach(([href, permission]) => {
    document.querySelectorAll(`a[href="${href}"]`).forEach(link => {
      link.classList.toggle('hidden', !hasPermission(permission));
    });
  });

  document.querySelectorAll('a[href="index.html"]').forEach(link => {
    const text = (link.textContent || '').toLowerCase();
    if (text.includes('cerrar') || link.querySelector('[data-lucide="log-out"]')) {
      link.addEventListener('click', event => {
        event.preventDefault();
        logout();
      });
    }
  });

  // Make sidebar user section clickable → Mi Perfil (on pages that don't already wire it inline)
  const sidebarUserEl = document.querySelector('[data-current-user-name]');
  if (sidebarUserEl) {
    const section = sidebarUserEl.parentElement?.parentElement?.parentElement;
    if (section && !section.onclick) {
      section.classList.add('cursor-pointer', 'hover:bg-slate-700', 'transition-colors');
      section.onclick = () => { window.location.href = 'perfil.html'; };
    }
  }

  applyPermissionVisibility();
}


window.toNumber = toNumber;
window.DEFAULT_DUCKY_PERMISSIONS = DEFAULT_DUCKY_PERMISSIONS;
window.normalizeRoleName = normalizeRoleName;
window.ensurePermissionsStore = ensurePermissionsStore;
window.saveSession = saveSession;
window.getSession = getSession;
window.getCurrentUser = getCurrentUser;
window.getCurrentRole = getCurrentRole;
window.getCurrentPermissions = getCurrentPermissions;
window.hasPermission = hasPermission;
window.requireLogin = requireLogin;
window.requirePermission = requirePermission;
window.logout = logout;
window.applyPermissionVisibility = applyPermissionVisibility;
window.applyGlobalAuthUI = applyGlobalAuthUI;

// ============================================================
//  UTILIDADES
// ============================================================
function generateId() {
  return Math.random().toString(36).substring(2, 9);
}

// Calcula días entre dos fechas dd/mm/yyyy
function daysBetween(dateStr1, dateStr2) {
  const parse = s => {
    const [d, m, y] = s.split('/');
    return new Date(`${y}-${m}-${d}`);
  };
  const diff = parse(dateStr2) - parse(dateStr1);
  return Math.floor(diff / (1000 * 60 * 60 * 24));
}

// Devuelve la fecha de hoy en formato dd/mm/yyyy
function todayStr() {
  const d = new Date();
  const dd = String(d.getDate()).padStart(2, '0');
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const yyyy = d.getFullYear();
  return `${dd}/${mm}/${yyyy}`;
}

// Costo de multa por día de retraso (MXN)
const FINE_PER_DAY = 10.00;

// Calcula multa de un préstamo dado su dueDate y hoy
function calcFine(dueDate) {
  const days = daysBetween(dueDate, todayStr());
  return days > 0 ? days * FINE_PER_DAY : 0;
}

// ============================================================
//  TOAST NOTIFICATIONS
// ============================================================
function showToast(title, message, type = 'success') {
  const containerId = 'toast-container';
  let container = document.getElementById(containerId);

  if (!container) {
    container = document.createElement('div');
    container.id = containerId;
    container.className = 'fixed bottom-4 right-4 z-50 flex flex-col gap-2';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  const bgColor = type === 'success' ? 'bg-green-50 border-green-200'
                : type === 'error'   ? 'bg-red-50 border-red-200'
                                     : 'bg-yellow-50 border-yellow-200';
  const textColor = type === 'success' ? 'text-green-800'
                  : type === 'error'   ? 'text-red-800'
                                       : 'text-yellow-800';

  toast.className = `min-w-[300px] p-4 rounded-lg shadow-lg border ${bgColor} transform transition-all duration-300 translate-y-full opacity-0`;
  toast.innerHTML = `
    <h4 class="font-semibold text-sm ${textColor}">${title}</h4>
    <p class="text-sm ${textColor} opacity-90">${message}</p>
  `;

  container.appendChild(toast);
  setTimeout(() => toast.classList.remove('translate-y-full', 'opacity-0'), 10);
  setTimeout(() => {
    toast.classList.add('opacity-0');
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// ============================================================
//  ARRANQUE
// ============================================================
initDB();
