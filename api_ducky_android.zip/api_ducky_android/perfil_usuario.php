<?php
require_once "db.php";

requerirParametros(["usuario_id"]);
$usuarioId = obtenerParametro("usuario_id");

try {
    $sql = "SELECT
                u.id,
                u.nombre,
                u.matricula,
                u.correo,
                u.estado,
                u.fecha_creacion,
                r.nombre AS rol,
                a.carrera,
                a.semestre,
                a.estado AS estado_alumno,
                pr.departamento,
                pr.especialidad,
                pr.estado AS estado_profesor,
                co.area,
                co.puesto,
                co.estado AS estado_colaborador
            FROM usuarios u
            INNER JOIN roles r ON r.id = u.rol_id
            LEFT JOIN alumnos a ON a.usuario_id = u.id
            LEFT JOIN profesores pr ON pr.usuario_id = u.id
            LEFT JOIN colaboradores co ON co.usuario_id = u.id
            WHERE u.id = ?
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->execute([$usuarioId]);
    $usuario = $stmt->fetch();

    if (!$usuario) {
        responder(false, "Usuario no encontrado", [], 404);
    }

    responder(true, "Perfil obtenido correctamente", [
        "usuario" => $usuario
    ]);
} catch (PDOException $e) {
    responder(false, "Error al obtener perfil", [], 500);
}
?>
