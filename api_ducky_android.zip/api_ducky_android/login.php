<?php
require_once "db.php";

$correo = $_POST["correo"] ?? "";
$password = $_POST["password"] ?? "";

if ($correo == "" || $password == "") {
    responder(false, "Correo y contraseña requeridos", [], 400);
}

$sql = "SELECT
            u.id,
            u.nombre,
            u.matricula,
            u.correo,
            u.password,
            u.rol_id,
            r.nombre AS rol,
            u.estado
        FROM usuarios u
        INNER JOIN roles r ON u.rol_id = r.id
        WHERE u.correo = ?
        LIMIT 1";

$stmt = $conn->prepare($sql);
$stmt->execute([$correo]);
$usuario = $stmt->fetch();

if (!$usuario) {
    responder(false, "Usuario no encontrado", [], 401);
}

$passwordGuardada = $usuario["password"];

$passwordCorrecta =
    password_verify($password, $passwordGuardada) ||
    $password === $passwordGuardada;

if (!$passwordCorrecta) {
    responder(false, "Contraseña incorrecta", [], 401);
}

$estado = strtolower($usuario["estado"]);

if ($estado !== "activo" && $estado !== "suspendido") {
    responder(false, "Usuario inactivo", [], 403);
}

unset($usuario["password"]);

responder(true, "Inicio de sesión correcto", [
    "usuario" => $usuario
]);
?>
