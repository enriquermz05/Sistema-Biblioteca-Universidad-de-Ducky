<?php
require_once "db.php";

requerirParametros(["usuario_id"]);
$usuarioId = obtenerParametro("usuario_id");

try {
    $sql = "SELECT
                r.id,
                r.usuario_id,
                r.libro_id,
                r.fecha_reserva,
                r.fecha_expiracion,
                r.estado,
                l.titulo,
                l.isbn,
                l.ubicacion,
                c.nombre AS categoria,
                GROUP_CONCAT(DISTINCT au.nombre ORDER BY au.nombre SEPARATOR ', ') AS autores
            FROM reservas r
            INNER JOIN libros l ON l.id = r.libro_id
            LEFT JOIN categorias c ON c.id = l.categoria_id
            LEFT JOIN libro_autor la ON la.libro_id = l.id
            LEFT JOIN autores au ON au.id = la.autor_id
            WHERE r.usuario_id = ?
            GROUP BY r.id
            ORDER BY r.fecha_reserva DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute([$usuarioId]);
    $reservas = $stmt->fetchAll();

    responder(true, "Reservas obtenidas correctamente", [
        "reservas" => $reservas
    ]);
} catch (PDOException $e) {
    responder(false, "Error al obtener reservas", [], 500);
}
?>
