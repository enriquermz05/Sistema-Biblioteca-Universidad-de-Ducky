<?php
require_once "db.php";

requerirParametros(["usuario_id", "libro_id"]);
$usuarioId = obtenerParametro("usuario_id");
$libroId = obtenerParametro("libro_id");

try {
    $sqlUsuario = "SELECT id FROM usuarios WHERE id = ? AND LOWER(estado) = 'activo' LIMIT 1";
    $stmtUsuario = $conn->prepare($sqlUsuario);
    $stmtUsuario->execute([$usuarioId]);

    if (!$stmtUsuario->fetch()) {
        responder(false, "Usuario no válido o inactivo", [], 403);
    }

    $sqlLibro = "SELECT id FROM libros WHERE id = ? AND LOWER(estado_catalogo) IN ('activo', 'disponible') LIMIT 1";
    $stmtLibro = $conn->prepare($sqlLibro);
    $stmtLibro->execute([$libroId]);

    if (!$stmtLibro->fetch()) {
        responder(false, "Libro no encontrado o no disponible en catálogo", [], 404);
    }

    $sqlExistente = "SELECT id FROM reservas
                     WHERE usuario_id = ?
                     AND libro_id = ?
                     AND LOWER(estado) IN ('activa', 'pendiente')
                     LIMIT 1";
    $stmtExistente = $conn->prepare($sqlExistente);
    $stmtExistente->execute([$usuarioId, $libroId]);

    if ($stmtExistente->fetch()) {
        responder(false, "Ya tienes una reserva activa para este libro", [], 409);
    }

    $sql = "INSERT INTO reservas (usuario_id, libro_id, fecha_reserva, fecha_expiracion, estado)
            VALUES (?, ?, NOW(), DATE_ADD(NOW(), INTERVAL 2 DAY), 'Activa')";

    $stmt = $conn->prepare($sql);
    $stmt->execute([$usuarioId, $libroId]);

    responder(true, "Reserva creada correctamente", [
        "reserva_id" => $conn->lastInsertId()
    ], 201);
} catch (PDOException $e) {
    responder(false, "Error al reservar libro", [], 500);
}
?>
