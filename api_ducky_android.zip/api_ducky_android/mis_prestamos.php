<?php
require_once "db.php";

requerirParametros(["usuario_id"]);
$usuarioId = obtenerParametro("usuario_id");

try {
    $sql = "SELECT
                p.id,
                p.usuario_id,
                p.copia_id,
                p.fecha_prestamo,
                p.fecha_vencimiento,
                p.numero_renovaciones,
                p.estado,
                l.id AS libro_id,
                l.titulo,
                l.isbn,
                cl.codigo_interno,
                cl.estado AS estado_copia,
                d.fecha_devolucion,
                d.condicion_libro
            FROM prestamos p
            INNER JOIN copias_libros cl ON cl.id = p.copia_id
            INNER JOIN libros l ON l.id = cl.libro_id
            LEFT JOIN devoluciones d ON d.prestamo_id = p.id
            WHERE p.usuario_id = ?
            ORDER BY p.fecha_prestamo DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute([$usuarioId]);
    $prestamos = $stmt->fetchAll();

    responder(true, "Préstamos obtenidos correctamente", [
        "prestamos" => $prestamos
    ]);
} catch (PDOException $e) {
    responder(false, "Error al obtener préstamos", [], 500);
}
?>
