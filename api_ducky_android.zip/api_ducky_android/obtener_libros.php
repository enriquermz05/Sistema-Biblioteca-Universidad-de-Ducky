<?php
require_once "db.php";

try {
    $sql = "SELECT
                l.id,
                l.titulo,
                l.isbn,
                l.anio_publicacion,
                l.paginas,
                l.ubicacion,
                l.precio_reposicion,
                l.descripcion,
                l.tipo_uso,
                l.estado_catalogo,
                c.nombre AS categoria,
                e.nombre AS editorial,
                i.nombre AS idioma,
                GROUP_CONCAT(DISTINCT au.nombre ORDER BY au.nombre SEPARATOR ', ') AS autores,
                COUNT(DISTINCT cl.id) AS total_copias,
                SUM(CASE WHEN LOWER(cl.estado) = 'disponible' THEN 1 ELSE 0 END) AS copias_disponibles
            FROM libros l
            LEFT JOIN categorias c ON c.id = l.categoria_id
            LEFT JOIN editoriales e ON e.id = l.editorial_id
            LEFT JOIN idiomas i ON i.id = l.idioma_id
            LEFT JOIN libro_autor la ON la.libro_id = l.id
            LEFT JOIN autores au ON au.id = la.autor_id
            LEFT JOIN copias_libros cl ON cl.libro_id = l.id
            WHERE LOWER(l.estado_catalogo) IN ('activo', 'disponible')
            GROUP BY l.id
            ORDER BY l.titulo ASC";

    $stmt = $conn->prepare($sql);
    $stmt->execute();
    $libros = $stmt->fetchAll();

    responder(true, "Libros obtenidos correctamente", [
        "libros" => $libros
    ]);
} catch (PDOException $e) {
    responder(false, "Error al obtener libros", [], 500);
}
?>
