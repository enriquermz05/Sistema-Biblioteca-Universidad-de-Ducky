<?php
require_once "db.php";

requerirParametros(["usuario_id"]);
$usuarioId = obtenerParametro("usuario_id");

try {
    $sql = "SELECT
                id,
                usuario_id,
                tipo,
                mensaje,
                medio,
                fecha_envio,
                estado
            FROM notificaciones
            WHERE usuario_id = ?
            ORDER BY fecha_envio DESC, id DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute([$usuarioId]);
    $notificaciones = $stmt->fetchAll();

    responder(true, "Notificaciones obtenidas correctamente", [
        "notificaciones" => $notificaciones
    ]);
} catch (PDOException $e) {
    responder(false, "Error al obtener notificaciones", [], 500);
}
?>
