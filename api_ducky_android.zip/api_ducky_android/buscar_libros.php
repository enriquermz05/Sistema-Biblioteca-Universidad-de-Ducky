<?php
require_once "db.php";

$q = obtenerParametro("q", "");
$categoriaId = obtenerParametro("categoria_id", "");

try {
    $where = "WHERE LOWER(l.estado_catalogo) IN ('activo', 'disponible')";
    $params = [];

    if ($q !== "") {
        $where .= " AND (
            l.titulo LIKE ?
            OR l.isbn LIKE ?
            OR au.nombre LIKE ?
            OR c.nombre LIKE ?
            OR e.nombre LIKE ?
        )";
        $busqueda = "%" . $q . "%";
        array_push($params, $busqueda, $busqueda, $busqueda, $busqueda, $busqueda);
    }

    if ($categoriaId !== "") {
        $where .= " AND l.categoria_id = ?";
        $params[] = $categoriaId;
    }

    $sql = "SELECT
                l.id,
                l.titulo,
                l.isbn,
                l.anio_publicacion,
                l.ubicacion,
                l.descripcion,
                l.tipo_uso,
                l.estado_catalogo,
                c.nombre AS categoria,
                e.nombre AS editorial,
                GROUP_CONCAT(DISTINCT au.nombre ORDER BY au.nombre SEPARATOR ', ') AS autores,
                COUNT(DISTINCT cl.id) AS total_copias,
                SUM(CASE WHEN LOWER(cl.estado) = 'disponible' THEN 1 ELSE 0 END) AS copias_disponibles
            FROM libros l
            LEFT JOIN categorias c ON c.id = l.categoria_id
            LEFT JOIN editoriales e ON e.id = l.editorial_id
            LEFT JOIN libro_autor la ON la.libro_id = l.id
            LEFT JOIN autores au ON au.id = la.autor_id
            LEFT JOIN copias_libros cl ON cl.libro_id = l.id
            $where
            GROUP BY l.id
            ORDER BY l.titulo ASC";

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $libros = $stmt->fetchAll();

    responder(true, "Búsqueda realizada correctamente", [
        "libros" => $libros
    ]);
} catch (PDOException $e) {
    responder(false, "Error al buscar libros", [], 500);
}
?>
