<?php
require_once "db.php";

requerirParametros(["usuario_id", "prestamo_id"]);
$usuarioId = obtenerParametro("usuario_id");
$prestamoId = obtenerParametro("prestamo_id");
$maxRenovaciones = 2;
$diasRenovacion = 7;

try {
    $conn->beginTransaction();

    $sqlPrestamo = "SELECT id, usuario_id, fecha_vencimiento, numero_renovaciones, estado
                    FROM prestamos
                    WHERE id = ? AND usuario_id = ?
                    LIMIT 1
                    FOR UPDATE";

    $stmtPrestamo = $conn->prepare($sqlPrestamo);
    $stmtPrestamo->execute([$prestamoId, $usuarioId]);
    $prestamo = $stmtPrestamo->fetch();

    if (!$prestamo) {
        $conn->rollBack();
        responder(false, "Préstamo no encontrado", [], 404);
    }

    if (strtolower($prestamo["estado"]) !== "activo") {
        $conn->rollBack();
        responder(false, "Solo se pueden renovar préstamos activos", [], 409);
    }

    if ((int)$prestamo["numero_renovaciones"] >= $maxRenovaciones) {
        $conn->rollBack();
        responder(false, "Ya alcanzaste el límite de renovaciones", [], 409);
    }

    $fechaAnterior = $prestamo["fecha_vencimiento"];

    $sqlNuevaFecha = "SELECT DATE_ADD(?, INTERVAL $diasRenovacion DAY) AS nueva_fecha";
    $stmtFecha = $conn->prepare($sqlNuevaFecha);
    $stmtFecha->execute([$fechaAnterior]);
    $fechaNueva = $stmtFecha->fetch()["nueva_fecha"];

    $sqlRenovacion = "INSERT INTO renovaciones
                        (prestamo_id, fecha_renovacion, fecha_vencimiento_anterior, fecha_vencimiento_nueva, autorizado_por)
                      VALUES (?, NOW(), ?, ?, ?)";

    $stmtRenovacion = $conn->prepare($sqlRenovacion);
    $stmtRenovacion->execute([$prestamoId, $fechaAnterior, $fechaNueva, $usuarioId]);

    $sqlUpdate = "UPDATE prestamos
                  SET fecha_vencimiento = ?, numero_renovaciones = numero_renovaciones + 1
                  WHERE id = ?";

    $stmtUpdate = $conn->prepare($sqlUpdate);
    $stmtUpdate->execute([$fechaNueva, $prestamoId]);

    $conn->commit();

    responder(true, "Préstamo renovado correctamente", [
        "prestamo_id" => $prestamoId,
        "fecha_vencimiento_anterior" => $fechaAnterior,
        "fecha_vencimiento_nueva" => $fechaNueva
    ]);
} catch (PDOException $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    responder(false, "Error al renovar préstamo", [], 500);
}
?>
