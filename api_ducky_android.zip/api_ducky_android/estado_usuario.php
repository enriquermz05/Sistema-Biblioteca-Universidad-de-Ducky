<?php
require_once "db.php";

requerirParametros(["usuario_id"]);
$usuarioId = obtenerParametro("usuario_id");

try {
    $sqlUsuario = "SELECT id, estado FROM usuarios WHERE id = ? LIMIT 1";
    $stmtUsuario = $conn->prepare($sqlUsuario);
    $stmtUsuario->execute([$usuarioId]);
    $usuario = $stmtUsuario->fetch();

    if (!$usuario) {
        responder(false, "Usuario no encontrado", [], 404);
    }

    $sqlSuspension = "SELECT motivo
                      FROM suspensiones
                      WHERE usuario_id = ?
                      AND LOWER(estado) IN ('activa', 'activo')
                      AND (fecha_fin IS NULL OR fecha_fin >= NOW())
                      ORDER BY fecha_inicio DESC
                      LIMIT 1";
    $stmtSuspension = $conn->prepare($sqlSuspension);
    $stmtSuspension->execute([$usuarioId]);
    $suspension = $stmtSuspension->fetch();

    $estado = $usuario["estado"];
    $suspendido = strtolower($estado) === "suspendido" || $suspension !== false;

    responder(true, "Estado de usuario obtenido correctamente", [
        "usuario" => [
            "usuario_id" => $usuario["id"],
            "estado" => $estado,
            "suspendido" => $suspendido,
            "motivo_suspension" => $suspension["motivo"] ?? ""
        ]
    ]);
} catch (PDOException $e) {
    responder(false, "Error al obtener estado de usuario", [], 500);
}
?>
