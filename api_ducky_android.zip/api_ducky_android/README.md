# API Biblioteca Ducky

Esta carpeta contiene una primera versión de API en PHP para conectar una app Android con la base de datos MySQL/MariaDB de Biblioteca Ducky.

## 1. Archivos incluidos

- `db.php`: conexión a la base de datos.
- `helpers.php`: funciones generales para responder JSON y leer parámetros.
- `health.php`: prueba rápida de conexión.
- `login.php`: inicio de sesión.
- `obtener_libros.php`: catálogo completo de libros.
- `buscar_libros.php`: búsqueda por título, ISBN, autor, categoría o editorial.
- `detalle_libro.php`: detalle de un libro y sus copias.
- `mis_prestamos.php`: préstamos de un usuario.
- `mis_multas.php`: multas de un usuario.
- `mis_reservas.php`: reservas de un usuario.
- `reservar_libro.php`: crea una reserva.
- `renovar_prestamo.php`: renueva un préstamo activo.
- `perfil_usuario.php`: perfil del usuario.
- `obtener_notificaciones.php`: notificaciones del usuario.
- `pagar_multa.php`: registra un pago de multa.

## 2. Configurar credenciales

Abre `db.php` y cambia estos valores:

```php
$host = "localhost";
$dbname = "NOMBRE_DE_TU_BASE_DE_DATOS";
$user = "TU_USUARIO";
$password = "TU_PASSWORD";
```

## 3. Ubicación recomendada con XAMPP

Copia la carpeta `api_ducky` dentro de:

```txt
C:/xampp/htdocs/
```

La URL local quedaría así:

```txt
http://localhost/api_ducky/health.php
```

Desde el emulador de Android Studio se usaría:

```txt
http://10.0.2.2/api_ducky/
```

## 4. Pruebas rápidas

### Login

Método: `POST`

URL:

```txt
http://localhost/api_ducky/login.php
```

Parámetros:

```txt
correo
password
```

### Obtener libros

Método: `GET`

```txt
http://localhost/api_ducky/obtener_libros.php
```

### Buscar libros

Método: `GET` o `POST`

```txt
http://localhost/api_ducky/buscar_libros.php?q=calculo
```

### Mis préstamos

Método: `GET` o `POST`

```txt
http://localhost/api_ducky/mis_prestamos.php?usuario_id=1
```

## 5. Nota sobre contraseñas

`login.php` acepta dos casos:

1. Contraseñas guardadas con `password_hash()`.
2. Contraseñas guardadas en texto plano.

Para una versión real, se recomienda usar `password_hash()` y `password_verify()`.
