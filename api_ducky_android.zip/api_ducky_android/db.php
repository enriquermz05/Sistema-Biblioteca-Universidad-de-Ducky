<?php
require_once "helpers.php";

$host = "localhost";
$port = "8889";
$dbname = "biblioteca_ducky";
$user = "root";
$password = "root";

try {
    $conn = new PDO(
        "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4",
        $user,
        $password
    );

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    responder(false, "Error al conectar con la base de datos", [], 500);
}
?>
