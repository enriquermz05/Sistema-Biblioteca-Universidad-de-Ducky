<?php
require_once "db.php";

requerirParametros(["libro_id"]);
$libroId = obtenerParametro("libro_id");

try {
    $sql = "SELECT
                l.id,
                l.titulo,
                l.isbn,
                l.anio_publicacion,
                l.paginas,
                l.ubicacion,
                l.precio_reposicion,
                l.descripcion,
                l.tipo_uso,
                l.estado_catalogo,
                l.fecha_alta,
                c.nombre AS categoria,
                e.nombre AS editorial,
                e.pais AS pais_editorial,
                i.nombre AS idioma,
                GROUP_CONCAT(DISTINCT au.nombre ORDER BY au.nombre SEPARATOR ', ') AS autores,
                COUNT(DISTINCT cl.id) AS total_copias,
                SUM(CASE WHEN LOWER(cl.estado) = 'disponible' THEN 1 ELSE 0 END) AS copias_disponibles
            FROM libros l
            LEFT JOIN categorias c ON c.id = l.categoria_id
            LEFT JOIN editoriales e ON e.id = l.editorial_id
            LEFT JOIN idiomas i ON i.id = l.idioma_id
            LEFT JOIN libro_autor la ON la.libro_id = l.id
            LEFT JOIN autores au ON au.id = la.autor_id
            LEFT JOIN copias_libros cl ON cl.libro_id = l.id
            WHERE l.id = ?
            GROUP BY l.id
            LIMIT 1";

    $stmt = $conn->prepare($sql);
    $stmt->execute([$libroId]);
    $libro = $stmt->fetch();

    if (!$libro) {
        responder(false, "Libro no encontrado", [], 404);
    }

    $sqlCopias = "SELECT id, codigo_interno, estado, fecha_adquisicion, observaciones
                  FROM copias_libros
                  WHERE libro_id = ?
                  ORDER BY codigo_interno ASC";

    $stmtCopias = $conn->prepare($sqlCopias);
    $stmtCopias->execute([$libroId]);
    $copias = $stmtCopias->fetchAll();

    responder(true, "Detalle del libro obtenido correctamente", [
        "libro" => $libro,
        "copias" => $copias
    ]);
} catch (PDOException $e) {
    responder(false, "Error al obtener el detalle del libro", [], 500);
}
?>
