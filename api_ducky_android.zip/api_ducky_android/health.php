<?php
require_once "db.php";
responder(true, "API Biblioteca Ducky funcionando correctamente", [
    "version" => "1.0",
    "database" => "conectada"
]);
?>
