<?php
require_once "db.php";

requerirParametros(["usuario_id", "multa_id", "monto", "metodo_pago"]);
$usuarioId = obtenerParametro("usuario_id");
$multaId = obtenerParametro("multa_id");
$monto = obtenerParametro("monto");
$metodoPago = obtenerParametro("metodo_pago");
$concepto = obtenerParametro("concepto", "Pago de multa");

try {
    $conn->beginTransaction();

    $sqlMulta = "SELECT id, usuario_id, monto, estado
                 FROM multas
                 WHERE id = ? AND usuario_id = ?
                 LIMIT 1
                 FOR UPDATE";

    $stmtMulta = $conn->prepare($sqlMulta);
    $stmtMulta->execute([$multaId, $usuarioId]);
    $multa = $stmtMulta->fetch();

    if (!$multa) {
        $conn->rollBack();
        responder(false, "Multa no encontrada", [], 404);
    }

    if (strtolower($multa["estado"]) === "pagada") {
        $conn->rollBack();
        responder(false, "La multa ya se encuentra pagada", [], 409);
    }

    $sqlPago = "INSERT INTO pagos
                    (usuario_id, multa_id, monto, concepto, fecha_pago, estado, metodo_pago, registrado_por)
                VALUES (?, ?, ?, ?, NOW(), 'Confirmado', ?, ?)";

    $stmtPago = $conn->prepare($sqlPago);
    $stmtPago->execute([$usuarioId, $multaId, $monto, $concepto, $metodoPago, $usuarioId]);

    $sqlSuma = "SELECT COALESCE(SUM(monto), 0) AS total_pagado
                FROM pagos
                WHERE multa_id = ? AND LOWER(estado) IN ('confirmado', 'pagado')";

    $stmtSuma = $conn->prepare($sqlSuma);
    $stmtSuma->execute([$multaId]);
    $totalPagado = (float)$stmtSuma->fetch()["total_pagado"];

    if ($totalPagado >= (float)$multa["monto"]) {
        $sqlUpdate = "UPDATE multas SET estado = 'Pagada' WHERE id = ?";
        $stmtUpdate = $conn->prepare($sqlUpdate);
        $stmtUpdate->execute([$multaId]);
    }

    $conn->commit();

    responder(true, "Pago registrado correctamente", [
        "pago_id" => $conn->lastInsertId(),
        "total_pagado" => $totalPagado
    ], 201);
} catch (PDOException $e) {
    if ($conn->inTransaction()) {
        $conn->rollBack();
    }
    responder(false, "Error al registrar pago", [], 500);
}
?>
