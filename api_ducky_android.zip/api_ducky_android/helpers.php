<?php
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(200);
    exit;
}

function responder($success, $message, $data = [], $statusCode = 200) {
    http_response_code($statusCode);
    echo json_encode([
        "success" => $success,
        "message" => $message,
        "data" => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

function obtenerParametro($nombre, $default = null) {
    if (isset($_POST[$nombre])) {
        return trim($_POST[$nombre]);
    }

    if (isset($_GET[$nombre])) {
        return trim($_GET[$nombre]);
    }

    $json = json_decode(file_get_contents("php://input"), true);
    if (is_array($json) && isset($json[$nombre])) {
        return trim($json[$nombre]);
    }

    return $default;
}

function requerirParametros($parametros) {
    foreach ($parametros as $parametro) {
        $valor = obtenerParametro($parametro);
        if ($valor === null || $valor === "") {
            responder(false, "Falta el parámetro: " . $parametro, [], 400);
        }
    }
}

function passwordValida($passwordIngresada, $passwordGuardada) {
    $info = password_get_info($passwordGuardada);

    if ($info["algo"] !== 0) {
        return password_verify($passwordIngresada, $passwordGuardada);
    }

    return hash_equals($passwordGuardada, $passwordIngresada);
}
?>
