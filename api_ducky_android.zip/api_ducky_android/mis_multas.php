<?php
require_once "db.php";

requerirParametros(["usuario_id"]);
$usuarioId = obtenerParametro("usuario_id");

try {
    $sql = "SELECT
                m.id,
                m.usuario_id,
                m.prestamo_id,
                m.tipo_id,
                tm.nombre AS tipo_multa,
                tm.descripcion AS descripcion_tipo,
                m.monto,
                COALESCE(SUM(pg.monto), 0) AS total_pagado,
                (m.monto - COALESCE(SUM(pg.monto), 0)) AS monto_pendiente,
                m.estado,
                m.fecha_generacion,
                m.dias_retraso,
                m.observaciones,
                l.titulo AS titulo_libro
            FROM multas m
            INNER JOIN tipos_multa tm ON tm.id = m.tipo_id
            LEFT JOIN pagos pg ON pg.multa_id = m.id
            LEFT JOIN prestamos p ON p.id = m.prestamo_id
            LEFT JOIN copias_libros cl ON cl.id = p.copia_id
            LEFT JOIN libros l ON l.id = cl.libro_id
            WHERE m.usuario_id = ?
            GROUP BY m.id
            ORDER BY m.fecha_generacion DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute([$usuarioId]);
    $multas = $stmt->fetchAll();

    responder(true, "Multas obtenidas correctamente", [
        "multas" => $multas
    ]);
} catch (PDOException $e) {
    responder(false, "Error al obtener multas", [], 500);
}
?>
