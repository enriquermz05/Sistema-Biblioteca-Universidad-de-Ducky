
  # App - Universidad Ducky Sistema de gestion bibliteca (Copy)

  This is a code bundle for App - Universidad Ducky Sistema de gestion bibliteca (Copy). The original project is available at https://www.figma.com/design/nP3aicoCVGcFWfPSoID4fz/App---Universidad-Ducky-Sistema-de-gestion-bibliteca--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  