export type LoanStatus = "Activo" | "Vencido" | "Por Vencer";

export interface Loan {
  id: string;
  bookId: string;
  bookTitle: string;
  bookAuthor: string;
  bookCover?: string;
  loanDate: string;
  dueDate: string;
  returnDate?: string;
  status: LoanStatus;
  renewalCount: number;
  maxRenewals: number;
}

export interface Fine {
  id: string;
  loanId: string;
  bookTitle: string;
  amount: number;
  daysLate: number;
  dueDate: string;
  status: "Pendiente" | "Pagada";
}

// Mock data for current user's loans
export const mockLoans: Loan[] = [
  {
    id: "L001",
    bookId: "1",
    bookTitle: "Cien años de soledad",
    bookAuthor: "Gabriel García Márquez",
    loanDate: "2026-02-24",
    dueDate: "2026-03-17",
    status: "Por Vencer",
    renewalCount: 0,
    maxRenewals: 2,
  },
  {
    id: "L002",
    bookId: "5",
    bookTitle: "1984",
    bookAuthor: "George Orwell",
    loanDate: "2026-02-10",
    dueDate: "2026-03-03",
    status: "Vencido",
    renewalCount: 1,
    maxRenewals: 2,
  },
  {
    id: "L003",
    bookId: "8",
    bookTitle: "El código limpio",
    bookAuthor: "Robert C. Martin",
    loanDate: "2026-02-28",
    dueDate: "2026-03-21",
    status: "Activo",
    renewalCount: 0,
    maxRenewals: 2,
  },
  {
    id: "L004",
    bookId: "12",
    bookTitle: "Diseño de patrones",
    bookAuthor: "Erich Gamma",
    loanDate: "2026-02-20",
    dueDate: "2026-03-13",
    status: "Activo",
    renewalCount: 1,
    maxRenewals: 2,
  },
];

export const mockFines: Fine[] = [
  {
    id: "F001",
    loanId: "L002",
    bookTitle: "1984",
    amount: 35.0,
    daysLate: 7,
    dueDate: "2026-03-03",
    status: "Pendiente",
  },
];

// Helper functions
export function getDaysUntilDue(dueDate: string): number {
  const due = new Date(dueDate);
  const today = new Date("2026-03-10"); // Current date from system
  const diffTime = due.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
  return diffDays;
}

export function getTotalFines(): number {
  return mockFines
    .filter((fine) => fine.status === "Pendiente")
    .reduce((sum, fine) => sum + fine.amount, 0);
}

// Helper function to add a new loan
export function addLoan(bookId: string, bookTitle: string, bookAuthor: string): Loan {
  const today = new Date();
  const dueDate = new Date();
  dueDate.setDate(dueDate.getDate() + 21); // 21 days from now

  const todayString = today.toISOString().split('T')[0];
  const dueDateString = dueDate.toISOString().split('T')[0];

  const daysUntilDue = getDaysUntilDue(dueDateString);
  let status: LoanStatus = "Activo";
  if (daysUntilDue < 0) {
    status = "Vencido";
  } else if (daysUntilDue <= 7) {
    status = "Por Vencer";
  }

  const newLoan: Loan = {
    id: `L${String(Date.now()).slice(-6)}`,
    bookId,
    bookTitle,
    bookAuthor,
    loanDate: todayString,
    dueDate: dueDateString,
    status,
    renewalCount: 0,
    maxRenewals: 2,
  };

  return newLoan;
}

// Helper function to check if a book is already loaned
export function isBookLoaned(bookId: string, loans: Loan[]): boolean {
  return loans.some(l => l.bookId === bookId && !l.returnDate);
}
