export type UserRole = "Administrador" | "Bibliotecario" | "Profesor" | "Estudiante" | "Colaborador";
export type UserStatus = "Activo" | "Suspendido" | "Inactivo";

export interface Fine {
  id: string;
  amount: number;
  reason: string;
  date: string;
  status: "Pendiente" | "Pagado";
}

export interface BookFine {
  id: string;
  bookTitle: string;
  reason: "Libro perdido" | "Libro dañado" | "Préstamo vencido";
  replacementPrice: number;
  status: "Pendiente" | "Pagado";
}

export interface User {
  id: string;
  name: string;
  universityId: string;
  role: UserRole;
  status: UserStatus;
  activeLoans: number;
  fines: number;
  email: string;
  phone: string;
  department?: string;
  joinedDate: string;
  loans: Loan[];
  fineHistory: Fine[];
  bookFines: BookFine[];
}

export interface Loan {
  id: string;
  bookTitle: string;
  borrowDate: string;
  dueDate: string;
  status: "Activo" | "Vencido" | "Devuelto";
}

export const mockUsers: User[] = [
  {
    id: "1",
    name: "Sarah Johnson",
    universityId: "EST-2024-001",
    role: "Estudiante",
    status: "Activo",
    activeLoans: 3,
    fines: 465.50,
    email: "sarah.johnson@universidad.edu",
    phone: "+1 (555) 123-4567",
    department: "Ciencias de la Computación",
    joinedDate: "15/01/2024",
    loans: [
      {
        id: "L001",
        bookTitle: "Sistemas de Bases de Datos: El Libro Completo",
        borrowDate: "20/02/2026",
        dueDate: "20/03/2026",
        status: "Activo",
      },
      {
        id: "L002",
        bookTitle: "Inteligencia Artificial: Un Enfoque Moderno",
        borrowDate: "25/02/2026",
        dueDate: "25/03/2026",
        status: "Activo",
      },
      {
        id: "L003",
        bookTitle: "Código Limpio",
        borrowDate: "01/03/2026",
        dueDate: "31/03/2026",
        status: "Activo",
      },
    ],
    fineHistory: [
      {
        id: "F001",
        amount: 15.50,
        reason: "Devolución tardía - Introducción a Algoritmos",
        date: "15/02/2026",
        status: "Pendiente",
      },
    ],
    bookFines: [
      {
        id: "BF001",
        bookTitle: "Código Limpio",
        reason: "Libro perdido",
        replacementPrice: 450.00,
        status: "Pendiente",
      },
    ],
  },
  {
    id: "2",
    name: "Michael Chen",
    universityId: "PRF-2022-045",
    role: "Profesor",
    status: "Activo",
    activeLoans: 5,
    fines: 0,
    email: "m.chen@universidad.edu",
    phone: "+1 (555) 234-5678",
    department: "Ingeniería",
    joinedDate: "01/09/2022",
    loans: [
      {
        id: "L004",
        bookTitle: "Matemáticas Avanzadas para Ingeniería",
        borrowDate: "10/01/2026",
        dueDate: "10/04/2026",
        status: "Activo",
      },
      {
        id: "L005",
        bookTitle: "Diseño de Ingeniería Mecánica",
        borrowDate: "15/01/2026",
        dueDate: "15/04/2026",
        status: "Activo",
      },
    ],
    fineHistory: [],
    bookFines: [],
  },
  {
    id: "3",
    name: "Emma Williams",
    universityId: "BIB-2023-012",
    role: "Bibliotecario",
    status: "Activo",
    activeLoans: 0,
    fines: 0,
    email: "e.williams@universidad.edu",
    phone: "+1 (555) 345-6789",
    joinedDate: "15/03/2023",
    loans: [],
    fineHistory: [],
    bookFines: [],
  },
  {
    id: "4",
    name: "James Brown",
    universityId: "EST-2023-156",
    role: "Estudiante",
    status: "Suspendido",
    activeLoans: 2,
    fines: 85.00,
    email: "james.brown@universidad.edu",
    phone: "+1 (555) 456-7890",
    department: "Administración de Empresas",
    joinedDate: "01/09/2023",
    loans: [
      {
        id: "L006",
        bookTitle: "Gestión de Marketing",
        borrowDate: "01/12/2025",
        dueDate: "01/01/2026",
        status: "Vencido",
      },
      {
        id: "L007",
        bookTitle: "Contabilidad Financiera",
        borrowDate: "15/12/2025",
        dueDate: "15/01/2026",
        status: "Vencido",
      },
    ],
    fineHistory: [
      {
        id: "F002",
        amount: 45.00,
        reason: "Devolución tardía - Estrategia Empresarial",
        date: "20/01/2026",
        status: "Pendiente",
      },
      {
        id: "F003",
        amount: 40.00,
        reason: "Devolución tardía - Principios de Economía",
        date: "10/02/2026",
        status: "Pendiente",
      },
    ],
    bookFines: [],
  },
  {
    id: "5",
    name: "Lisa Anderson",
    universityId: "COL-2024-008",
    role: "Colaborador",
    status: "Activo",
    activeLoans: 1,
    fines: 0,
    email: "lisa.anderson@investigacion.org",
    phone: "+1 (555) 567-8901",
    joinedDate: "01/02/2024",
    loans: [
      {
        id: "L008",
        bookTitle: "Métodos de Investigación en Psicología",
        borrowDate: "28/02/2026",
        dueDate: "28/03/2026",
        status: "Activo",
      },
    ],
    fineHistory: [],
    bookFines: [],
  },
  {
    id: "6",
    name: "Robert Taylor",
    universityId: "ADM-2021-001",
    role: "Administrador",
    status: "Activo",
    activeLoans: 0,
    fines: 0,
    email: "r.taylor@universidad.edu",
    phone: "+1 (555) 678-9012",
    joinedDate: "10/01/2021",
    loans: [],
    fineHistory: [],
    bookFines: [],
  },
  {
    id: "7",
    name: "María García",
    universityId: "EST-2024-089",
    role: "Estudiante",
    status: "Activo",
    activeLoans: 2,
    fines: 385.00,
    email: "maria.garcia@universidad.edu",
    phone: "+1 (555) 789-0123",
    department: "Biología",
    joinedDate: "20/01/2024",
    loans: [
      {
        id: "L009",
        bookTitle: "Biología Molecular de la Célula",
        borrowDate: "15/02/2026",
        dueDate: "15/03/2026",
        status: "Activo",
      },
    ],
    fineHistory: [
      {
        id: "F004",
        amount: 5.00,
        reason: "Devolución tardía - Genética",
        date: "01/02/2026",
        status: "Pagado",
      },
    ],
    bookFines: [
      {
        id: "BF002",
        bookTitle: "Introducción a Algoritmos",
        reason: "Libro dañado",
        replacementPrice: 380.00,
        status: "Pendiente",
      },
    ],
  },
  {
    id: "8",
    name: "David Lee",
    universityId: "PRF-2020-023",
    role: "Profesor",
    status: "Activo",
    activeLoans: 4,
    fines: 120.00,
    email: "d.lee@universidad.edu",
    phone: "+1 (555) 890-1234",
    department: "Física",
    joinedDate: "15/08/2020",
    loans: [
      {
        id: "L010",
        bookTitle: "Mecánica Cuántica",
        borrowDate: "05/01/2026",
        dueDate: "05/04/2026",
        status: "Activo",
      },
    ],
    fineHistory: [],
    bookFines: [
      {
        id: "BF003",
        bookTitle: "Programación en Python",
        reason: "Préstamo vencido",
        replacementPrice: 120.00,
        status: "Pagado",
      },
    ],
  },
];