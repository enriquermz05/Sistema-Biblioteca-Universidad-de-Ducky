export type ReservationStatus = "Pendiente" | "Activa" | "Notificada" | "Completada" | "Cancelada";

export interface Reservation {
  id: string;
  bookId: string;
  bookTitle: string;
  bookAuthor: string;
  bookCover?: string;
  reservationDate: string;
  estimatedAvailableDate?: string;
  status: ReservationStatus;
  position: number;
}

// Mock data for current user's reservations
export const mockReservations: Reservation[] = [
  {
    id: "R001",
    bookId: "3",
    bookTitle: "Código Limpio",
    bookAuthor: "Robert C. Martin",
    reservationDate: "2026-03-08",
    estimatedAvailableDate: "2026-03-15",
    status: "Activa",
    position: 1,
  },
  {
    id: "R002",
    bookId: "7",
    bookTitle: "Gestión de Marketing",
    bookAuthor: "Philip Kotler, Kevin Lane Keller",
    reservationDate: "2026-03-01",
    estimatedAvailableDate: "2026-03-10",
    status: "Notificada",
    position: 1,
  },
];

// Helper function to add a reservation (for books that are loaned)
export function addReservation(bookId: string, bookTitle: string, bookAuthor: string): Reservation {
  const newReservation: Reservation = {
    id: `R${String(Date.now()).slice(-6)}`,
    bookId,
    bookTitle,
    bookAuthor,
    reservationDate: new Date().toISOString().split('T')[0],
    estimatedAvailableDate: calculateEstimatedDate(7),
    status: "Activa",
    position: 1,
  };

  return newReservation;
}

// Helper function to add a loan request (for available books)
export function addLoanRequest(bookId: string, bookTitle: string, bookAuthor: string): Reservation {
  const newRequest: Reservation = {
    id: `R${String(Date.now()).slice(-6)}`,
    bookId,
    bookTitle,
    bookAuthor,
    reservationDate: new Date().toISOString().split('T')[0],
    status: "Pendiente",
    position: 1,
  };

  return newRequest;
}

// Helper function to calculate estimated date
function calculateEstimatedDate(daysToAdd: number): string {
  const date = new Date();
  date.setDate(date.getDate() + daysToAdd);
  return date.toISOString().split('T')[0];
}

// Helper function to check if a book is already reserved
export function isBookReserved(bookId: string, reservations: Reservation[]): boolean {
  return reservations.some(
    r => r.bookId === bookId && (r.status === "Activa" || r.status === "Notificada")
  );
}
