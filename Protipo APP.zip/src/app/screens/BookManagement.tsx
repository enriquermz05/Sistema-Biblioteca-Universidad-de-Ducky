import { useState } from "react";
import { Link } from "react-router";
import { Plus, Edit, Trash2, Eye, BookOpen, Search } from "lucide-react";
import { mockBooks, BookCondition } from "../data/mockBooks";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "../components/ui/alert-dialog";
import { toast } from "sonner";

export function BookManagement() {
  const [books, setBooks] = useState(mockBooks);
  const [searchQuery, setSearchQuery] = useState("");
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [bookToDelete, setBookToDelete] = useState<string | null>(null);

  const filteredBooks = books.filter(
    (book) =>
      book.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
      book.isbn.includes(searchQuery)
  );

  const handleDeleteClick = (bookId: string) => {
    setBookToDelete(bookId);
    setDeleteDialogOpen(true);
  };

  const handleDeleteConfirm = () => {
    if (bookToDelete) {
      const book = books.find((b) => b.id === bookToDelete);
      setBooks(books.filter((b) => b.id !== bookToDelete));
      toast.success("Libro eliminado", {
        description: `"${book?.title}" ha sido eliminado del catálogo.`,
      });
      setDeleteDialogOpen(false);
      setBookToDelete(null);
    }
  };

  const getConditionBadge = (condition: BookCondition) => {
    const styles = {
      "Perfecto": "bg-green-100 text-green-800",
      "Daño Menor": "bg-yellow-100 text-yellow-800",
      "Dañado": "bg-orange-100 text-orange-800",
      "No Utilizable": "bg-red-100 text-red-800",
    };
    return styles[condition] || "bg-gray-100 text-gray-800";
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      "Disponible": "bg-blue-100 text-blue-800",
      "Prestado": "bg-purple-100 text-purple-800",
      "Dañado": "bg-red-100 text-red-800",
      "Perdido": "bg-gray-100 text-gray-800",
    };
    return styles[status] || "bg-gray-100 text-gray-800";
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-2">Gestión de Libros</h1>
          <p className="text-sm md:text-base text-slate-600">
            Administra el catálogo completo de la biblioteca
          </p>
        </div>
        <Link
          to="/books/add"
          className="px-4 md:px-6 py-3 bg-[#F97316] text-white rounded-lg hover:bg-[#EA580C] transition-colors flex items-center justify-center gap-2 text-sm md:text-base"
        >
          <Plus className="w-4 h-4 md:w-5 md:h-5" />
          Agregar Libro
        </Link>
      </div>

      {/* Search Bar */}
      <div className="bg-white rounded-lg shadow-md p-4">
        <div className="relative">
          <Search className="absolute left-3 md:left-4 top-1/2 -translate-y-1/2 w-4 h-4 md:w-5 md:h-5 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Buscar por título, autor o ISBN..."
            className="w-full pl-10 md:pl-12 pr-4 py-2.5 md:py-3 border-2 border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
          />
        </div>
      </div>

      {/* Statistics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">
        <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-[#F97316] bg-opacity-10 rounded-lg flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-5 h-5 md:w-6 md:h-6 text-[#F97316]" />
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-slate-800">{books.length}</p>
              <p className="text-xs md:text-sm text-slate-500">Total de Libros</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-5 h-5 md:w-6 md:h-6 text-green-600" />
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-slate-800">
                {books.filter((b) => b.condition === "Perfecto").length}
              </p>
              <p className="text-xs md:text-sm text-slate-500">Estado Perfecto</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-yellow-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-5 h-5 md:w-6 md:h-6 text-yellow-600" />
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-slate-800">
                {books.filter((b) => b.condition === "Daño Menor").length}
              </p>
              <p className="text-xs md:text-sm text-slate-500">Daño Menor</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <BookOpen className="w-5 h-5 md:w-6 md:h-6 text-red-600" />
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-slate-800">
                {books.filter(
                  (b) => b.condition === "Dañado" || b.condition === "No Utilizable"
                ).length}
              </p>
              <p className="text-xs md:text-sm text-slate-500">Dañados/No Utilizables</p>
            </div>
          </div>
        </div>
      </div>

      {/* Books Table - Desktop */}
      <div className="hidden lg:block bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">
                  Portada
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">
                  Título
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">
                  Autor
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">
                  ISBN
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">
                  Disponibilidad
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">
                  Condición
                </th>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700">
                  Acciones
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {filteredBooks.length > 0 ? (
                filteredBooks.map((book) => (
                  <tr key={book.id} className="hover:bg-slate-50 transition-colors">
                    <td className="px-6 py-4">
                      <div className="w-12 h-16 bg-gradient-to-br from-[#F97316] to-[#EA580C] rounded flex items-center justify-center">
                        <BookOpen className="w-6 h-6 text-white opacity-50" />
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <div className="max-w-xs">
                        <p className="font-medium text-slate-800 line-clamp-2">
                          {book.title}
                        </p>
                        <p className="text-sm text-slate-500">{book.category}</p>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-slate-700 max-w-[200px] line-clamp-2">
                        {book.author}
                      </p>
                    </td>
                    <td className="px-6 py-4">
                      <p className="text-slate-700 font-mono text-sm">{book.isbn}</p>
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadge(
                          book.status
                        )}`}
                      >
                        {book.status}
                      </span>
                      {book.status === "Disponible" && (
                        <p className="text-xs text-slate-500 mt-1">
                          {book.availableCopies}/{book.totalCopies} disponibles
                        </p>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${getConditionBadge(
                          book.condition
                        )}`}
                      >
                        {book.condition}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Link
                          to={`/books/${book.id}`}
                          className="p-2 text-slate-600 hover:text-[#F97316] hover:bg-slate-100 rounded-lg transition-colors"
                          title="Ver Ficha"
                        >
                          <Eye className="w-4 h-4" />
                        </Link>
                        <Link
                          to={`/books/${book.id}/edit`}
                          className="p-2 text-slate-600 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Editar"
                        >
                          <Edit className="w-4 h-4" />
                        </Link>
                        <button
                          onClick={() => handleDeleteClick(book.id)}
                          className="p-2 text-slate-600 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Eliminar"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center">
                    <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
                    <p className="text-slate-600">No se encontraron libros</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Books Grid - Mobile & Tablet */}
      <div className="lg:hidden space-y-4">
        {filteredBooks.length > 0 ? (
          filteredBooks.map((book) => (
            <div key={book.id} className="bg-white rounded-lg shadow-md p-4">
              <div className="flex gap-4">
                {/* Book Cover */}
                <div className="w-16 h-24 bg-gradient-to-br from-[#F97316] to-[#EA580C] rounded flex items-center justify-center flex-shrink-0">
                  <BookOpen className="w-8 h-8 text-white opacity-50" />
                </div>

                {/* Book Info */}
                <div className="flex-1 min-w-0">
                  <h3 className="font-semibold text-slate-800 mb-1 line-clamp-2">
                    {book.title}
                  </h3>
                  <p className="text-sm text-slate-600 mb-2 line-clamp-1">{book.author}</p>
                  <div className="flex flex-wrap gap-2 mb-2">
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBadge(
                        book.status
                      )}`}
                    >
                      {book.status}
                    </span>
                    <span
                      className={`px-2 py-1 rounded-full text-xs font-medium ${getConditionBadge(
                        book.condition
                      )}`}
                    >
                      {book.condition}
                    </span>
                  </div>
                  {book.status === "Disponible" && (
                    <p className="text-xs text-slate-500">
                      {book.availableCopies}/{book.totalCopies} disponibles
                    </p>
                  )}
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-2 mt-4 pt-4 border-t border-slate-200">
                <Link
                  to={`/books/${book.id}`}
                  className="flex-1 px-3 py-2 text-sm bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors flex items-center justify-center gap-2"
                >
                  <Eye className="w-4 h-4" />
                  Ver
                </Link>
                <Link
                  to={`/books/${book.id}/edit`}
                  className="flex-1 px-3 py-2 text-sm bg-blue-50 text-blue-700 rounded-lg hover:bg-blue-100 transition-colors flex items-center justify-center gap-2"
                >
                  <Edit className="w-4 h-4" />
                  Editar
                </Link>
                <button
                  onClick={() => handleDeleteClick(book.id)}
                  className="flex-1 px-3 py-2 text-sm bg-red-50 text-red-700 rounded-lg hover:bg-red-100 transition-colors flex items-center justify-center gap-2"
                >
                  <Trash2 className="w-4 h-4" />
                  Eliminar
                </button>
              </div>
            </div>
          ))
        ) : (
          <div className="bg-white rounded-lg shadow-md p-12 text-center">
            <BookOpen className="w-12 h-12 text-slate-300 mx-auto mb-3" />
            <p className="text-slate-600">No se encontraron libros</p>
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>¿Eliminar Libro?</AlertDialogTitle>
            <AlertDialogDescription>
              Esta acción no se puede deshacer. El libro{" "}
              <span className="font-semibold">
                "{books.find((b) => b.id === bookToDelete)?.title}"
              </span>{" "}
              será eliminado permanentemente del catálogo de la biblioteca.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancelar</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDeleteConfirm}
              className="bg-red-600 hover:bg-red-700"
            >
              Eliminar
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}