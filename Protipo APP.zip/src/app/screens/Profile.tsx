import { useNavigate } from "react-router";
import { 
  User, 
  Mail, 
  Phone, 
  MapPin, 
  Calendar, 
  BookOpen,
  CreditCard,
  Bell,
  Lock,
  HelpCircle,
  LogOut,
  ChevronRight,
  IdCard,
  Shield
} from "lucide-react";
import { MobileLayout } from "../components/MobileLayout";
import { mockLoans, getTotalFines } from "../data/mockLoans";

export function Profile() {
  const navigate = useNavigate();

  // Mock user data
  const user = {
    name: "Carlos Méndez",
    email: "carlos.mendez@universidad.edu.mx",
    matricula: "2021-0456",
    userType: "Estudiante",
    phone: "+52 55 1234 5678",
    address: "Ciudad Universitaria, CDMX",
    memberSince: "2021-08-15",
    avatar: null,
  };

  const totalLoans = mockLoans.length;
  const totalFines = getTotalFines();

  const handleLogout = () => {
    // In a real app, clear auth tokens here
    navigate("/login");
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-MX', { day: 'numeric', month: 'long', year: 'numeric' });
  };

  return (
    <MobileLayout>
      <div className="max-w-md mx-auto pb-6">
        {/* Profile Header */}
        <div className="bg-gradient-to-br from-[#F97316] to-[#EA580C] px-4 pt-6 pb-20 rounded-b-3xl">
          <div className="flex flex-col items-center">
            {/* Avatar */}
            <div className="w-24 h-24 rounded-full bg-white/20 backdrop-blur-sm border-4 border-white/30 flex items-center justify-center mb-3">
              <User className="w-12 h-12 text-white" />
            </div>
            
            {/* User Info */}
            <h1 className="text-white text-xl font-bold mb-1">{user.name}</h1>
            <p className="text-white/80 text-sm mb-1">{user.userType}</p>
            <div className="flex items-center gap-1.5 px-3 py-1 bg-white/20 backdrop-blur-sm rounded-full">
              <IdCard className="w-3.5 h-3.5 text-white" />
              <span className="text-white text-xs font-medium">{user.matricula}</span>
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="px-4 -mt-12 mb-6">
          <div className="bg-white rounded-xl shadow-lg p-4 grid grid-cols-2 gap-4">
            <div className="text-center">
              <div className="bg-blue-100 rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-2">
                <BookOpen className="w-6 h-6 text-blue-600" />
              </div>
              <p className="text-2xl font-bold text-slate-800">{totalLoans}</p>
              <p className="text-xs text-slate-600">Préstamos</p>
            </div>
            <div className="text-center">
              <div className={`${totalFines > 0 ? 'bg-red-100' : 'bg-green-100'} rounded-full w-12 h-12 flex items-center justify-center mx-auto mb-2`}>
                <CreditCard className={`w-6 h-6 ${totalFines > 0 ? 'text-red-600' : 'text-green-600'}`} />
              </div>
              <p className="text-2xl font-bold text-slate-800">${totalFines}</p>
              <p className="text-xs text-slate-600">Multas</p>
            </div>
          </div>
        </div>

        <div className="px-4 space-y-6">
          {/* Personal Information */}
          <div>
            <h2 className="text-sm font-semibold text-slate-500 uppercase mb-3 px-1">
              Información Personal
            </h2>
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <div className="p-4 border-b border-slate-100 flex items-center gap-3">
                <Mail className="w-5 h-5 text-slate-400" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-500">Correo Electrónico</p>
                  <p className="text-sm text-slate-800 truncate">{user.email}</p>
                </div>
              </div>
              
              <div className="p-4 border-b border-slate-100 flex items-center gap-3">
                <Phone className="w-5 h-5 text-slate-400" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-500">Teléfono</p>
                  <p className="text-sm text-slate-800">{user.phone}</p>
                </div>
              </div>
              
              <div className="p-4 border-b border-slate-100 flex items-center gap-3">
                <MapPin className="w-5 h-5 text-slate-400" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-500">Dirección</p>
                  <p className="text-sm text-slate-800">{user.address}</p>
                </div>
              </div>
              
              <div className="p-4 flex items-center gap-3">
                <Calendar className="w-5 h-5 text-slate-400" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-500">Miembro Desde</p>
                  <p className="text-sm text-slate-800">{formatDate(user.memberSince)}</p>
                </div>
              </div>
            </div>
          </div>

          {/* Account Settings */}
          <div>
            <h2 className="text-sm font-semibold text-slate-500 uppercase mb-3 px-1">
              Configuración de Cuenta
            </h2>
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <button className="w-full p-4 border-b border-slate-100 flex items-center gap-3 hover:bg-slate-50 transition-colors">
                <div className="bg-slate-100 rounded-full p-2">
                  <Bell className="w-5 h-5 text-slate-600" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium text-slate-800">Notificaciones</p>
                  <p className="text-xs text-slate-500">Alertas y recordatorios</p>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </button>
              
              <button className="w-full p-4 border-b border-slate-100 flex items-center gap-3 hover:bg-slate-50 transition-colors">
                <div className="bg-slate-100 rounded-full p-2">
                  <Lock className="w-5 h-5 text-slate-600" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium text-slate-800">Cambiar Contraseña</p>
                  <p className="text-xs text-slate-500">Seguridad de la cuenta</p>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </button>
              
              <button className="w-full p-4 flex items-center gap-3 hover:bg-slate-50 transition-colors">
                <div className="bg-slate-100 rounded-full p-2">
                  <Shield className="w-5 h-5 text-slate-600" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium text-slate-800">Privacidad</p>
                  <p className="text-xs text-slate-500">Controla tus datos</p>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </button>
            </div>
          </div>

          {/* Support */}
          <div>
            <h2 className="text-sm font-semibold text-slate-500 uppercase mb-3 px-1">
              Soporte
            </h2>
            <div className="bg-white rounded-xl shadow-md overflow-hidden">
              <button className="w-full p-4 border-b border-slate-100 flex items-center gap-3 hover:bg-slate-50 transition-colors">
                <div className="bg-slate-100 rounded-full p-2">
                  <HelpCircle className="w-5 h-5 text-slate-600" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium text-slate-800">Centro de Ayuda</p>
                  <p className="text-xs text-slate-500">FAQs y guías</p>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </button>
              
              <button className="w-full p-4 flex items-center gap-3 hover:bg-slate-50 transition-colors">
                <div className="bg-slate-100 rounded-full p-2">
                  <Mail className="w-5 h-5 text-slate-600" />
                </div>
                <div className="flex-1 text-left">
                  <p className="text-sm font-medium text-slate-800">Contactar Soporte</p>
                  <p className="text-xs text-slate-500">Envíanos un mensaje</p>
                </div>
                <ChevronRight className="w-5 h-5 text-slate-400" />
              </button>
            </div>
          </div>

          {/* Logout Button */}
          <button
            onClick={handleLogout}
            className="w-full bg-red-500 hover:bg-red-600 text-white rounded-xl p-4 flex items-center justify-center gap-2 font-medium transition-colors shadow-md"
          >
            <LogOut className="w-5 h-5" />
            Cerrar Sesión
          </button>

          {/* App Version */}
          <div className="text-center">
            <p className="text-xs text-slate-400">
              Sistema de Biblioteca Universitaria
            </p>
            <p className="text-xs text-slate-400 mt-1">
              Versión 1.0.0
            </p>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
