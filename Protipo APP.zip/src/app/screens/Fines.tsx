import { Link } from "react-router";
import { 
  AlertCircle, 
  DollarSign, 
  Calendar, 
  BookOpen,
  CheckCircle,
  CreditCard,
  Info
} from "lucide-react";
import { MobileLayout } from "../components/MobileLayout";
import { mockFines, getTotalFines } from "../data/mockLoans";

export function Fines() {
  const totalFines = getTotalFines();
  const pendingFines = mockFines.filter(fine => fine.status === "Pendiente");
  const paidFines = mockFines.filter(fine => fine.status === "Pagada");

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-MX', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  return (
    <MobileLayout>
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="bg-white border-b border-slate-200 px-4 py-4 sticky top-0 z-10">
          <h1 className="text-xl font-bold text-slate-800">Multas</h1>
          <p className="text-sm text-slate-600 mt-1">
            {pendingFines.length} multa{pendingFines.length !== 1 ? 's' : ''} pendiente{pendingFines.length !== 1 ? 's' : ''}
          </p>
        </div>

        <div className="px-4 py-4 space-y-4">
          {/* Total Balance */}
          <div className={`rounded-xl p-6 ${
            totalFines > 0 
              ? 'bg-gradient-to-br from-red-500 to-red-600' 
              : 'bg-gradient-to-br from-green-500 to-green-600'
          }`}>
            <div className="flex items-center justify-between mb-2">
              <p className="text-white/80 text-sm">Total a Pagar</p>
              {totalFines > 0 ? (
                <AlertCircle className="w-5 h-5 text-white" />
              ) : (
                <CheckCircle className="w-5 h-5 text-white" />
              )}
            </div>
            <div className="flex items-baseline gap-2 mb-4">
              <span className="text-white text-4xl font-bold">
                ${totalFines.toFixed(2)}
              </span>
              <span className="text-white/80 text-sm">MXN</span>
            </div>
            {totalFines > 0 ? (
              <button className="w-full bg-white text-red-600 font-semibold py-3 rounded-lg hover:bg-red-50 transition-colors flex items-center justify-center gap-2">
                <CreditCard className="w-5 h-5" />
                Pagar Ahora
              </button>
            ) : (
              <div className="text-white text-sm flex items-center gap-2">
                <CheckCircle className="w-4 h-4" />
                No tienes multas pendientes
              </div>
            )}
          </div>

          {/* Pending Fines */}
          {pendingFines.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-slate-800 mb-3">
                Multas Pendientes
              </h2>
              <div className="space-y-3">
                {pendingFines.map((fine) => (
                  <div
                    key={fine.id}
                    className="bg-white rounded-xl shadow-md overflow-hidden border-l-4 border-red-500"
                  >
                    <div className="p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h3 className="text-sm font-semibold text-slate-800 mb-1">
                            {fine.bookTitle}
                          </h3>
                          <div className="flex items-center gap-2 text-xs text-slate-600">
                            <Calendar className="w-3.5 h-3.5" />
                            <span>Vencido: {formatDate(fine.dueDate)}</span>
                          </div>
                        </div>
                        <div className="flex flex-col items-end">
                          <span className="text-2xl font-bold text-red-600">
                            ${fine.amount.toFixed(2)}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-4 pt-3 border-t border-slate-100">
                        <div className="flex items-center gap-2 text-xs text-slate-600">
                          <AlertCircle className="w-3.5 h-3.5 text-red-500" />
                          <span>{fine.daysLate} día{fine.daysLate !== 1 ? 's' : ''} de retraso</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-slate-600">
                          <DollarSign className="w-3.5 h-3.5" />
                          <span>$5.00 por día</span>
                        </div>
                      </div>
                    </div>

                    <div className="bg-red-50 px-4 py-2 flex items-center justify-between">
                      <Link
                        to={`/loans`}
                        className="text-xs text-red-700 hover:text-red-800 font-medium flex items-center gap-1"
                      >
                        <BookOpen className="w-3.5 h-3.5" />
                        Ver préstamo
                      </Link>
                      <button className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white rounded-lg text-xs font-medium transition-colors">
                        Pagar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Paid Fines History */}
          {paidFines.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-slate-800 mb-3">
                Historial de Pagos
              </h2>
              <div className="space-y-3">
                {paidFines.map((fine) => (
                  <div
                    key={fine.id}
                    className="bg-white rounded-xl shadow-md overflow-hidden border-l-4 border-green-500"
                  >
                    <div className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h3 className="text-sm font-semibold text-slate-800 mb-1">
                            {fine.bookTitle}
                          </h3>
                          <div className="flex items-center gap-2 text-xs text-slate-600">
                            <CheckCircle className="w-3.5 h-3.5 text-green-600" />
                            <span>Pagada</span>
                          </div>
                        </div>
                        <div className="flex flex-col items-end">
                          <span className="text-xl font-bold text-green-600">
                            ${fine.amount.toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* No Fines */}
          {pendingFines.length === 0 && paidFines.length === 0 && (
            <div className="bg-white rounded-xl shadow-md p-8 text-center">
              <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-800 mb-2">
                ¡Excelente!
              </h3>
              <p className="text-sm text-slate-600 mb-6">
                No tienes multas pendientes
              </p>
              <p className="text-xs text-slate-500">
                Sigue devolviendo tus libros a tiempo
              </p>
            </div>
          )}

          {/* Info Box */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <div className="flex gap-3">
              <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-medium text-blue-900 mb-1">
                  Información sobre multas
                </p>
                <ul className="text-xs text-blue-800 space-y-1">
                  <li>• Las multas se calculan a $5.00 por día de retraso</li>
                  <li>• Puedes pagar en la biblioteca o en línea</li>
                  <li>• Con multas pendientes no puedes solicitar nuevos préstamos</li>
                  <li>• Devuelve a tiempo para evitar cargos adicionales</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Payment Methods */}
          {totalFines > 0 && (
            <div className="bg-white rounded-xl shadow-md p-4">
              <h3 className="text-sm font-semibold text-slate-800 mb-3">
                Métodos de Pago
              </h3>
              <div className="space-y-2">
                <div className="flex items-center gap-3 p-3 border border-slate-200 rounded-lg hover:border-[#F97316] cursor-pointer transition-colors">
                  <CreditCard className="w-5 h-5 text-slate-600" />
                  <div>
                    <p className="text-sm font-medium text-slate-800">Tarjeta de Crédito/Débito</p>
                    <p className="text-xs text-slate-500">Pago en línea seguro</p>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 border border-slate-200 rounded-lg hover:border-[#F97316] cursor-pointer transition-colors">
                  <DollarSign className="w-5 h-5 text-slate-600" />
                  <div>
                    <p className="text-sm font-medium text-slate-800">Efectivo en Biblioteca</p>
                    <p className="text-xs text-slate-500">Paga en el mostrador</p>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </MobileLayout>
  );
}
