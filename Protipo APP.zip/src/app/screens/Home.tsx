import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { 
  Search, 
  BookOpen, 
  Clock, 
  AlertCircle, 
  TrendingUp,
  Library,
  Star,
  ChevronRight
} from "lucide-react";
import { MobileLayout } from "../components/MobileLayout";
import { mockBooks } from "../data/mockBooks";
import { mockLoans, getTotalFines } from "../data/mockLoans";

export function Home() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");

  // Get user info (mock)
  const userName = "Carlos Méndez";

  // Get recommended books (top 6)
  const recommendedBooks = mockBooks.filter(book => book.status === "Disponible").slice(0, 6);

  // Get active loans count
  const activeLoans = mockLoans.filter(loan => loan.status !== "Activo" || loan.status === "Por Vencer").length;

  // Get total fines
  const totalFines = getTotalFines();

  // Get overdue loans
  const overdueLoans = mockLoans.filter(loan => loan.status === "Vencido").length;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search/results?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  return (
    <MobileLayout>
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="bg-gradient-to-br from-[#F97316] to-[#EA580C] px-4 py-6 rounded-b-3xl shadow-lg">
          <div className="flex items-center justify-between mb-6">
            <div>
              <p className="text-white/80 text-sm">Bienvenido</p>
              <h1 className="text-white text-xl font-bold">{userName}</h1>
            </div>
            <div className="bg-white/20 backdrop-blur-sm rounded-full p-3">
              <Library className="w-6 h-6 text-white" />
            </div>
          </div>

          {/* Search Bar */}
          <form onSubmit={handleSearch}>
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar libros, autores..."
                className="w-full pl-12 pr-4 py-3.5 bg-white rounded-full focus:outline-none focus:ring-2 focus:ring-white/50 shadow-md text-base"
              />
            </div>
          </form>
        </div>

        <div className="px-4 py-6 space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-3 gap-3">
            <Link
              to="/loans"
              className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="flex flex-col items-center text-center">
                <div className="bg-blue-100 rounded-full p-3 mb-2">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                </div>
                <p className="text-2xl font-bold text-slate-800">{mockLoans.length}</p>
                <p className="text-xs text-slate-600 mt-1">Préstamos</p>
              </div>
            </Link>

            <Link
              to="/loans"
              className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="flex flex-col items-center text-center">
                <div className={`${overdueLoans > 0 ? 'bg-red-100' : 'bg-green-100'} rounded-full p-3 mb-2`}>
                  <Clock className={`w-5 h-5 ${overdueLoans > 0 ? 'text-red-600' : 'text-green-600'}`} />
                </div>
                <p className="text-2xl font-bold text-slate-800">{overdueLoans}</p>
                <p className="text-xs text-slate-600 mt-1">Vencidos</p>
              </div>
            </Link>

            <Link
              to="/fines"
              className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-shadow"
            >
              <div className="flex flex-col items-center text-center">
                <div className={`${totalFines > 0 ? 'bg-yellow-100' : 'bg-green-100'} rounded-full p-3 mb-2`}>
                  <AlertCircle className={`w-5 h-5 ${totalFines > 0 ? 'text-yellow-600' : 'text-green-600'}`} />
                </div>
                <p className="text-2xl font-bold text-slate-800">${totalFines}</p>
                <p className="text-xs text-slate-600 mt-1">Multas</p>
              </div>
            </Link>
          </div>

          {/* Alerts */}
          {overdueLoans > 0 && (
            <Link
              to="/loans"
              className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start gap-3"
            >
              <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-semibold text-red-900">
                  Tienes {overdueLoans} préstamo{overdueLoans > 1 ? 's' : ''} vencido{overdueLoans > 1 ? 's' : ''}
                </p>
                <p className="text-xs text-red-700 mt-1">
                  Devuélvelo{overdueLoans > 1 ? 's' : ''} pronto para evitar multas adicionales
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-red-600 flex-shrink-0" />
            </Link>
          )}

          {totalFines > 0 && (
            <Link
              to="/fines"
              className="bg-yellow-50 border border-yellow-200 rounded-xl p-4 flex items-start gap-3"
            >
              <AlertCircle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="text-sm font-semibold text-yellow-900">
                  Tienes multas pendientes
                </p>
                <p className="text-xs text-yellow-700 mt-1">
                  Total a pagar: ${totalFines.toFixed(2)}
                </p>
              </div>
              <ChevronRight className="w-5 h-5 text-yellow-600 flex-shrink-0" />
            </Link>
          )}

          {/* Quick Actions */}
          <div>
            <h2 className="text-lg font-semibold text-slate-800 mb-3 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-[#F97316]" />
              Accesos Rápidos
            </h2>
            <div className="grid grid-cols-2 gap-3">
              <Link
                to="/search"
                className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-shadow flex flex-col items-center text-center"
              >
                <div className="bg-[#F97316]/10 rounded-full p-3 mb-2">
                  <Search className="w-6 h-6 text-[#F97316]" />
                </div>
                <p className="text-sm font-medium text-slate-800">Buscar Libros</p>
              </Link>

              <Link
                to="/loans"
                className="bg-white rounded-xl p-4 shadow-md hover:shadow-lg transition-shadow flex flex-col items-center text-center"
              >
                <div className="bg-blue-100 rounded-full p-3 mb-2">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
                <p className="text-sm font-medium text-slate-800">Mis Préstamos</p>
              </Link>
            </div>
          </div>

          {/* Recommended Books */}
          <div>
            <div className="flex items-center justify-between mb-3">
              <h2 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                <Star className="w-5 h-5 text-[#F97316]" />
                Libros Recomendados
              </h2>
              <Link to="/search" className="text-sm text-[#F97316] font-medium hover:text-[#EA580C]">
                Ver todos
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-3">
              {recommendedBooks.map((book) => (
                <Link
                  key={book.id}
                  to={`/book/${book.id}`}
                  className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow overflow-hidden"
                >
                  <div className="aspect-[3/4] bg-gradient-to-br from-[#F97316] to-[#EA580C] flex items-center justify-center">
                    <BookOpen className="w-12 h-12 text-white opacity-50" />
                  </div>
                  <div className="p-3">
                    <h3 className="text-sm font-semibold text-slate-800 line-clamp-2 mb-1">
                      {book.title}
                    </h3>
                    <p className="text-xs text-slate-600 line-clamp-1">{book.author}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}
