import { useState } from "react";
import { Send, Bot, User as UserIcon, HelpCircle, BookOpen, Search, Clock } from "lucide-react";

interface Message {
  id: string;
  text: string;
  sender: "user" | "bot";
  timestamp: Date;
}

const FAQ_RESPONSES: Record<string, string> = {
  "buscar libro": "Para buscar un libro, usa la barra de búsqueda en la parte superior del Catálogo de Libros. Puedes buscar por título, autor, categoría o ISBN. También puedes usar los filtros rápidos para encontrar libros más específicos.",
  "disponibilidad": "Para verificar si un libro está disponible, busca el libro en el catálogo y haz clic en él. En la página de detalles verás el estado actual del libro (Disponible, Prestado, Dañado o Perdido) y cuántas copias están disponibles.",
  "préstamo": "Para solicitar un préstamo, ve a la página de detalles del libro y haz clic en 'Solicitar Préstamo'. El libro debe estar disponible. Un bibliotecario procesará tu solicitud y te notificará cuando puedas recogerlo.",
  "reservar": "Si un libro está prestado, puedes reservarlo para cuando esté disponible. Ve a la página del libro y haz clic en 'Reservar'. Te notificaremos cuando el libro esté disponible para ti.",
  "devolución": "Para devolver un libro, dirígete al mostrador de préstamos en la biblioteca con tu credencial universitaria. El personal procesará la devolución y actualizará tu cuenta.",
  "multa": "Las multas se generan por devoluciones tardías. Puedes ver tus multas pendientes en tu perfil de usuario. Dirígete al mostrador de servicios para realizar el pago.",
  "renovar": "Puedes renovar tus préstamos desde tu perfil de usuario, en la sección 'Mis Préstamos'. Solo puedes renovar si no hay reservas pendientes para ese libro.",
  "horario": "La biblioteca está abierta de lunes a viernes de 8:00 AM a 8:00 PM, y sábados de 9:00 AM a 2:00 PM. Los préstamos se realizan hasta 30 minutos antes del cierre.",
};

const QUICK_QUESTIONS = [
  "¿Cómo busco un libro?",
  "¿Cómo verifico la disponibilidad?",
  "¿Cómo solicito un préstamo?",
  "¿Cómo reservo un libro?",
  "¿Cómo devuelvo un libro?",
  "¿Qué son las multas?",
  "¿Puedo renovar un préstamo?",
  "¿Cuál es el horario?",
];

export function HelpChatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "¡Hola! Soy el asistente virtual de la biblioteca. ¿En qué puedo ayudarte hoy?",
      sender: "bot",
      timestamp: new Date(),
    },
  ]);
  const [inputMessage, setInputMessage] = useState("");

  const findResponse = (userMessage: string): string => {
    const lowerMessage = userMessage.toLowerCase();

    for (const [keyword, response] of Object.entries(FAQ_RESPONSES)) {
      if (lowerMessage.includes(keyword)) {
        return response;
      }
    }

    // Respuestas por palabras clave adicionales
    if (lowerMessage.includes("hola") || lowerMessage.includes("buenos") || lowerMessage.includes("ayuda")) {
      return "¡Hola! Estoy aquí para ayudarte. Puedes preguntarme sobre cómo buscar libros, verificar disponibilidad, solicitar préstamos, reservar libros, o cualquier otra consulta sobre la biblioteca.";
    }

    if (lowerMessage.includes("gracias")) {
      return "¡De nada! Si tienes más preguntas, no dudes en consultarme. Estoy aquí para ayudarte.";
    }

    if (lowerMessage.includes("catálogo")) {
      return "Nuestro catálogo tiene más de 20 títulos en diversas categorías como Ciencias de la Computación, Ingeniería, Matemáticas, Física, Biología, y más. Usa la búsqueda para encontrar el libro que necesitas.";
    }

    return "No estoy seguro de entender tu pregunta. Puedo ayudarte con información sobre búsqueda de libros, préstamos, devoluciones, reservas, multas y horarios de la biblioteca. ¿Sobre qué te gustaría saber?";
  };

  const handleSendMessage = (text?: string) => {
    const messageText = text || inputMessage.trim();
    if (!messageText) return;

    // Agregar mensaje del usuario
    const userMessage: Message = {
      id: Date.now().toString(),
      text: messageText,
      sender: "user",
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInputMessage("");

    // Simular delay de respuesta del bot
    setTimeout(() => {
      const botResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: findResponse(messageText),
        sender: "bot",
        timestamp: new Date(),
      };
      setMessages((prev) => [...prev, botResponse]);
    }, 500);
  };

  const handleQuickQuestion = (question: string) => {
    handleSendMessage(question);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage();
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-[#1E293B] to-[#334155] rounded-lg p-6 text-white">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 bg-[#F97316] rounded-full flex items-center justify-center">
            <Bot className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-3xl font-bold mb-1">Asistente Virtual</h1>
            <p className="text-slate-300">Estoy aquí para ayudarte con cualquier consulta sobre la biblioteca</p>
          </div>
        </div>
      </div>

      {/* Chat Container */}
      <div className="bg-white rounded-lg shadow-md overflow-hidden">
        {/* Messages Area */}
        <div className="h-[500px] overflow-y-auto p-6 space-y-4 bg-slate-50">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.sender === "user" ? "flex-row-reverse" : "flex-row"}`}
            >
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                  message.sender === "user" ? "bg-[#F97316]" : "bg-[#1E293B]"
                }`}
              >
                {message.sender === "user" ? (
                  <UserIcon className="w-5 h-5 text-white" />
                ) : (
                  <Bot className="w-5 h-5 text-white" />
                )}
              </div>
              <div
                className={`max-w-[70%] rounded-lg p-4 ${
                  message.sender === "user"
                    ? "bg-[#F97316] text-white"
                    : "bg-white text-slate-800 border border-slate-200"
                }`}
              >
                <p className="text-sm leading-relaxed">{message.text}</p>
                <p
                  className={`text-xs mt-2 ${
                    message.sender === "user" ? "text-orange-100" : "text-slate-400"
                  }`}
                >
                  {message.timestamp.toLocaleTimeString("es-ES", {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Quick Questions */}
        {messages.length <= 2 && (
          <div className="px-6 py-4 bg-white border-t border-slate-200">
            <p className="text-sm font-medium text-slate-700 mb-3 flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-[#F97316]" />
              Preguntas frecuentes:
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {QUICK_QUESTIONS.map((question, index) => (
                <button
                  key={index}
                  onClick={() => handleQuickQuestion(question)}
                  className="text-left px-3 py-2 bg-slate-50 hover:bg-[#F97316] hover:text-white rounded-lg transition-colors text-sm"
                >
                  {question}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input Area */}
        <form onSubmit={handleSubmit} className="p-4 bg-white border-t border-slate-200">
          <div className="flex gap-3">
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Escribe tu pregunta aquí..."
              className="flex-1 px-4 py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim()}
              className="px-6 py-3 bg-[#F97316] text-white rounded-lg hover:bg-[#EA580C] transition-colors disabled:bg-slate-200 disabled:text-slate-400 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <Send className="w-5 h-5" />
              Enviar
            </button>
          </div>
        </form>
      </div>

      {/* Help Resources */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="w-12 h-12 bg-[#F97316] bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
            <BookOpen className="w-6 h-6 text-[#F97316]" />
          </div>
          <h3 className="font-semibold text-slate-800 mb-2">Guía de Búsqueda</h3>
          <p className="text-sm text-slate-600">
            Aprende a usar nuestro catálogo digital para encontrar el libro perfecto para tus necesidades.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="w-12 h-12 bg-[#F97316] bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
            <Search className="w-6 h-6 text-[#F97316]" />
          </div>
          <h3 className="font-semibold text-slate-800 mb-2">Preguntas Frecuentes</h3>
          <p className="text-sm text-slate-600">
            Encuentra respuestas rápidas a las preguntas más comunes sobre nuestros servicios.
          </p>
        </div>

        <div className="bg-white rounded-lg shadow-md p-6">
          <div className="w-12 h-12 bg-[#F97316] bg-opacity-10 rounded-lg flex items-center justify-center mb-4">
            <Clock className="w-6 h-6 text-[#F97316]" />
          </div>
          <h3 className="font-semibold text-slate-800 mb-2">Horarios</h3>
          <p className="text-sm text-slate-600">
            Lunes a Viernes: 8:00 AM - 8:00 PM<br />
            Sábados: 9:00 AM - 2:00 PM
          </p>
        </div>
      </div>
    </div>
  );
}
