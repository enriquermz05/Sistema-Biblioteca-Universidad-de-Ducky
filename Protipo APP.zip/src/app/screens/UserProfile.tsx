import { useState } from "react";
import { useParams, useNavigate } from "react-router";
import { ArrowLeft, Mail, Phone, Calendar, Ban, Edit, AlertTriangle } from "lucide-react";
import { Button } from "../components/ui/button";
import { Badge } from "../components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "../components/ui/dialog";
import { mockUsers, UserRole } from "../data/mockUsers";
import { toast } from "sonner";

export function UserProfile() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [showSuspendModal, setShowSuspendModal] = useState(false);

  const user = mockUsers.find((u) => u.id === id);

  if (!user) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold text-[#111827]">Usuario no encontrado</h2>
        <Button onClick={() => navigate("/users")} className="mt-4">
          Volver a Gestión de Usuarios
        </Button>
      </div>
    );
  }

  const getRoleColor = (role: UserRole) => {
    switch (role) {
      case "Administrador":
        return "bg-purple-100 text-purple-700 border-purple-300";
      case "Bibliotecario":
        return "bg-blue-100 text-blue-700 border-blue-300";
      case "Profesor":
        return "bg-orange-100 text-orange-700 border-orange-300";
      case "Estudiante":
        return "bg-emerald-100 text-emerald-700 border-emerald-300";
      case "Colaborador":
        return "bg-amber-100 text-amber-700 border-amber-300";
      default:
        return "bg-slate-100 text-slate-700 border-slate-300";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Activo":
        return "bg-green-100 text-green-700 border-green-300";
      case "Suspendido":
        return "bg-red-100 text-red-700 border-red-300";
      case "Inactivo":
        return "bg-slate-100 text-slate-700 border-slate-300";
      default:
        return "bg-slate-100 text-slate-700 border-slate-300";
    }
  };

  const getLoanStatusColor = (status: string) => {
    switch (status) {
      case "Activo":
        return "bg-blue-100 text-blue-700 border-blue-300";
      case "Vencido":
        return "bg-red-100 text-red-700 border-red-300";
      case "Devuelto":
        return "bg-green-100 text-green-700 border-green-300";
      default:
        return "bg-slate-100 text-slate-700 border-slate-300";
    }
  };

  const getFineStatusColor = (status: string) => {
    switch (status) {
      case "Pendiente":
        return "bg-red-100 text-red-700 border-red-300";
      case "Pagado":
        return "bg-green-100 text-green-700 border-green-300";
      default:
        return "bg-slate-100 text-slate-700 border-slate-300";
    }
  };

  const handleSuspend = () => {
    // In a real app, this would update the backend
    toast.success("Usuario suspendido exitosamente", {
      description: `La cuenta de ${user?.name} ha sido suspendida.`,
      duration: 3000,
    });
    setShowSuspendModal(false);
    navigate("/users");
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <Button
          variant="ghost"
          onClick={() => navigate("/users")}
          className="mb-4 text-slate-600 hover:text-[#F97316]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver a Gestión de Usuarios
        </Button>
        <div className="flex items-start justify-between">
          <div>
            <h1 className="text-3xl font-bold text-[#111827]">{user.name}</h1>
            <p className="text-slate-600 mt-1">{user.universityId}</p>
            {/* Fines Indicator */}
            {user.bookFines.filter(f => f.status === "Pendiente").length > 0 && (
              <div className="mt-3 inline-flex items-center gap-2 px-3 py-2 bg-orange-50 border border-orange-300 rounded-lg">
                <AlertTriangle className="w-4 h-4 text-orange-600" />
                <div className="text-sm">
                  <span className="font-semibold text-orange-800">
                    Multas activas: {user.bookFines.filter(f => f.status === "Pendiente").length}
                  </span>
                  <span className="text-orange-600 ml-2">
                    | Total adeudo: ${user.bookFines.filter(f => f.status === "Pendiente").reduce((sum, f) => sum + f.replacementPrice, 0).toFixed(2)} MXN
                  </span>
                </div>
              </div>
            )}
          </div>
          <div className="flex gap-2">
            <Button
              variant="outline"
              onClick={() => navigate(`/users/${id}/edit`)}
              className="border-[#F97316] text-[#F97316] hover:bg-orange-50"
            >
              <Edit className="w-4 h-4 mr-2" />
              Editar Usuario
            </Button>
            {user.status !== "Suspendido" && (
              <Button
                variant="outline"
                onClick={() => setShowSuspendModal(true)}
                className="border-red-600 text-red-600 hover:bg-red-50"
              >
                <Ban className="w-4 h-4 mr-2" />
                Suspender Usuario
              </Button>
            )}
          </div>
        </div>
      </div>

      {/* User Information Card */}
      <Card className="border-slate-200">
        <CardHeader className="bg-slate-50">
          <CardTitle className="text-[#111827]">Información del Usuario</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <p className="text-sm text-slate-500 mb-1">Rol</p>
                <Badge className={`${getRoleColor(user.role)} border text-base px-3 py-1`}>
                  {user.role}
                </Badge>
              </div>
              <div>
                <p className="text-sm text-slate-500 mb-1">Estado</p>
                <Badge className={`${getStatusColor(user.status)} border text-base px-3 py-1`}>
                  {user.status}
                </Badge>
              </div>
              <div className="flex items-center gap-2 text-slate-700">
                <Mail className="w-4 h-4 text-slate-400" />
                <span>{user.email}</span>
              </div>
              <div className="flex items-center gap-2 text-slate-700">
                <Phone className="w-4 h-4 text-slate-400" />
                <span>{user.phone}</span>
              </div>
            </div>
            <div className="space-y-4">
              {user.department && (
                <div>
                  <p className="text-sm text-slate-500 mb-1">Departamento</p>
                  <p className="text-slate-700 font-medium">{user.department}</p>
                </div>
              )}
              <div className="flex items-center gap-2 text-slate-700">
                <Calendar className="w-4 h-4 text-slate-400" />
                <span>Registrado el {user.joinedDate}</span>
              </div>
              <div>
                <p className="text-sm text-slate-500 mb-1">Préstamos Activos</p>
                <p className="text-2xl font-bold text-[#F97316]">{user.activeLoans}</p>
              </div>
              <div>
                <p className="text-sm text-slate-500 mb-1">Multas Pendientes</p>
                <p
                  className={`text-2xl font-bold ${
                    user.fines > 0 ? "text-red-600" : "text-green-600"
                  }`}
                >
                  ${user.fines.toFixed(2)}
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Active Loans */}
      <Card className="border-slate-200">
        <CardHeader className="bg-slate-50">
          <CardTitle className="text-[#111827]">Préstamos Activos</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          {user.loans.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Título del Libro</TableHead>
                  <TableHead>Fecha de Préstamo</TableHead>
                  <TableHead>Fecha de Vencimiento</TableHead>
                  <TableHead>Estado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {user.loans.map((loan) => (
                  <TableRow key={loan.id}>
                    <TableCell className="font-medium text-[#111827]">
                      {loan.bookTitle}
                    </TableCell>
                    <TableCell className="text-slate-600">{loan.borrowDate}</TableCell>
                    <TableCell className="text-slate-600">{loan.dueDate}</TableCell>
                    <TableCell>
                      <Badge className={`${getLoanStatusColor(loan.status)} border`}>
                        {loan.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-slate-500 text-center py-8">Sin préstamos activos</p>
          )}
        </CardContent>
      </Card>

      {/* Book Fines - Multas del Usuario */}
      <Card className="border-slate-200">
        <CardHeader className="bg-slate-50">
          <CardTitle className="text-[#111827]">Multas del Usuario</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          {user.bookFines.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Libro</TableHead>
                  <TableHead>Motivo</TableHead>
                  <TableHead>Precio de reposición</TableHead>
                  <TableHead>Estado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {user.bookFines.map((fine) => (
                  <TableRow key={fine.id}>
                    <TableCell className="font-medium text-[#111827]">
                      {fine.bookTitle}
                    </TableCell>
                    <TableCell className="text-slate-600">{fine.reason}</TableCell>
                    <TableCell className="font-semibold text-red-600">
                      ${fine.replacementPrice.toFixed(2)} MXN
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getFineStatusColor(fine.status)} border`}>
                        {fine.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-slate-500 text-center py-8">Sin multas por libros</p>
          )}
        </CardContent>
      </Card>

      {/* Fine History */}
      <Card className="border-slate-200">
        <CardHeader className="bg-slate-50">
          <CardTitle className="text-[#111827]">Historial de Multas</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          {user.fineHistory.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Fecha</TableHead>
                  <TableHead>Razón</TableHead>
                  <TableHead>Monto</TableHead>
                  <TableHead>Estado</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {user.fineHistory.map((fine) => (
                  <TableRow key={fine.id}>
                    <TableCell className="text-slate-600">{fine.date}</TableCell>
                    <TableCell className="text-[#111827]">{fine.reason}</TableCell>
                    <TableCell className="font-semibold text-red-600">
                      ${fine.amount.toFixed(2)}
                    </TableCell>
                    <TableCell>
                      <Badge className={`${getFineStatusColor(fine.status)} border`}>
                        {fine.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <p className="text-slate-500 text-center py-8">Sin historial de multas</p>
          )}
        </CardContent>
      </Card>

      {/* Suspend User Modal */}
      <Dialog open={showSuspendModal} onOpenChange={setShowSuspendModal}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#111827] flex items-center gap-2">
              <Ban className="w-5 h-5 text-red-600" />
              Suspender Cuenta de Usuario
            </DialogTitle>
            <DialogDescription className="text-slate-600">
              Esta acción suspenderá la cuenta del usuario y le impedirá tomar prestados libros
              o acceder a los servicios de la biblioteca.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-sm text-red-800">
                <strong>Usuario:</strong> {user.name}
              </p>
              <p className="text-sm text-red-800 mt-1">
                <strong>ID:</strong> {user.universityId}
              </p>
              <p className="text-sm text-red-800 mt-1">
                <strong>Multas Pendientes:</strong> ${user.fines.toFixed(2)}
              </p>
            </div>
            <p className="text-sm text-slate-600">
              El usuario deberá liquidar todas las multas pendientes y devolver todos los libros
              prestados antes de que su cuenta pueda ser reactivada.
            </p>
          </div>
          <DialogFooter className="gap-2 sm:gap-0">
            <Button
              variant="outline"
              onClick={() => setShowSuspendModal(false)}
              className="border-slate-300"
            >
              Cancelar
            </Button>
            <Button
              onClick={handleSuspend}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              <Ban className="w-4 h-4 mr-2" />
              Suspender Usuario
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}