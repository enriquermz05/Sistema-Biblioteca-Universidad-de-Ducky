import { useState, useEffect } from "react";
import { Link, useParams, useNavigate } from "react-router";
import { ArrowLeft, BookOpen, User as UserIcon, Calendar, MapPin, Hash, Globe, FileText, CheckCircle, XCircle, Clock, AlertCircle, DollarSign, AlertTriangle } from "lucide-react";
import { mockBooks } from "../data/mockBooks";
import { mockReservations, addReservation, addLoanRequest, isBookReserved, type Reservation } from "../data/mockReservations";
import { mockLoans, isBookLoaned, type Loan } from "../data/mockLoans";
import { MobileLayout } from "../components/MobileLayout";
import { toast } from "sonner";

export function BookDetails() {
  const { id } = useParams();
  const navigate = useNavigate();
  const book = mockBooks.find((b) => b.id === id);

  // State for loans and reservations
  const [loans, setLoans] = useState<Loan[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);
  const [isReserved, setIsReserved] = useState(false);
  const [hasActiveLoan, setHasActiveLoan] = useState(false);
  const [hasPendingRequest, setHasPendingRequest] = useState(false);

  // Load loans from localStorage
  useEffect(() => {
    const savedLoans = localStorage.getItem('userLoans');
    if (savedLoans) {
      const parsed = JSON.parse(savedLoans);
      setLoans(parsed);
      if (book) {
        setHasActiveLoan(isBookLoaned(book.id, parsed));
      }
    } else {
      // Initialize with mock data
      localStorage.setItem('userLoans', JSON.stringify(mockLoans));
      setLoans(mockLoans);
      if (book) {
        setHasActiveLoan(isBookLoaned(book.id, mockLoans));
      }
    }
  }, [book]);

  // Load reservations from localStorage on mount
  useEffect(() => {
    const savedReservations = localStorage.getItem('userReservations');
    if (savedReservations) {
      const parsed = JSON.parse(savedReservations);
      setReservations(parsed);
      if (book) {
        setIsReserved(isBookReserved(book.id, parsed));
        // Check if there's a pending loan request
        setHasPendingRequest(parsed.some((r: Reservation) => r.bookId === book.id && r.status === "Pendiente"));
      }
    } else {
      // Initialize with mock data
      localStorage.setItem('userReservations', JSON.stringify(mockReservations));
      setReservations(mockReservations);
      if (book) {
        setIsReserved(isBookReserved(book.id, mockReservations));
        setHasPendingRequest(mockReservations.some(r => r.bookId === book.id && r.status === "Pendiente"));
      }
    }
  }, [book]);

  if (!book) {
    return (
      <MobileLayout>
        <div className="px-4 py-8">
          <div className="bg-white rounded-lg shadow-md p-8 text-center">
            <BookOpen className="w-16 h-16 text-slate-300 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-slate-800 mb-2">Libro no encontrado</h2>
            <p className="text-sm text-slate-600 mb-6">
              El libro que buscas no existe en nuestro catálogo
            </p>
            <Link
              to="/search"
              className="inline-flex items-center gap-2 px-6 py-3 bg-[#F97316] text-white rounded-lg hover:bg-[#EA580C] transition-colors"
            >
              <ArrowLeft className="w-5 h-5" />
              Volver al Catálogo
            </Link>
          </div>
        </div>
      </MobileLayout>
    );
  }

  const handleRequestLoan = () => {
    if (!book) return;

    // Check if already has an active loan
    if (hasActiveLoan) {
      toast.error("Ya tienes este libro", {
        description: "Ya tienes un préstamo activo de este libro.",
      });
      return;
    }

    // Check if already has a pending request
    if (hasPendingRequest) {
      toast.error("Solicitud pendiente", {
        description: "Ya tienes una solicitud pendiente para este libro.",
      });
      return;
    }

    // Check availability
    if (book.status !== "Disponible" || book.availableCopies === 0) {
      toast.error("No disponible", {
        description: "Este libro no está disponible para préstamo en este momento.",
      });
      return;
    }

    // Create new loan request (goes to reservations with status "Pendiente")
    const newRequest = addLoanRequest(book.id, book.title, book.author);
    const updatedReservations = [...reservations, newRequest];

    // Save to localStorage
    localStorage.setItem('userReservations', JSON.stringify(updatedReservations));
    setReservations(updatedReservations);
    setHasPendingRequest(true);

    toast.success("Solicitud enviada", {
      description: `Tu solicitud de préstamo para "${book.title}" está pendiente de aprobación. Puedes verla en la pestaña Reservas.`,
      action: {
        label: "Ver solicitudes",
        onClick: () => navigate("/loans"),
      },
    });
  };

  const handleReserve = () => {
    if (!book) return;

    // Check if already reserved
    if (isReserved) {
      toast.error("Ya reservado", {
        description: "Ya tienes una reserva activa para este libro.",
      });
      return;
    }

    // Only allow reservations for books that are loaned
    if (book.status !== "Prestado") {
      toast.error("No se puede reservar", {
        description: "Solo puedes reservar libros que están prestados actualmente.",
      });
      return;
    }

    // Create new reservation
    const newReservation = addReservation(book.id, book.title, book.author);
    const updatedReservations = [...reservations, newReservation];

    // Save to localStorage
    localStorage.setItem('userReservations', JSON.stringify(updatedReservations));
    setReservations(updatedReservations);
    setIsReserved(true);

    toast.success("Reserva realizada", {
      description: `Has reservado "${book.title}". Te notificaremos cuando esté disponible.`,
      action: {
        label: "Ver reservas",
        onClick: () => navigate("/loans"),
      },
    });
  };

  const getStatusIcon = () => {
    switch (book.status) {
      case "Disponible":
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case "Prestado":
        return <Clock className="w-5 h-5 text-yellow-600" />;
      case "Dañado":
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      case "Perdido":
        return <XCircle className="w-5 h-5 text-gray-600" />;
    }
  };

  const getStatusColor = () => {
    switch (book.status) {
      case "Disponible":
        return "bg-green-100 text-green-800";
      case "Prestado":
        return "bg-yellow-100 text-yellow-800";
      case "Dañado":
        return "bg-red-100 text-red-800";
      case "Perdido":
        return "bg-gray-100 text-gray-800";
    }
  };

  const relatedBooks = mockBooks
    .filter((b) => b.category === book.category && b.id !== book.id && b.status === "Disponible")
    .slice(0, 3);

  return (
    <MobileLayout>
      <div className="max-w-md mx-auto">
        {/* Header with back button */}
        <div className="bg-white border-b border-slate-200 px-4 py-3 sticky top-0 z-10">
          <button
            onClick={() => {
              if (window.history.state && window.history.state.idx > 0) {
                navigate(-1);
              } else {
                navigate('/search');
              }
            }}
            className="flex items-center gap-2 text-slate-600 hover:text-[#F97316] transition-colors"
          >
            <ArrowLeft className="w-5 h-5" />
            <span className="font-medium">Detalles del Libro</span>
          </button>
        </div>

        <div className="px-4 py-4 space-y-4">
          {/* Book Cover */}
          <div className="w-full aspect-[3/4] max-w-xs mx-auto bg-gradient-to-br from-[#F97316] to-[#EA580C] rounded-xl flex items-center justify-center shadow-lg">
            <BookOpen className="w-24 h-24 text-white opacity-50" />
          </div>

          {/* Title and Author */}
          <div className="text-center">
            <h1 className="text-2xl font-bold text-slate-800 mb-2">{book.title}</h1>
            <div className="flex items-center justify-center gap-2 text-slate-600 mb-3">
              <UserIcon className="w-4 h-4" />
              <span>{book.author}</span>
            </div>
            <div className="flex flex-wrap justify-center gap-2">
              <span className="px-3 py-1 bg-[#F97316] bg-opacity-10 text-[#F97316] rounded-full text-sm font-medium">
                {book.category}
              </span>
              <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm">
                {book.language}
              </span>
            </div>
          </div>

          {/* Availability Status */}
          <div className="bg-white rounded-xl shadow-md p-4">
            <div className="flex items-center gap-3 mb-3">
              {getStatusIcon()}
              <div>
                <p className="text-sm font-semibold text-slate-800">Estado Actual</p>
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium mt-1 ${getStatusColor()}`}>
                  {book.status}
                </span>
              </div>
            </div>

            {book.status === "Disponible" && (
              <div className="mt-3 pt-3 border-t border-slate-200">
                <p className="text-sm text-slate-600">
                  <span className="font-medium text-slate-800">{book.availableCopies}</span> de{" "}
                  <span className="font-medium text-slate-800">{book.totalCopies}</span> copias disponibles
                </p>
              </div>
            )}
          </div>

          {/* Book Condition */}
          <div className="bg-white rounded-xl shadow-md p-4">
            <div className="flex items-center gap-3">
              <BookOpen className="w-5 h-5 text-[#F97316]" />
              <div>
                <p className="text-sm font-medium text-slate-800 mb-1">Condición del Libro</p>
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                  book.condition === "Perfecto"
                    ? "bg-green-100 text-green-800"
                    : book.condition === "Daño Menor"
                    ? "bg-yellow-100 text-yellow-800"
                    : book.condition === "Dañado"
                    ? "bg-orange-100 text-orange-800"
                    : "bg-red-100 text-red-800"
                }`}>
                  {book.condition}
                </span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="bg-white rounded-xl shadow-md p-4">
            <h2 className="font-semibold text-slate-800 mb-2 flex items-center gap-2">
              <FileText className="w-5 h-5 text-[#F97316]" />
              Descripción
            </h2>
            <p className="text-sm text-slate-700 leading-relaxed">{book.description}</p>
          </div>

          {/* Bibliographic Information */}
          <div className="bg-white rounded-xl shadow-md p-4">
            <h2 className="font-semibold text-slate-800 mb-3">Información Bibliográfica</h2>
            <div className="space-y-3">
              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                <Hash className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-500 mb-1">ISBN</p>
                  <p className="text-sm font-medium text-slate-800 break-all">{book.isbn}</p>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                <BookOpen className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-500 mb-1">Editorial</p>
                  <p className="text-sm font-medium text-slate-800">{book.publisher}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-start gap-2 p-3 bg-slate-50 rounded-lg">
                  <Calendar className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-slate-500 mb-1">Año</p>
                    <p className="text-sm font-medium text-slate-800">{book.year}</p>
                  </div>
                </div>

                <div className="flex items-start gap-2 p-3 bg-slate-50 rounded-lg">
                  <FileText className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-slate-500 mb-1">Páginas</p>
                    <p className="text-sm font-medium text-slate-800">{book.pages}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-start gap-3 p-3 bg-slate-50 rounded-lg">
                <MapPin className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                <div className="flex-1 min-w-0">
                  <p className="text-xs text-slate-500 mb-1">Ubicación en Biblioteca</p>
                  <p className="text-sm font-medium text-slate-800">{book.location}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-start gap-2 p-3 bg-slate-50 rounded-lg">
                  <DollarSign className="w-4 h-4 text-slate-400 mt-0.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-slate-500 mb-1">Precio Reposición</p>
                    <p className="text-sm font-medium text-slate-800">${book.replacementPrice.toFixed(2)}</p>
                  </div>
                </div>

                <div className="flex items-start gap-2 p-3 bg-orange-50 rounded-lg">
                  <AlertTriangle className="w-4 h-4 text-orange-500 mt-0.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-orange-600 mb-1">Multa por Daño</p>
                    <p className="text-sm font-medium text-orange-800">${book.damageFine.toFixed(2)}</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-3">
            <button
              onClick={handleRequestLoan}
              disabled={book.status !== "Disponible" || book.availableCopies === 0 || hasActiveLoan || hasPendingRequest}
              className={`w-full px-6 py-3.5 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2 ${
                book.status === "Disponible" && book.availableCopies > 0 && !hasActiveLoan && !hasPendingRequest
                  ? "bg-[#F97316] text-white hover:bg-[#EA580C] shadow-md"
                  : "bg-slate-200 text-slate-400 cursor-not-allowed"
              }`}
            >
              <BookOpen className="w-5 h-5" />
              {hasActiveLoan ? "Ya Prestado" : hasPendingRequest ? "Solicitud Pendiente" : "Solicitar Préstamo"}
            </button>

            <button
              onClick={handleReserve}
              disabled={book.status !== "Prestado" || isReserved}
              className={`w-full px-6 py-3.5 rounded-lg font-semibold transition-colors flex items-center justify-center gap-2 ${
                book.status === "Prestado" && !isReserved
                  ? "bg-[#1E293B] text-white hover:bg-[#334155] shadow-md"
                  : "bg-slate-200 text-slate-400 cursor-not-allowed"
              }`}
            >
              <Clock className="w-5 h-5" />
              {isReserved ? "Ya Reservado" : "Reservar"}
            </button>
          </div>

          {/* Related Books */}
          {relatedBooks.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-slate-800 mb-3">Libros Relacionados</h2>
              <div className="grid grid-cols-2 gap-3">
                {relatedBooks.map((relatedBook) => (
                  <Link
                    key={relatedBook.id}
                    to={`/book/${relatedBook.id}`}
                    className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow overflow-hidden"
                  >
                    <div className="aspect-[3/4] bg-gradient-to-br from-[#F97316] to-[#EA580C] flex items-center justify-center">
                      <BookOpen className="w-12 h-12 text-white opacity-50" />
                    </div>
                    <div className="p-3">
                      <h3 className="text-sm font-semibold text-slate-800 mb-1 line-clamp-2">
                        {relatedBook.title}
                      </h3>
                      <div className="flex items-center gap-1.5 text-xs text-slate-600 mb-2">
                        <UserIcon className="w-3 h-3 flex-shrink-0" />
                        <span className="line-clamp-1">{relatedBook.author}</span>
                      </div>
                      <span className="inline-block px-2 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                        {relatedBook.status}
                      </span>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </MobileLayout>
  );
}
