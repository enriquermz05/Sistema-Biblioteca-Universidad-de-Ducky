import { useState } from "react";
import { Link, useNavigate } from "react-router";
import { Search, BookOpen, User as UserIcon, Calendar, Tag, CheckCircle, Menu } from "lucide-react";
import { mockBooks, BookCategory } from "../data/mockBooks";
import { MobileLayout } from "../components/MobileLayout";

export function BookSearch() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search/results?q=${encodeURIComponent(searchQuery)}`);
    }
  };

  const handleQuickFilter = (filterType: string, value: string) => {
    navigate(`/search/results?${filterType}=${encodeURIComponent(value)}`);
  };

  // Obtener libros populares (primeros 6 disponibles)
  const popularBooks = mockBooks.filter(book => book.status === "Disponible").slice(0, 6);

  // Categorías únicas
  const categories = Array.from(new Set(mockBooks.map(book => book.category)));

  return (
    <MobileLayout>
      <div className="px-4 py-4 space-y-6 max-w-md mx-auto">
        {/* Hero Section */}
        <div className="bg-gradient-to-r from-[#1E293B] to-[#334155] rounded-xl p-6 text-white">
          <h1 className="text-2xl font-bold mb-2">Catálogo de Libros</h1>
          <p className="text-slate-300 text-sm">
            Busca entre más de {mockBooks.length} títulos disponibles
          </p>
        </div>

        {/* Search Bar */}
        <div className="bg-white rounded-xl shadow-md p-4">
          <form onSubmit={handleSearch}>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por título, autor..."
                className="w-full pl-10 pr-4 py-3 border-2 border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-base"
              />
            </div>
          </form>

          {/* Quick Filters */}
          <div className="mt-4">
            <div className="flex items-center justify-between mb-3">
              <p className="text-sm font-medium text-slate-600">Filtros rápidos:</p>
              <button
                onClick={() => setShowFilters(!showFilters)}
                className="flex items-center gap-2 text-[#F97316] text-sm"
              >
                <Menu className="w-4 h-4" />
                {showFilters ? "Ocultar" : "Mostrar"}
              </button>
            </div>
            <div className={`${showFilters ? "flex" : "hidden"} flex-wrap gap-2`}>
              <button
                onClick={() => handleQuickFilter("category", "Ciencias de la Computación")}
                className="px-3 py-2 bg-slate-100 hover:bg-[#F97316] hover:text-white rounded-lg transition-colors flex items-center gap-2 text-sm"
              >
                <Tag className="w-4 h-4" />
                <span className="whitespace-nowrap">Computación</span>
              </button>
              <button
                onClick={() => handleQuickFilter("category", "Ingeniería")}
                className="px-3 py-2 bg-slate-100 hover:bg-[#F97316] hover:text-white rounded-lg transition-colors flex items-center gap-2 text-sm"
              >
                <Tag className="w-4 h-4" />
                <span>Ingeniería</span>
              </button>
              <button
                onClick={() => handleQuickFilter("status", "Disponible")}
                className="px-3 py-2 bg-slate-100 hover:bg-[#F97316] hover:text-white rounded-lg transition-colors flex items-center gap-2 text-sm"
              >
                <CheckCircle className="w-4 h-4" />
                <span>Disponibles</span>
              </button>
            </div>
          </div>
        </div>

        {/* Popular Books */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-semibold text-slate-800">Libros Populares</h2>
            <Link
              to="/search/results"
              className="text-[#F97316] hover:text-[#EA580C] font-medium flex items-center gap-1 text-sm"
            >
              Ver todos
              <span>→</span>
            </Link>
          </div>

          <div className="grid grid-cols-1 gap-4">
            {popularBooks.map((book) => (
              <Link
                key={book.id}
                to={`/book/${book.id}`}
                className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow overflow-hidden flex"
              >
                <div className="w-28 flex-shrink-0 bg-gradient-to-br from-[#F97316] to-[#EA580C] flex items-center justify-center">
                  <BookOpen className="w-12 h-12 text-white opacity-50" />
                </div>
                <div className="p-4 flex-1 min-w-0">
                  <h3 className="font-semibold text-base text-slate-800 mb-2 line-clamp-2">
                    {book.title}
                  </h3>
                  <div className="flex items-center gap-2 text-sm text-slate-600 mb-2">
                    <UserIcon className="w-4 h-4 flex-shrink-0" />
                    <span className="line-clamp-1">{book.author}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      book.status === "Disponible"
                        ? "bg-green-100 text-green-800"
                        : book.status === "Prestado"
                        ? "bg-yellow-100 text-yellow-800"
                        : book.status === "Dañado"
                        ? "bg-red-100 text-red-800"
                        : "bg-gray-100 text-gray-800"
                    }`}>
                      {book.status}
                    </span>
                    {book.status === "Disponible" && (
                      <span className="text-xs text-slate-500">
                        {book.availableCopies}/{book.totalCopies}
                      </span>
                    )}
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Categories Overview - Simplified */}
        <div>
          <h2 className="text-xl font-semibold text-slate-800 mb-4">Explorar por Categoría</h2>
          <div className="grid grid-cols-2 gap-3">
            {categories.slice(0, 6).map((category) => {
              const booksInCategory = mockBooks.filter(b => b.category === category).length;
              return (
                <button
                  key={category}
                  onClick={() => handleQuickFilter("category", category)}
                  className="bg-white rounded-xl shadow-md p-4 hover:shadow-lg hover:border-[#F97316] border-2 border-transparent transition-all text-left"
                >
                  <div className="w-10 h-10 bg-[#F97316] bg-opacity-10 rounded-lg flex items-center justify-center mb-2">
                    <BookOpen className="w-6 h-6 text-[#F97316]" />
                  </div>
                  <h3 className="font-semibold text-slate-800 mb-1 text-sm line-clamp-2">{category}</h3>
                  <p className="text-xs text-slate-500">{booksInCategory} libros</p>
                </button>
              );
            })}
          </div>
        </div>

        {/* Statistics - Simplified */}
        <div className="grid grid-cols-2 gap-3">
          <div className="bg-white rounded-xl shadow-md p-4">
            <div className="w-10 h-10 bg-[#F97316] bg-opacity-10 rounded-lg flex items-center justify-center mb-3">
              <BookOpen className="w-5 h-5 text-[#F97316]" />
            </div>
            <p className="text-2xl font-bold text-slate-800">{mockBooks.length}</p>
            <p className="text-xs text-slate-500">Títulos Totales</p>
          </div>

          <div className="bg-white rounded-xl shadow-md p-4">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mb-3">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-slate-800">
              {mockBooks.filter(b => b.status === "Disponible").length}
            </p>
            <p className="text-xs text-slate-500">Disponibles</p>
          </div>
        </div>
      </div>
    </MobileLayout>
  );
}