import { useState } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Save, X } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Label } from "../components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { UserRole } from "../data/mockUsers";
import { toast } from "sonner";

export function CreateUser() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    fullName: "",
    universityId: "",
    email: "",
    phone: "",
    department: "",
    role: "" as UserRole | "",
    status: "Activo",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would save to backend
    toast.success("Usuario creado exitosamente", {
      description: `${formData.fullName} ha sido agregado al sistema.`,
      duration: 3000,
    });
    navigate("/users");
  };

  const handleCancel = () => {
    navigate("/users");
  };

  return (
    <div className="max-w-3xl">
      {/* Header */}
      <div className="mb-6">
        <Button
          variant="ghost"
          onClick={handleCancel}
          className="mb-4 text-slate-600 hover:text-[#F97316]"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Volver a Gestión de Usuarios
        </Button>
        <h1 className="text-3xl font-bold text-[#111827]">Crear Nuevo Usuario</h1>
        <p className="text-slate-600 mt-2">Agregar un nuevo usuario al sistema de biblioteca</p>
      </div>

      {/* Form */}
      <Card className="border-slate-200">
        <CardHeader className="bg-slate-50">
          <CardTitle className="text-[#111827]">Información del Usuario</CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Full Name */}
            <div className="space-y-2">
              <Label htmlFor="fullName" className="text-[#111827]">
                Nombre Completo <span className="text-red-500">*</span>
              </Label>
              <Input
                id="fullName"
                type="text"
                placeholder="Ingrese el nombre completo"
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                className="border-slate-300"
                required
              />
            </div>

            {/* University ID */}
            <div className="space-y-2">
              <Label htmlFor="universityId" className="text-[#111827]">
                ID Universitario <span className="text-red-500">*</span>
              </Label>
              <Input
                id="universityId"
                type="text"
                placeholder="ej. EST-2024-001"
                value={formData.universityId}
                onChange={(e) => setFormData({ ...formData, universityId: e.target.value })}
                className="border-slate-300"
                required
              />
            </div>

            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email" className="text-[#111827]">
                Correo Electrónico <span className="text-red-500">*</span>
              </Label>
              <Input
                id="email"
                type="email"
                placeholder="correo@universidad.edu"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="border-slate-300"
                required
              />
            </div>

            {/* Phone */}
            <div className="space-y-2">
              <Label htmlFor="phone" className="text-[#111827]">
                Número de Teléfono
              </Label>
              <Input
                id="phone"
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="border-slate-300"
              />
            </div>

            {/* Department */}
            <div className="space-y-2">
              <Label htmlFor="department" className="text-[#111827]">
                Departamento
              </Label>
              <Input
                id="department"
                type="text"
                placeholder="ej. Ciencias de la Computación"
                value={formData.department}
                onChange={(e) => setFormData({ ...formData, department: e.target.value })}
                className="border-slate-300"
              />
            </div>

            {/* Role Selector */}
            <div className="space-y-2">
              <Label htmlFor="role" className="text-[#111827]">
                Rol <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.role}
                onValueChange={(value) => setFormData({ ...formData, role: value as UserRole })}
                required
              >
                <SelectTrigger className="border-slate-300">
                  <SelectValue placeholder="Seleccione un rol" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Administrador">Administrador</SelectItem>
                  <SelectItem value="Bibliotecario">Bibliotecario</SelectItem>
                  <SelectItem value="Profesor">Profesor</SelectItem>
                  <SelectItem value="Estudiante">Estudiante</SelectItem>
                  <SelectItem value="Colaborador">Colaborador</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Status Toggle */}
            <div className="space-y-2">
              <Label htmlFor="status" className="text-[#111827]">
                Estado <span className="text-red-500">*</span>
              </Label>
              <Select
                value={formData.status}
                onValueChange={(value) => setFormData({ ...formData, status: value })}
                required
              >
                <SelectTrigger className="border-slate-300">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Activo">Activo</SelectItem>
                  <SelectItem value="Inactivo">Inactivo</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Action Buttons */}
            <div className="flex gap-4 pt-4 border-t border-slate-200">
              <Button
                type="submit"
                className="flex-1 bg-[#F97316] hover:bg-[#ea580c] text-white"
              >
                <Save className="w-4 h-4 mr-2" />
                Guardar Usuario
              </Button>
              <Button
                type="button"
                variant="outline"
                onClick={handleCancel}
                className="flex-1 border-slate-300 text-slate-700 hover:bg-slate-50"
              >
                <X className="w-4 h-4 mr-2" />
                Cancelar
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}