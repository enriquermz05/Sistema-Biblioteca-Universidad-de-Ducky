import { useState, useEffect } from "react";
import { Link } from "react-router";
import {
  BookOpen,
  Calendar,
  AlertCircle,
  RefreshCw,
  Clock,
  CheckCircle,
  XCircle,
  Bell
} from "lucide-react";
import { MobileLayout } from "../components/MobileLayout";
import { mockLoans, getDaysUntilDue, type LoanStatus, type Loan } from "../data/mockLoans";
import { mockReservations, type Reservation, type ReservationStatus } from "../data/mockReservations";
import { toast } from "sonner";

type TabType = "loans" | "reservations";
type FilterType = "Todos" | "Activo" | "Vencido" | "Por Vencer";

export function MyLoans() {
  const [activeTab, setActiveTab] = useState<TabType>("loans");
  const [filter, setFilter] = useState<FilterType>("Todos");
  const [loans, setLoans] = useState<Loan[]>([]);
  const [reservations, setReservations] = useState<Reservation[]>([]);

  // Load loans from localStorage
  useEffect(() => {
    const savedLoans = localStorage.getItem('userLoans');
    if (savedLoans) {
      setLoans(JSON.parse(savedLoans));
    } else {
      // Initialize with mock data
      localStorage.setItem('userLoans', JSON.stringify(mockLoans));
      setLoans(mockLoans);
    }
  }, []);

  // Load reservations from localStorage
  useEffect(() => {
    const savedReservations = localStorage.getItem('userReservations');
    if (savedReservations) {
      setReservations(JSON.parse(savedReservations));
    } else {
      // Initialize with mock data
      localStorage.setItem('userReservations', JSON.stringify(mockReservations));
      setReservations(mockReservations);
    }
  }, []);

  const filteredLoans = loans.filter(loan => {
    if (filter === "Todos") return true;
    return loan.status === filter;
  });

  const handleRenewLoan = (loanId: string) => {
    const loanIndex = loans.findIndex(l => l.id === loanId);
    if (loanIndex === -1) return;

    const loan = loans[loanIndex];

    // Check if can renew
    if (loan.renewalCount >= loan.maxRenewals) {
      toast.error("No se puede renovar", {
        description: "Has alcanzado el límite máximo de renovaciones para este libro.",
      });
      return;
    }

    if (loan.status === "Vencido") {
      toast.error("No se puede renovar", {
        description: "No puedes renovar un préstamo vencido. Por favor, devuelve el libro.",
      });
      return;
    }

    // Calculate new due date (21 days from current due date)
    const currentDueDate = new Date(loan.dueDate);
    const newDueDate = new Date(currentDueDate);
    newDueDate.setDate(newDueDate.getDate() + 21);
    const newDueDateString = newDueDate.toISOString().split('T')[0];

    // Calculate new status based on new due date
    const daysUntilDue = getDaysUntilDue(newDueDateString);
    let newStatus: LoanStatus = "Activo";
    if (daysUntilDue < 0) {
      newStatus = "Vencido";
    } else if (daysUntilDue <= 7) {
      newStatus = "Por Vencer";
    }

    // Update loan
    const updatedLoans = [...loans];
    updatedLoans[loanIndex] = {
      ...loan,
      renewalCount: loan.renewalCount + 1,
      dueDate: newDueDateString,
      status: newStatus,
    };

    // Save to localStorage
    localStorage.setItem('userLoans', JSON.stringify(updatedLoans));
    setLoans(updatedLoans);

    toast.success("Préstamo renovado", {
      description: `Has renovado "${loan.bookTitle}". Nueva fecha de vencimiento: ${formatDate(newDueDateString)}`,
    });
  };

  const getStatusBadge = (status: LoanStatus) => {
    switch (status) {
      case "Activo":
        return {
          bg: "bg-green-100",
          text: "text-green-800",
          icon: CheckCircle,
        };
      case "Por Vencer":
        return {
          bg: "bg-yellow-100",
          text: "text-yellow-800",
          icon: Clock,
        };
      case "Vencido":
        return {
          bg: "bg-red-100",
          text: "text-red-800",
          icon: XCircle,
        };
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-MX', { day: 'numeric', month: 'short', year: 'numeric' });
  };

  const getReservationStatusBadge = (status: ReservationStatus) => {
    switch (status) {
      case "Pendiente":
        return {
          bg: "bg-yellow-100",
          text: "text-yellow-800",
          icon: Clock,
        };
      case "Activa":
        return {
          bg: "bg-blue-100",
          text: "text-blue-800",
          icon: Clock,
        };
      case "Notificada":
        return {
          bg: "bg-green-100",
          text: "text-green-800",
          icon: Bell,
        };
      case "Completada":
        return {
          bg: "bg-gray-100",
          text: "text-gray-800",
          icon: CheckCircle,
        };
      case "Cancelada":
        return {
          bg: "bg-red-100",
          text: "text-red-800",
          icon: XCircle,
        };
    }
  };

  const handleCancelReservation = (reservationId: string) => {
    const updatedReservations = reservations.filter(r => r.id !== reservationId);
    localStorage.setItem('userReservations', JSON.stringify(updatedReservations));
    setReservations(updatedReservations);
  };

  return (
    <MobileLayout>
      <div className="max-w-md mx-auto">
        {/* Header */}
        <div className="bg-white border-b border-slate-200 px-4 py-4 sticky top-0 z-10">
          <h1 className="text-xl font-bold text-slate-800">Mis Préstamos</h1>

          {/* Tabs */}
          <div className="flex gap-2 mt-3">
            <button
              onClick={() => setActiveTab("loans")}
              className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === "loans"
                  ? "bg-[#F97316] text-white"
                  : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              Préstamos ({loans.length})
            </button>
            <button
              onClick={() => setActiveTab("reservations")}
              className={`flex-1 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                activeTab === "reservations"
                  ? "bg-[#F97316] text-white"
                  : "bg-slate-100 text-slate-700 hover:bg-slate-200"
              }`}
            >
              Reservas ({reservations.filter(r => r.status === "Pendiente" || r.status === "Activa" || r.status === "Notificada").length})
            </button>
          </div>
        </div>

        <div className="px-4 py-4 space-y-4">
          {/* Loans Tab */}
          {activeTab === "loans" && (
            <>
              {/* Filters */}
              <div className="flex gap-2 overflow-x-auto pb-2">
                {(["Todos", "Activo", "Por Vencer", "Vencido"] as FilterType[]).map((f) => (
                  <button
                    key={f}
                    onClick={() => setFilter(f)}
                    className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                      filter === f
                        ? "bg-[#F97316] text-white"
                        : "bg-white text-slate-700 border border-slate-200 hover:border-[#F97316]"
                    }`}
                  >
                    {f}
                    {f !== "Todos" && (
                      <span className="ml-1.5 opacity-75">
                        ({loans.filter(l => l.status === f).length})
                      </span>
                    )}
                  </button>
                ))}
              </div>

          {/* Loans List */}
          {filteredLoans.length > 0 ? (
            <div className="space-y-3">
              {filteredLoans.map((loan) => {
                const daysUntilDue = getDaysUntilDue(loan.dueDate);
                const statusInfo = getStatusBadge(loan.status);
                const StatusIcon = statusInfo.icon;

                return (
                  <div
                    key={loan.id}
                    className="bg-white rounded-xl shadow-md overflow-hidden"
                  >
                    <Link
                      to={`/book/${loan.bookId}`}
                      className="flex hover:bg-slate-50 transition-colors"
                    >
                      {/* Book Cover */}
                      <div className="w-24 flex-shrink-0 bg-gradient-to-br from-[#F97316] to-[#EA580C] flex items-center justify-center">
                        <BookOpen className="w-10 h-10 text-white opacity-50" />
                      </div>

                      {/* Book Info */}
                      <div className="flex-1 p-3">
                        <h3 className="text-sm font-semibold text-slate-800 line-clamp-2 mb-1">
                          {loan.bookTitle}
                        </h3>
                        <p className="text-xs text-slate-600 mb-2">{loan.bookAuthor}</p>

                        {/* Status Badge */}
                        <div className="flex items-center gap-2 mb-2">
                          <span
                            className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${statusInfo.bg} ${statusInfo.text}`}
                          >
                            <StatusIcon className="w-3 h-3" />
                            {loan.status}
                          </span>
                        </div>

                        {/* Dates */}
                        <div className="space-y-1">
                          <div className="flex items-center gap-2 text-xs text-slate-600">
                            <Calendar className="w-3.5 h-3.5" />
                            <span>Prestado: {formatDate(loan.loanDate)}</span>
                          </div>
                          <div className="flex items-center gap-2 text-xs">
                            <Calendar className="w-3.5 h-3.5" />
                            <span className={loan.status === "Vencido" ? "text-red-600 font-medium" : "text-slate-600"}>
                              Vence: {formatDate(loan.dueDate)}
                              {loan.status !== "Vencido" && daysUntilDue >= 0 && (
                                <span className="ml-1">({daysUntilDue} día{daysUntilDue !== 1 ? 's' : ''})</span>
                              )}
                              {loan.status === "Vencido" && (
                                <span className="ml-1">({Math.abs(daysUntilDue)} día{Math.abs(daysUntilDue) !== 1 ? 's' : ''} de retraso)</span>
                              )}
                            </span>
                          </div>
                        </div>
                      </div>
                    </Link>

                    {/* Actions */}
                    <div className="border-t border-slate-100 px-3 py-2 flex items-center justify-between bg-slate-50">
                      <div className="text-xs text-slate-600">
                        Renovaciones: {loan.renewalCount}/{loan.maxRenewals}
                      </div>
                      {loan.renewalCount < loan.maxRenewals && loan.status !== "Vencido" && (
                        <button
                          onClick={() => handleRenewLoan(loan.id)}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-[#F97316] hover:bg-[#EA580C] text-white rounded-lg text-xs font-medium transition-colors"
                        >
                          <RefreshCw className="w-3.5 h-3.5" />
                          Renovar
                        </button>
                      )}
                      {loan.status === "Vencido" && (
                        <span className="flex items-center gap-1.5 px-3 py-1.5 bg-red-100 text-red-800 rounded-lg text-xs font-medium">
                          <AlertCircle className="w-3.5 h-3.5" />
                          Devolver ya
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="bg-white rounded-xl shadow-md p-8 text-center">
              <BookOpen className="w-16 h-16 text-slate-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-slate-800 mb-2">
                No hay préstamos
              </h3>
              <p className="text-sm text-slate-600 mb-6">
                {filter === "Todos" 
                  ? "Aún no tienes libros prestados"
                  : `No tienes préstamos con estado "${filter}"`
                }
              </p>
              <Link
                to="/search"
                className="inline-flex items-center gap-2 px-6 py-3 bg-[#F97316] text-white rounded-lg hover:bg-[#EA580C] transition-colors"
              >
                <BookOpen className="w-5 h-5" />
                Buscar Libros
              </Link>
            </div>
          )}

              {/* Info Box */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-blue-900 mb-1">
                      Información importante
                    </p>
                    <ul className="text-xs text-blue-800 space-y-1">
                      <li>• Las solicitudes de préstamo aparecen en la pestaña "Reservas" hasta ser aprobadas</li>
                      <li>• Los préstamos tienen una duración de 21 días</li>
                      <li>• Puedes renovar hasta 2 veces si no hay reservas</li>
                      <li>• Las multas son de $5.00 por día de retraso</li>
                      <li>• Devuelve a tiempo para evitar multas</li>
                    </ul>
                  </div>
                </div>
              </div>
            </>
          )}

          {/* Reservations Tab */}
          {activeTab === "reservations" && (
            <>
              {reservations.filter(r => r.status === "Pendiente" || r.status === "Activa" || r.status === "Notificada").length > 0 ? (
                <div className="space-y-3">
                  {reservations
                    .filter(r => r.status === "Pendiente" || r.status === "Activa" || r.status === "Notificada")
                    .map((reservation) => {
                      const statusInfo = getReservationStatusBadge(reservation.status);
                      const StatusIcon = statusInfo.icon;

                      return (
                        <div
                          key={reservation.id}
                          className="bg-white rounded-xl shadow-md overflow-hidden"
                        >
                          <Link
                            to={`/book/${reservation.bookId}`}
                            className="flex hover:bg-slate-50 transition-colors"
                          >
                            {/* Book Cover */}
                            <div className={`w-24 flex-shrink-0 flex items-center justify-center ${
                              reservation.status === "Pendiente"
                                ? "bg-gradient-to-br from-yellow-500 to-orange-500"
                                : "bg-gradient-to-br from-[#1E293B] to-[#334155]"
                            }`}>
                              <BookOpen className="w-10 h-10 text-white opacity-50" />
                            </div>

                            {/* Book Info */}
                            <div className="flex-1 p-3">
                              <h3 className="text-sm font-semibold text-slate-800 line-clamp-2 mb-1">
                                {reservation.bookTitle}
                              </h3>
                              <p className="text-xs text-slate-600 mb-2">{reservation.bookAuthor}</p>

                              {/* Status Badge */}
                              <div className="flex items-center gap-2 mb-2">
                                <span
                                  className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${statusInfo.bg} ${statusInfo.text}`}
                                >
                                  <StatusIcon className="w-3 h-3" />
                                  {reservation.status === "Pendiente" ? "Pendiente de Aprobación" : reservation.status}
                                </span>
                                {reservation.status !== "Pendiente" && (
                                  <span className="text-xs text-slate-600">
                                    Posición: #{reservation.position}
                                  </span>
                                )}
                              </div>

                              {/* Dates */}
                              <div className="space-y-1">
                                <div className="flex items-center gap-2 text-xs text-slate-600">
                                  <Calendar className="w-3.5 h-3.5" />
                                  <span>
                                    {reservation.status === "Pendiente"
                                      ? `Solicitado: ${formatDate(reservation.reservationDate)}`
                                      : `Reservado: ${formatDate(reservation.reservationDate)}`
                                    }
                                  </span>
                                </div>
                                {reservation.estimatedAvailableDate && reservation.status !== "Pendiente" && (
                                  <div className="flex items-center gap-2 text-xs text-slate-600">
                                    <Clock className="w-3.5 h-3.5" />
                                    <span>Est. disponible: {formatDate(reservation.estimatedAvailableDate)}</span>
                                  </div>
                                )}
                              </div>
                            </div>
                          </Link>

                          {/* Actions */}
                          <div className="border-t border-slate-100 px-3 py-2 flex items-center justify-end bg-slate-50">
                            {reservation.status === "Pendiente" && (
                              <>
                                <span className="text-xs text-slate-600 mr-2">Esperando aprobación</span>
                                <button
                                  onClick={() => handleCancelReservation(reservation.id)}
                                  className="flex items-center gap-1.5 px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-800 rounded-lg text-xs font-medium transition-colors"
                                >
                                  <XCircle className="w-3.5 h-3.5" />
                                  Cancelar
                                </button>
                              </>
                            )}
                            {reservation.status === "Activa" && (
                              <button
                                onClick={() => handleCancelReservation(reservation.id)}
                                className="flex items-center gap-1.5 px-3 py-1.5 bg-red-100 hover:bg-red-200 text-red-800 rounded-lg text-xs font-medium transition-colors"
                              >
                                <XCircle className="w-3.5 h-3.5" />
                                Cancelar
                              </button>
                            )}
                            {reservation.status === "Notificada" && (
                              <span className="flex items-center gap-1.5 px-3 py-1.5 bg-green-100 text-green-800 rounded-lg text-xs font-medium">
                                <Bell className="w-3.5 h-3.5" />
                                ¡Ya disponible!
                              </span>
                            )}
                          </div>
                        </div>
                      );
                    })}
                </div>
              ) : (
                <div className="bg-white rounded-xl shadow-md p-8 text-center">
                  <Clock className="w-16 h-16 text-slate-300 mx-auto mb-4" />
                  <h3 className="text-lg font-semibold text-slate-800 mb-2">
                    No tienes solicitudes ni reservas
                  </h3>
                  <p className="text-sm text-slate-600 mb-6">
                    Solicita préstamos de libros disponibles o reserva libros que están prestados
                  </p>
                  <Link
                    to="/search"
                    className="inline-flex items-center gap-2 px-6 py-3 bg-[#F97316] text-white rounded-lg hover:bg-[#EA580C] transition-colors"
                  >
                    <BookOpen className="w-5 h-5" />
                    Buscar Libros
                  </Link>
                </div>
              )}

              {/* Info Box */}
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <div className="flex gap-3">
                  <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                  <div>
                    <p className="text-sm font-medium text-blue-900 mb-1">
                      Acerca de las solicitudes y reservas
                    </p>
                    <ul className="text-xs text-blue-800 space-y-1">
                      <li>• <strong>Pendiente:</strong> Solicitudes de préstamo esperando aprobación de administración</li>
                      <li>• <strong>Activa:</strong> Reservas para libros prestados, serás notificado cuando estén disponibles</li>
                      <li>• Puedes cancelar tus solicitudes y reservas en cualquier momento</li>
                    </ul>
                  </div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </MobileLayout>
  );
}
