import { useState } from "react";
import { useNavigate } from "react-router";
import { Mail, Lock } from "lucide-react";
import { Input } from "../components/ui/input";
import { Button } from "../components/ui/button";
import { Label } from "../components/ui/label";
import logoImage from "figma:asset/8e90dbb61a46f3b3dba9f0b91f55dfa786cead07.png";

export function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    // Navigate to home instead of catalog
    navigate("/home");
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1E293B] to-[#334155] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md overflow-hidden">
        {/* Header */}
        <div className="bg-[#F97316] p-8 text-white text-center">
          <div className="flex items-center justify-center mb-4">
            <div className="w-32 h-32 md:w-40 md:h-40 bg-white rounded-2xl flex items-center justify-center p-3">
              <img
                src={logoImage}
                alt="Ducky University Logo"
                className="w-full h-full object-contain"
              />
            </div>
          </div>
          <h1 className="text-2xl md:text-3xl font-bold">Sistema Biblioteca</h1>
          <p className="text-[#FDBA74] mt-2 text-sm md:text-base">
            Portal de Gestión Universidad de Ducky
          </p>
        </div>

        {/* Form */}
        <form onSubmit={handleLogin} className="p-6 md:p-8">
          <div className="space-y-6">
            {/* Email */}
            <div className="space-y-2">
              <Label htmlFor="email" className="text-[#111827]">
                Correo Electrónico
              </Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  id="email"
                  type="email"
                  placeholder="admin@universidad.edu"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 border-slate-300 focus:border-[#F97316] focus:ring-[#F97316]"
                  required
                />
              </div>
            </div>

            {/* Password */}
            <div className="space-y-2">
              <Label htmlFor="password" className="text-[#111827]">
                Contraseña
              </Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <Input
                  id="password"
                  type="password"
                  placeholder="Ingresa tu contraseña"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10 border-slate-300 focus:border-[#F97316] focus:ring-[#F97316]"
                  required
                />
              </div>
            </div>

            {/* Remember Me */}
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  className="w-4 h-4 rounded border-slate-300 text-[#F97316] focus:ring-[#F97316]"
                />
                <span className="text-sm text-slate-600">Recordarme</span>
              </label>
              <a href="#" className="text-sm text-[#F97316] hover:text-[#ea580c]">
                ¿Olvidaste tu contraseña?
              </a>
            </div>

            {/* Login Button */}
            <Button
              type="submit"
              className="w-full bg-[#F97316] hover:bg-[#ea580c] text-white py-6 text-lg font-semibold"
            >
              Iniciar Sesión
            </Button>
          </div>

          {/* Footer */}
          <div className="mt-6 text-center text-sm text-slate-500">
            ¿Necesitas ayuda? Contacta a{" "}
            <a href="#" className="text-[#F97316] hover:underline">
              Soporte TI
            </a>
          </div>
        </form>
      </div>
    </div>
  );
}