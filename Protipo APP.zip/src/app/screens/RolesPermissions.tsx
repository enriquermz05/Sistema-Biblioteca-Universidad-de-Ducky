import { useState } from "react";
import { Shield, Save, RotateCcw, CheckCircle, XCircle } from "lucide-react";
import { toast } from "sonner";
import { Switch } from "../components/ui/switch";

type Role = "Administrador" | "Bibliotecario" | "Profesor" | "Alumno" | "Colaborador";

type Permission = 
  | "crearUsuarios"
  | "suspenderUsuarios"
  | "registrarPrestamo"
  | "registrarDevolucion"
  | "renovarPrestamo"
  | "buscarLibros"
  | "consultarCatalogo"
  | "verReportes";

type PermissionsMatrix = {
  [key in Role]: {
    [key in Permission]: boolean;
  };
};

const permissionLabels: { [key in Permission]: string } = {
  crearUsuarios: "Crear Usuarios",
  suspenderUsuarios: "Suspender Usuarios",
  registrarPrestamo: "Registrar Préstamo",
  registrarDevolucion: "Registrar Devolución",
  renovarPrestamo: "Renovar Préstamo",
  buscarLibros: "Buscar Libros",
  consultarCatalogo: "Consultar Catálogo",
  verReportes: "Ver Reportes",
};

const defaultPermissions: PermissionsMatrix = {
  Administrador: {
    crearUsuarios: true,
    suspenderUsuarios: true,
    registrarPrestamo: true,
    registrarDevolucion: true,
    renovarPrestamo: true,
    buscarLibros: true,
    consultarCatalogo: true,
    verReportes: true,
  },
  Bibliotecario: {
    crearUsuarios: false,
    suspenderUsuarios: false,
    registrarPrestamo: true,
    registrarDevolucion: true,
    renovarPrestamo: true,
    buscarLibros: true,
    consultarCatalogo: true,
    verReportes: true,
  },
  Profesor: {
    crearUsuarios: false,
    suspenderUsuarios: false,
    registrarPrestamo: false,
    registrarDevolucion: false,
    renovarPrestamo: false,
    buscarLibros: true,
    consultarCatalogo: true,
    verReportes: false,
  },
  Alumno: {
    crearUsuarios: false,
    suspenderUsuarios: false,
    registrarPrestamo: false,
    registrarDevolucion: false,
    renovarPrestamo: false,
    buscarLibros: true,
    consultarCatalogo: true,
    verReportes: false,
  },
  Colaborador: {
    crearUsuarios: false,
    suspenderUsuarios: false,
    registrarPrestamo: false,
    registrarDevolucion: false,
    renovarPrestamo: false,
    buscarLibros: true,
    consultarCatalogo: true,
    verReportes: false,
  },
};

export function RolesPermissions() {
  const [selectedRole, setSelectedRole] = useState<Role>("Administrador");
  const [permissions, setPermissions] = useState<PermissionsMatrix>(defaultPermissions);
  const [hasChanges, setHasChanges] = useState(false);

  const roles: Role[] = ["Administrador", "Bibliotecario", "Profesor", "Alumno", "Colaborador"];
  const permissionKeys = Object.keys(permissionLabels) as Permission[];

  const handlePermissionToggle = (role: Role, permission: Permission) => {
    setPermissions((prev) => ({
      ...prev,
      [role]: {
        ...prev[role],
        [permission]: !prev[role][permission],
      },
    }));
    setHasChanges(true);
  };

  const handleSaveChanges = () => {
    toast.success("Cambios guardados", {
      description: "Los permisos han sido actualizados exitosamente.",
    });
    setHasChanges(false);
  };

  const handleResetPermissions = () => {
    setPermissions(defaultPermissions);
    setHasChanges(false);
    toast.info("Permisos restablecidos", {
      description: "Se han restaurado los permisos predeterminados del sistema.",
    });
  };

  const getRoleBadgeColor = (role: Role) => {
    const colors = {
      Administrador: "bg-red-100 text-red-800",
      Bibliotecario: "bg-blue-100 text-blue-800",
      Profesor: "bg-purple-100 text-purple-800",
      Alumno: "bg-green-100 text-green-800",
      Colaborador: "bg-orange-100 text-orange-800",
    };
    return colors[role];
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-800 mb-2">
            Gestión de Roles y Permisos
          </h1>
          <p className="text-sm md:text-base text-slate-600">
            Configura los permisos de acceso para cada rol del sistema
          </p>
        </div>
        {hasChanges && (
          <div className="flex items-center gap-2 px-4 py-2 bg-amber-50 border border-amber-200 rounded-lg">
            <div className="w-2 h-2 bg-amber-500 rounded-full animate-pulse"></div>
            <span className="text-sm text-amber-800">Cambios sin guardar</span>
          </div>
        )}
      </div>

      {/* Role Selector - Mobile */}
      <div className="md:hidden bg-white rounded-lg shadow-md p-4">
        <label className="block text-sm font-medium text-slate-700 mb-2">
          Seleccionar Rol
        </label>
        <select
          value={selectedRole}
          onChange={(e) => setSelectedRole(e.target.value as Role)}
          className="w-full px-4 py-3 border-2 border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors"
        >
          {roles.map((role) => (
            <option key={role} value={role}>
              {role}
            </option>
          ))}
        </select>
      </div>

      {/* Role Tabs - Desktop */}
      <div className="hidden md:block bg-white rounded-lg shadow-md p-2">
        <div className="flex gap-2">
          {roles.map((role) => (
            <button
              key={role}
              onClick={() => setSelectedRole(role)}
              className={`flex-1 px-4 py-3 rounded-lg font-medium transition-all ${
                selectedRole === role
                  ? "bg-[#F97316] text-white shadow-md"
                  : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              {role}
            </button>
          ))}
        </div>
      </div>

      {/* Selected Role Info */}
      <div className="bg-gradient-to-r from-[#1E293B] to-[#334155] rounded-lg p-6 text-white">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 md:w-16 md:h-16 bg-white bg-opacity-20 rounded-lg flex items-center justify-center">
            <Shield className="w-6 h-6 md:w-8 md:h-8" />
          </div>
          <div>
            <p className="text-sm text-slate-300 mb-1">Configurando permisos para</p>
            <h2 className="text-xl md:text-2xl font-bold">{selectedRole}</h2>
          </div>
        </div>
      </div>

      {/* Permissions Table - Desktop */}
      <div className="hidden lg:block bg-white rounded-lg shadow-md overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-slate-50 border-b border-slate-200">
              <tr>
                <th className="px-6 py-4 text-left text-sm font-semibold text-slate-700 sticky left-0 bg-slate-50 z-10">
                  Rol
                </th>
                {permissionKeys.map((permission) => (
                  <th
                    key={permission}
                    className="px-6 py-4 text-center text-sm font-semibold text-slate-700"
                  >
                    {permissionLabels[permission]}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {roles.map((role) => (
                <tr
                  key={role}
                  className={`${
                    role === selectedRole ? "bg-[#F97316] bg-opacity-5" : "hover:bg-slate-50"
                  } transition-colors`}
                >
                  <td className="px-6 py-4 sticky left-0 bg-inherit z-10">
                    <span
                      className={`px-3 py-1 rounded-full text-sm font-medium ${getRoleBadgeColor(
                        role
                      )}`}
                    >
                      {role}
                    </span>
                  </td>
                  {permissionKeys.map((permission) => (
                    <td key={permission} className="px-6 py-4 text-center">
                      <div className="flex justify-center">
                        <Switch
                          checked={permissions[role][permission]}
                          onCheckedChange={() => handlePermissionToggle(role, permission)}
                        />
                      </div>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Permissions Cards - Mobile & Tablet */}
      <div className="lg:hidden space-y-4">
        <div className="bg-white rounded-lg shadow-md p-4">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-slate-800">Permisos del Rol</h3>
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${getRoleBadgeColor(selectedRole)}`}>
              {selectedRole}
            </span>
          </div>
          <div className="space-y-3">
            {permissionKeys.map((permission) => (
              <div
                key={permission}
                className="flex items-center justify-between p-3 bg-slate-50 rounded-lg"
              >
                <div className="flex items-center gap-3">
                  {permissions[selectedRole][permission] ? (
                    <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                  ) : (
                    <XCircle className="w-5 h-5 text-slate-300 flex-shrink-0" />
                  )}
                  <span className="text-sm md:text-base text-slate-700">
                    {permissionLabels[permission]}
                  </span>
                </div>
                <Switch
                  checked={permissions[selectedRole][permission]}
                  onCheckedChange={() => handlePermissionToggle(selectedRole, permission)}
                />
              </div>
            ))}
          </div>
        </div>

        {/* Other Roles Summary */}
        <div className="bg-white rounded-lg shadow-md p-4">
          <h3 className="text-base md:text-lg font-semibold text-slate-800 mb-4">Otros Roles</h3>
          <div className="space-y-3">
            {roles
              .filter((role) => role !== selectedRole)
              .map((role) => (
                <button
                  key={role}
                  onClick={() => setSelectedRole(role)}
                  className="w-full flex items-center justify-between p-3 bg-slate-50 hover:bg-slate-100 rounded-lg transition-colors"
                >
                  <span className={`px-3 py-1 rounded-full text-sm font-medium ${getRoleBadgeColor(role)}`}>
                    {role}
                  </span>
                  <span className="text-xs text-slate-500">
                    {Object.values(permissions[role]).filter(Boolean).length} permisos activos
                  </span>
                </button>
              ))}
          </div>
        </div>
      </div>

      {/* Permission Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
          <div className="flex items-center gap-3 md:gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-green-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <CheckCircle className="w-5 h-5 md:w-6 md:h-6 text-green-600" />
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-slate-800">
                {Object.values(permissions[selectedRole]).filter(Boolean).length}
              </p>
              <p className="text-xs md:text-sm text-slate-500">Permisos Activos</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
          <div className="flex items-center gap-3 md:gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-red-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <XCircle className="w-5 h-5 md:w-6 md:h-6 text-red-600" />
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-slate-800">
                {Object.values(permissions[selectedRole]).filter((v) => !v).length}
              </p>
              <p className="text-xs md:text-sm text-slate-500">Permisos Inactivos</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
          <div className="flex items-center gap-3 md:gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Shield className="w-5 h-5 md:w-6 md:h-6 text-blue-600" />
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-slate-800">{roles.length}</p>
              <p className="text-xs md:text-sm text-slate-500">Roles Totales</p>
            </div>
          </div>
        </div>

        <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
          <div className="flex items-center gap-3 md:gap-4">
            <div className="w-10 h-10 md:w-12 md:h-12 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
              <Shield className="w-5 h-5 md:w-6 md:h-6 text-purple-600" />
            </div>
            <div>
              <p className="text-2xl md:text-3xl font-bold text-slate-800">
                {permissionKeys.length}
              </p>
              <p className="text-xs md:text-sm text-slate-500">Permisos del Sistema</p>
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="sticky bottom-0 bg-white rounded-lg shadow-md p-4 md:p-6 flex flex-col sm:flex-row gap-3 md:gap-4">
        <button
          onClick={handleSaveChanges}
          disabled={!hasChanges}
          className={`flex-1 px-4 md:px-6 py-2.5 md:py-3 rounded-lg font-medium transition-all flex items-center justify-center gap-2 text-sm md:text-base ${
            hasChanges
              ? "bg-[#F97316] text-white hover:bg-[#EA580C] shadow-md"
              : "bg-slate-200 text-slate-400 cursor-not-allowed"
          }`}
        >
          <Save className="w-4 h-4 md:w-5 md:h-5" />
          Guardar Cambios
        </button>
        <button
          onClick={handleResetPermissions}
          className="flex-1 px-4 md:px-6 py-2.5 md:py-3 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors font-medium flex items-center justify-center gap-2 text-sm md:text-base"
        >
          <RotateCcw className="w-4 h-4 md:w-5 md:h-5" />
          Restablecer Permisos
        </button>
      </div>
    </div>
  );
}
