import { useState, useMemo } from "react";
import { Link, useSearchParams } from "react-router";
import { Search, BookOpen, User as UserIcon, SlidersHorizontal, X, ArrowUpDown, Printer } from "lucide-react";
import { mockBooks, BookCategory, BookStatus } from "../data/mockBooks";
import { MobileLayout } from "../components/MobileLayout";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../components/ui/dialog";
import { Button } from "../components/ui/button";

type SortOption = "title" | "author" | "year" | "availability";

export function SearchResults() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [searchQuery, setSearchQuery] = useState(searchParams.get("q") || "");
  const [showFilters, setShowFilters] = useState(false);
  const [sortBy, setSortBy] = useState<SortOption>("title");
  const [isPrintModalOpen, setIsPrintModalOpen] = useState(false);

  // Filtros activos
  const activeCategory = searchParams.get("category") || "";
  const activeStatus = searchParams.get("status") || "";
  const activeYearFilter = searchParams.get("year") || "";
  const activeAuthor = searchParams.get("author") || "";

  // Aplicar filtros y búsqueda
  const filteredBooks = useMemo(() => {
    let results = mockBooks;

    // Filtro de búsqueda
    const query = searchParams.get("q") || "";
    if (query) {
      const lowerQuery = query.toLowerCase();
      results = results.filter(
        (book) =>
          book.title.toLowerCase().includes(lowerQuery) ||
          book.author.toLowerCase().includes(lowerQuery) ||
          book.category.toLowerCase().includes(lowerQuery) ||
          book.isbn.includes(lowerQuery)
      );
    }

    // Filtro de categoría
    if (activeCategory) {
      results = results.filter((book) => book.category === activeCategory);
    }

    // Filtro de estado
    if (activeStatus) {
      results = results.filter((book) => book.status === activeStatus);
    }

    // Filtro de año
    if (activeYearFilter) {
      const year = parseInt(activeYearFilter);
      results = results.filter((book) => book.year >= year);
    }

    // Filtro de autor
    if (activeAuthor) {
      results = results.filter((book) => book.author === activeAuthor);
    }

    // Ordenar
    results = [...results].sort((a, b) => {
      switch (sortBy) {
        case "title":
          return a.title.localeCompare(b.title);
        case "author":
          return a.author.localeCompare(b.author);
        case "year":
          return b.year - a.year;
        case "availability":
          if (a.status === "Disponible" && b.status !== "Disponible") return -1;
          if (a.status !== "Disponible" && b.status === "Disponible") return 1;
          return 0;
        default:
          return 0;
      }
    });

    return results;
  }, [searchParams, sortBy, activeCategory, activeStatus, activeYearFilter, activeAuthor]);

  // Obtener listas únicas para filtros
  const categories = Array.from(new Set(mockBooks.map((book) => book.category)));
  const authors = Array.from(new Set(mockBooks.map((book) => book.author))).sort();
  const statuses: BookStatus[] = ["Disponible", "Prestado", "Dañado", "Perdido"];

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      setSearchParams({ q: searchQuery });
    }
  };

  const addFilter = (key: string, value: string) => {
    const params = new URLSearchParams(searchParams);
    params.set(key, value);
    setSearchParams(params);
  };

  const removeFilter = (key: string) => {
    const params = new URLSearchParams(searchParams);
    params.delete(key);
    setSearchParams(params);
  };

  const clearAllFilters = () => {
    setSearchParams({});
    setSearchQuery("");
  };

  const activeFiltersCount =
    (activeCategory ? 1 : 0) +
    (activeStatus ? 1 : 0) +
    (activeYearFilter ? 1 : 0) +
    (activeAuthor ? 1 : 0);

  return (
    <MobileLayout>
      <div className="px-4 py-4 space-y-4 max-w-md mx-auto">
        {/* Search Bar */}
        <div className="bg-white rounded-xl shadow-md p-4">
          <form onSubmit={handleSearch}>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Buscar por título, autor..."
                className="w-full pl-10 pr-4 py-3 border-2 border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-base"
              />
            </div>
          </form>
        </div>

        {/* Active Filters */}
        {(activeFiltersCount > 0 || searchParams.get("q")) && (
          <div className="bg-white rounded-lg shadow-md p-3 md:p-4">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm md:text-base font-medium text-slate-800">Filtros Activos</h3>
              <button
                onClick={clearAllFilters}
                className="text-xs md:text-sm text-[#F97316] hover:text-[#EA580C] font-medium"
              >
                Limpiar todos
              </button>
            </div>
            <div className="flex flex-wrap gap-2">
              {searchParams.get("q") && (
                <span className="px-2 md:px-3 py-1 bg-[#F97316] text-white rounded-full text-xs md:text-sm flex items-center gap-2">
                  Búsqueda: "{searchParams.get("q")}"
                  <button onClick={() => removeFilter("q")}>
                    <X className="w-3 h-3 md:w-4 md:h-4" />
                  </button>
                </span>
              )}
              {activeCategory && (
                <span className="px-2 md:px-3 py-1 bg-[#F97316] text-white rounded-full text-xs md:text-sm flex items-center gap-2">
                  Categoría: {activeCategory}
                  <button onClick={() => removeFilter("category")}>
                    <X className="w-3 h-3 md:w-4 md:h-4" />
                  </button>
                </span>
              )}
              {activeStatus && (
                <span className="px-2 md:px-3 py-1 bg-[#F97316] text-white rounded-full text-xs md:text-sm flex items-center gap-2">
                  Estado: {activeStatus}
                  <button onClick={() => removeFilter("status")}>
                    <X className="w-3 h-3 md:w-4 md:h-4" />
                  </button>
                </span>
              )}
              {activeYearFilter && (
                <span className="px-2 md:px-3 py-1 bg-[#F97316] text-white rounded-full text-xs md:text-sm flex items-center gap-2">
                  Año ≥ {activeYearFilter}
                  <button onClick={() => removeFilter("year")}>
                    <X className="w-3 h-3 md:w-4 md:h-4" />
                  </button>
                </span>
              )}
              {activeAuthor && (
                <span className="px-2 md:px-3 py-1 bg-[#F97316] text-white rounded-full text-xs md:text-sm flex items-center gap-2">
                  Autor: {activeAuthor}
                  <button onClick={() => removeFilter("author")}>
                    <X className="w-3 h-3 md:w-4 md:h-4" />
                  </button>
                </span>
              )}
            </div>
          </div>
        )}

        <div className="flex flex-col lg:flex-row gap-4 md:gap-6">
          {/* Filters Sidebar - Mobile Overlay / Desktop Sidebar */}
          {showFilters && (
            <>
              {/* Mobile Overlay */}
              <div 
                className="lg:hidden fixed inset-0 bg-black bg-opacity-50 z-40"
                onClick={() => setShowFilters(false)}
              />
              
              {/* Sidebar */}
              <aside className={`
                fixed lg:static inset-y-0 right-0 z-50 lg:z-auto
                w-64 bg-white rounded-lg shadow-md p-4 md:p-6 h-fit
                lg:block overflow-y-auto
                transform transition-transform duration-300 ease-in-out
                ${showFilters ? 'translate-x-0' : 'translate-x-full lg:translate-x-0'}
              `}>
                <div className="flex items-center justify-between mb-6">
                  <h3 className="text-base md:text-lg font-semibold text-slate-800 flex items-center gap-2">
                    <SlidersHorizontal className="w-4 h-4 md:w-5 md:h-5" />
                    Filtros
                  </h3>
                  <button
                    onClick={() => setShowFilters(false)}
                    className="lg:hidden text-slate-400 hover:text-slate-600"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Category Filter */}
                <div className="mb-6">
                  <h4 className="text-sm md:text-base font-medium text-slate-700 mb-3">Categoría</h4>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {categories.map((category) => (
                      <button
                        key={category}
                        onClick={() =>
                          activeCategory === category
                            ? removeFilter("category")
                            : addFilter("category", category)
                        }
                        className={`w-full text-left px-2 md:px-3 py-2 rounded-lg text-xs md:text-sm transition-colors ${
                          activeCategory === category
                            ? "bg-[#F97316] text-white"
                            : "hover:bg-slate-100 text-slate-700"
                        }`}
                      >
                        <span className="line-clamp-2">{category}</span>
                        <span className="text-xs ml-2 opacity-70">
                          ({mockBooks.filter((b) => b.category === category).length})
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Status Filter */}
                <div className="mb-6">
                  <h4 className="text-sm md:text-base font-medium text-slate-700 mb-3">Disponibilidad</h4>
                  <div className="space-y-2">
                    {statuses.map((status) => (
                      <button
                        key={status}
                        onClick={() =>
                          activeStatus === status
                            ? removeFilter("status")
                            : addFilter("status", status)
                        }
                        className={`w-full text-left px-2 md:px-3 py-2 rounded-lg text-xs md:text-sm transition-colors ${
                          activeStatus === status
                            ? "bg-[#F97316] text-white"
                            : "hover:bg-slate-100 text-slate-700"
                        }`}
                      >
                        {status}
                        <span className="text-xs ml-2 opacity-70">
                          ({mockBooks.filter((b) => b.status === status).length})
                        </span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Year Filter */}
                <div className="mb-6">
                  <h4 className="text-sm md:text-base font-medium text-slate-700 mb-3">Año de Publicación</h4>
                  <div className="space-y-2">
                    {["2020", "2015", "2010", "2000"].map((year) => (
                      <button
                        key={year}
                        onClick={() =>
                          activeYearFilter === year
                            ? removeFilter("year")
                            : addFilter("year", year)
                        }
                        className={`w-full text-left px-2 md:px-3 py-2 rounded-lg text-xs md:text-sm transition-colors ${
                          activeYearFilter === year
                            ? "bg-[#F97316] text-white"
                            : "hover:bg-slate-100 text-slate-700"
                        }`}
                      >
                        Desde {year}
                      </button>
                    ))}
                  </div>
                </div>
              </aside>
            </>
          )}

          {/* Results */}
          <div className="flex-1 min-w-0">
            {/* Results Header */}
            <div className="bg-white rounded-lg shadow-md p-3 md:p-4 mb-4 md:mb-6">
              <div className="flex flex-col gap-3">
                {/* Primera fila: Filtros y Resultados */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => setShowFilters(!showFilters)}
                      className="px-3 py-2 bg-slate-100 hover:bg-slate-200 rounded-lg transition-colors flex items-center gap-2 text-sm"
                    >
                      <SlidersHorizontal className="w-4 h-4" />
                      <span className="hidden sm:inline">Filtros</span>
                    </button>
                    <p className="text-sm text-slate-600">
                      <span className="font-semibold text-slate-800">{filteredBooks.length}</span> resultados
                    </p>
                  </div>

                  <button
                    onClick={() => setIsPrintModalOpen(true)}
                    disabled={filteredBooks.length === 0}
                    className="px-3 py-2 bg-[#F97316] hover:bg-[#EA580C] text-white rounded-lg transition-colors flex items-center gap-1.5 text-sm disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <Printer className="w-4 h-4" />
                    <span className="hidden sm:inline">Imprimir</span>
                  </button>
                </div>

                {/* Segunda fila: Ordenamiento */}
                <div className="flex items-center gap-2">
                  <ArrowUpDown className="w-4 h-4 text-slate-400 flex-shrink-0" />
                  <select
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value as SortOption)}
                    className="w-full px-3 py-2 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] text-sm bg-white"
                  >
                    <option value="title">Ordenar por: Título</option>
                    <option value="author">Ordenar por: Autor</option>
                    <option value="year">Ordenar por: Año</option>
                    <option value="availability">Ordenar por: Disponibilidad</option>
                  </select>
                </div>
              </div>
            </div>

            {/* Books Grid */}
            {filteredBooks.length > 0 ? (
              <div className="grid grid-cols-1 gap-4">
                {filteredBooks.map((book) => (
                  <Link
                    key={book.id}
                    to={`/book/${book.id}`}
                    className="bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow overflow-hidden flex"
                  >
                    <div className="w-24 flex-shrink-0 bg-gradient-to-br from-[#F97316] to-[#EA580C] flex items-center justify-center">
                      <BookOpen className="w-10 h-10 text-white opacity-50" />
                    </div>
                    <div className="p-3 flex-1 min-w-0">
                      <h3 className="text-sm font-semibold text-slate-800 mb-1 line-clamp-2">
                        {book.title}
                      </h3>
                      <div className="flex items-center gap-2 text-xs text-slate-600 mb-2">
                        <UserIcon className="w-3 h-3 flex-shrink-0" />
                        <span className="line-clamp-1">{book.author}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-medium ${
                            book.status === "Disponible"
                              ? "bg-green-100 text-green-800"
                              : book.status === "Prestado"
                              ? "bg-yellow-100 text-yellow-800"
                              : book.status === "Dañado"
                              ? "bg-red-100 text-red-800"
                              : "bg-gray-100 text-gray-800"
                          }`}
                        >
                          {book.status}
                        </span>
                        {book.status === "Disponible" && (
                          <span className="text-xs text-slate-500">
                            {book.availableCopies}/{book.totalCopies}
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            ) : (
              <div className="bg-white rounded-lg shadow-md p-8 md:p-12 text-center">
                <BookOpen className="w-12 h-12 md:w-16 md:h-16 text-slate-300 mx-auto mb-4" />
                <h3 className="text-lg md:text-xl font-semibold text-slate-800 mb-2">
                  No se encontraron resultados
                </h3>
                <p className="text-sm md:text-base text-slate-600 mb-6">
                  Intenta ajustar tus filtros o realiza una nueva búsqueda
                </p>
                <button
                  onClick={clearAllFilters}
                  className="px-4 md:px-6 py-2.5 md:py-3 bg-[#F97316] text-white rounded-lg hover:bg-[#EA580C] transition-colors text-sm md:text-base"
                >
                  Limpiar Filtros
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Print Modal */}
        <Dialog open={isPrintModalOpen} onOpenChange={setIsPrintModalOpen}>
          <DialogContent className="max-w-[95vw] sm:max-w-[800px] max-h-[85vh] overflow-y-auto p-4 sm:p-6">
            <DialogHeader>
              <DialogTitle className="text-lg sm:text-xl text-[#111827]">Catálogo de Libros</DialogTitle>
              <DialogDescription className="text-sm text-slate-600">
                Resultados de búsqueda
              </DialogDescription>
            </DialogHeader>
            
            <div className="py-2 sm:py-4">
              {/* Print Preview Table */}
              <div className="overflow-x-auto -mx-4 sm:mx-0">
                <div className="inline-block min-w-full align-middle px-4 sm:px-0">
                  <table className="w-full text-xs sm:text-sm border-collapse">
                    <thead className="bg-slate-50 border-b border-slate-200">
                      <tr>
                        <th className="px-2 sm:px-3 py-2 text-left font-semibold text-slate-700 whitespace-nowrap">Título</th>
                        <th className="px-2 sm:px-3 py-2 text-left font-semibold text-slate-700 whitespace-nowrap">Autor</th>
                        <th className="px-2 sm:px-3 py-2 text-left font-semibold text-slate-700 whitespace-nowrap hidden sm:table-cell">Editorial</th>
                        <th className="px-2 sm:px-3 py-2 text-left font-semibold text-slate-700 whitespace-nowrap hidden md:table-cell">Categoría</th>
                        <th className="px-2 sm:px-3 py-2 text-left font-semibold text-slate-700 whitespace-nowrap">Estado</th>
                        <th className="px-2 sm:px-3 py-2 text-left font-semibold text-slate-700 whitespace-nowrap hidden lg:table-cell">Precio</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredBooks.map((book, index) => (
                        <tr key={book.id} className={`border-b border-slate-100 ${index % 2 === 0 ? 'bg-white' : 'bg-slate-50/50'}`}>
                          <td className="px-2 sm:px-3 py-2 text-slate-700">
                            <div className="max-w-[120px] sm:max-w-none truncate sm:whitespace-normal">{book.title}</div>
                          </td>
                          <td className="px-2 sm:px-3 py-2 text-slate-600">
                            <div className="max-w-[100px] sm:max-w-none truncate sm:whitespace-normal">{book.author}</div>
                          </td>
                          <td className="px-2 sm:px-3 py-2 text-slate-600 hidden sm:table-cell">
                            <div className="max-w-[120px] truncate">{book.publisher}</div>
                          </td>
                          <td className="px-2 sm:px-3 py-2 text-slate-600 hidden md:table-cell">
                            <div className="max-w-[100px] truncate">{book.category}</div>
                          </td>
                          <td className="px-2 sm:px-3 py-2">
                            <span className={`px-1.5 sm:px-2 py-0.5 rounded-full text-xs font-medium whitespace-nowrap ${
                              book.status === "Disponible"
                                ? "bg-green-100 text-green-800"
                                : book.status === "Prestado"
                                ? "bg-yellow-100 text-yellow-800"
                                : book.status === "Dañado"
                                ? "bg-red-100 text-red-800"
                                : "bg-gray-100 text-gray-800"
                            }`}>
                              {book.status}
                            </span>
                          </td>
                          <td className="px-2 sm:px-3 py-2 text-slate-700 font-medium hidden lg:table-cell whitespace-nowrap">
                            ${book.replacementPrice.toFixed(2)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Summary */}
              <div className="mt-4 text-xs sm:text-sm text-slate-500 border-t border-slate-200 pt-4">
                <p><strong>Total de resultados:</strong> {filteredBooks.length} libros</p>
                <p className="text-xs mt-1">Generado el: {new Date().toLocaleDateString('es-MX', { day: 'numeric', month: 'long', year: 'numeric' })}</p>
              </div>
            </div>

            <DialogFooter className="flex-col sm:flex-row gap-2 sm:gap-0">
              <Button
                type="button"
                variant="outline"
                onClick={() => setIsPrintModalOpen(false)}
                className="w-full sm:w-auto text-sm"
              >
                Cancelar
              </Button>
              <Button
                type="button"
                className="w-full sm:w-auto bg-[#F97316] hover:bg-[#EA580C] text-white text-sm"
                onClick={() => {
                  window.print();
                  setIsPrintModalOpen(false);
                }}
              >
                <Printer className="w-4 h-4 mr-2" />
                Imprimir
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </MobileLayout>
  );
}