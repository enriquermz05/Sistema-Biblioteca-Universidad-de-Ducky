import { useState } from "react";
import { useNavigate } from "react-router";
import { Search, Plus, Edit, Ban, Upload, Download, AlertTriangle, UserX, BookOpen, Clock, ChevronDown, FileSpreadsheet, File, Users } from "lucide-react";
import { Button } from "../components/ui/button";
import { Input } from "../components/ui/input";
import { Badge } from "../components/ui/badge";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "../components/ui/table";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "../components/ui/select";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "../components/ui/dialog";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../components/ui/dropdown-menu";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { mockUsers, UserRole } from "../data/mockUsers";

export function UserManagement() {
  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState("");
  const [roleFilter, setRoleFilter] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [isImportModalOpen, setIsImportModalOpen] = useState(false);
  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [importStats, setImportStats] = useState({
    detected: 0,
    new: 0,
    duplicates: 0,
  });

  // Calculate statistics
  const usersWithFines = mockUsers.filter(u => u.fines > 0).length;
  const suspendedUsers = mockUsers.filter(u => u.status === "Suspendido").length;
  const usersWithActiveLoans = mockUsers.filter(u => u.activeLoans > 0).length;
  const newUsersThisWeek = mockUsers.filter(u => {
    const joinedDate = new Date(u.joinedDate.split('/').reverse().join('-'));
    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);
    return joinedDate >= weekAgo;
  }).length;

  // Users requiring attention
  const usersRequiringAttention = [
    ...mockUsers.filter(u => u.fines > 50).map(u => ({
      id: u.id,
      name: u.name,
      status: "Multa pendiente",
      badge: "red",
      action: "Ver detalle"
    })),
    ...mockUsers.filter(u => u.loans.some(l => l.status === "Vencido")).map(u => ({
      id: u.id,
      name: u.name,
      status: "Préstamo vencido",
      badge: "orange",
      action: "Ver préstamo"
    })),
    ...mockUsers.filter(u => u.status === "Suspendido").map(u => ({
      id: u.id,
      name: u.name,
      status: "Cuenta suspendida",
      badge: "gray",
      action: "Ver usuario"
    })),
  ].slice(0, 5);

  const filteredUsers = mockUsers.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.universityId.toLowerCase().includes(searchQuery.toLowerCase()) ||
      user.email.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesRole = roleFilter === "all" || user.role === roleFilter;
    
    const matchesStatus = 
      statusFilter === "all" ||
      (statusFilter === "Activo" && user.status === "Activo") ||
      (statusFilter === "Suspendido" && user.status === "Suspendido") ||
      (statusFilter === "Con multa" && user.fines > 0) ||
      (statusFilter === "Con préstamo" && user.activeLoans > 0);

    return matchesSearch && matchesRole && matchesStatus;
  });

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFileSelect(e.dataTransfer.files[0]);
    }
  };

  const handleFileSelect = (file: File) => {
    setSelectedFile(file);
    // Simulate file validation
    setImportStats({
      detected: 120,
      new: 110,
      duplicates: 10,
    });
  };

  const handleFileInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleFileSelect(e.target.files[0]);
    }
  };

  const handleImport = () => {
    // Simulate import process
    console.log("Importing users from:", selectedFile?.name);
    setIsImportModalOpen(false);
    setSelectedFile(null);
    setImportStats({ detected: 0, new: 0, duplicates: 0 });
  };

  const handleExport = (format: 'csv' | 'excel') => {
    console.log("Exporting users as:", format);
    // Simulate export process
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Activo":
        return "bg-green-100 text-green-700 border-green-300";
      case "Suspendido":
        return "bg-red-100 text-red-700 border-red-300";
      case "Inactivo":
        return "bg-slate-100 text-slate-700 border-slate-300";
      default:
        return "bg-slate-100 text-slate-700 border-slate-300";
    }
  };

  const getRoleColor = (role: UserRole) => {
    switch (role) {
      case "Administrador":
        return "bg-purple-100 text-purple-700 border-purple-300";
      case "Bibliotecario":
        return "bg-blue-100 text-blue-700 border-blue-300";
      case "Profesor":
        return "bg-orange-100 text-orange-700 border-orange-300";
      case "Estudiante":
        return "bg-emerald-100 text-emerald-700 border-emerald-300";
      case "Colaborador":
        return "bg-amber-100 text-amber-700 border-amber-300";
      default:
        return "bg-slate-100 text-slate-700 border-slate-300";
    }
  };

  const getBadgeColor = (badge: string) => {
    switch (badge) {
      case "red":
        return "bg-red-100 text-red-700 border-red-300";
      case "orange":
        return "bg-orange-100 text-orange-700 border-orange-300";
      case "gray":
        return "bg-slate-100 text-slate-700 border-slate-300";
      default:
        return "bg-slate-100 text-slate-700 border-slate-300";
    }
  };

  return (
    <div className="space-y-6">
      {/* Usuarios Importantes Section */}
      <div>
        <h2 className="text-xl font-semibold text-[#111827] mb-4">Usuarios Importantes</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Card 1: Users with Fines */}
          <Card className="border-slate-200 hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">
                Usuarios con multas pendientes
              </CardTitle>
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: '#F9731615' }}
              >
                <AlertTriangle className="w-5 h-5" style={{ color: '#F97316' }} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-[#111827]">{usersWithFines}</div>
            </CardContent>
          </Card>

          {/* Card 2: Suspended Users */}
          <Card className="border-slate-200 hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">
                Usuarios suspendidos
              </CardTitle>
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: '#1E293B15' }}
              >
                <UserX className="w-5 h-5" style={{ color: '#1E293B' }} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-[#111827]">{suspendedUsers}</div>
            </CardContent>
          </Card>

          {/* Card 3: Active Loans */}
          <Card className="border-slate-200 hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">
                Usuarios con préstamos activos
              </CardTitle>
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: '#F9731615' }}
              >
                <BookOpen className="w-5 h-5" style={{ color: '#F97316' }} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-[#111827]">{usersWithActiveLoans}</div>
            </CardContent>
          </Card>

          {/* Card 4: New Users This Week */}
          <Card className="border-slate-200 hover:shadow-lg transition-shadow">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-slate-600">
                Usuarios nuevos esta semana
              </CardTitle>
              <div
                className="w-10 h-10 rounded-lg flex items-center justify-center"
                style={{ backgroundColor: '#1E293B15' }}
              >
                <Users className="w-5 h-5" style={{ color: '#1E293B' }} />
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-[#111827]">{newUsersThisWeek}</div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Usuarios que requieren atención Section */}
      <div>
        <h2 className="text-xl font-semibold text-[#111827] mb-4">Usuarios que requieren atención</h2>
        <Card className="border-slate-200">
          <CardContent className="pt-6">
            <div className="space-y-4">
              {usersRequiringAttention.map((user, index) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between pb-4 border-b border-slate-100 last:border-0 last:pb-0"
                >
                  <div className="flex-1">
                    <p className="text-[#111827] font-medium">{user.name}</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge className={`${getBadgeColor(user.badge)} border text-xs`}>
                        {user.status}
                      </Badge>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate(`/users/${user.id}`)}
                    className="text-[#F97316] hover:text-[#ea580c] hover:bg-orange-50"
                  >
                    {user.action}
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-end">
        <Button
          onClick={() => navigate("/users/new")}
          className="bg-[#F97316] hover:bg-[#ea580c] text-white w-full sm:w-auto"
        >
          <Plus className="w-5 h-5 mr-2" />
          Agregar Usuario
        </Button>
        <Button
          onClick={() => setIsImportModalOpen(true)}
          variant="outline"
          className="border-[#F97316] text-[#F97316] hover:bg-orange-50 w-full sm:w-auto"
        >
          <Upload className="w-5 h-5 mr-2" />
          Importar Usuarios
        </Button>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              variant="outline"
              className="border-[#F97316] text-[#F97316] hover:bg-orange-50 w-full sm:w-auto"
            >
              <Download className="w-5 h-5 mr-2" />
              Exportar Usuarios
              <ChevronDown className="w-4 h-4 ml-2" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => handleExport('csv')}>
              <FileSpreadsheet className="w-4 h-4 mr-2" />
              Exportar como CSV
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleExport('excel')}>
              <File className="w-4 h-4 mr-2" />
              Exportar como Excel
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center">
        {/* Search */}
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
          <Input
            type="text"
            placeholder="Buscar usuario"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10 border-slate-300"
          />
        </div>

        {/* Role Filter */}
        <Select value={roleFilter} onValueChange={setRoleFilter}>
          <SelectTrigger className="w-full sm:w-[200px] border-slate-300">
            <SelectValue placeholder="Filtrar por rol" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los Roles</SelectItem>
            <SelectItem value="Administrador">Administrador</SelectItem>
            <SelectItem value="Bibliotecario">Bibliotecario</SelectItem>
            <SelectItem value="Profesor">Profesor</SelectItem>
            <SelectItem value="Estudiante">Estudiante</SelectItem>
            <SelectItem value="Colaborador">Colaborador</SelectItem>
          </SelectContent>
        </Select>

        {/* Status Filter */}
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger className="w-full sm:w-[200px] border-slate-300">
            <SelectValue placeholder="Filtrar por estado" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">Todos los Estados</SelectItem>
            <SelectItem value="Activo">Activo</SelectItem>
            <SelectItem value="Suspendido">Suspendido</SelectItem>
            <SelectItem value="Con multa">Con multa</SelectItem>
            <SelectItem value="Con préstamo">Con préstamo</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* User Table */}
      <div className="bg-white rounded-lg border border-slate-200 shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="bg-slate-50">
              <TableHead className="font-semibold text-[#111827]">Nombre</TableHead>
              <TableHead className="font-semibold text-[#111827]">ID Universitario</TableHead>
              <TableHead className="font-semibold text-[#111827]">Rol</TableHead>
              <TableHead className="font-semibold text-[#111827]">Estado</TableHead>
              <TableHead className="font-semibold text-[#111827]">Préstamos Activos</TableHead>
              <TableHead className="font-semibold text-[#111827]">Multas</TableHead>
              <TableHead className="font-semibold text-[#111827] text-right">Acciones</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredUsers.map((user) => (
              <TableRow
                key={user.id}
                className="hover:bg-slate-50 cursor-pointer transition-colors"
                onClick={() => navigate(`/users/${user.id}`)}
              >
                <TableCell>
                  <div>
                    <div className="font-medium text-[#111827]">{user.name}</div>
                    <div className="text-sm text-slate-500">{user.email}</div>
                  </div>
                </TableCell>
                <TableCell className="text-slate-600">{user.universityId}</TableCell>
                <TableCell>
                  <Badge className={`${getRoleColor(user.role)} border`}>
                    {user.role}
                  </Badge>
                </TableCell>
                <TableCell>
                  <Badge className={`${getStatusColor(user.status)} border`}>
                    {user.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  <span className="text-[#111827] font-medium">{user.activeLoans}</span>
                </TableCell>
                <TableCell>
                  <span
                    className={`font-medium ${
                      user.fines > 0 ? "text-red-600" : "text-green-600"
                    }`}
                  >
                    ${user.fines.toFixed(2)}
                  </span>
                </TableCell>
                <TableCell>
                  <div className="flex items-center justify-end gap-2">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        navigate(`/users/${user.id}/edit`);
                      }}
                      className="text-[#F97316] hover:text-[#ea580c] hover:bg-orange-50"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    {user.status !== "Suspendido" && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          navigate(`/users/${user.id}`);
                        }}
                        className="text-red-600 hover:text-red-700 hover:bg-red-50"
                      >
                        <Ban className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* Results Summary */}
      <div className="text-sm text-slate-500">
        Mostrando {filteredUsers.length} de {mockUsers.length} usuarios
      </div>

      {/* Import Modal */}
      <Dialog open={isImportModalOpen} onOpenChange={setIsImportModalOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle className="text-xl text-[#111827]">Importar Usuarios</DialogTitle>
            <DialogDescription className="text-slate-600">
              Importa múltiples usuarios desde un archivo CSV o Excel proveniente del sistema de servicios escolares.
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4 py-4">
            {/* Upload Area */}
            <div
              className={`flex flex-col items-center justify-center w-full h-48 border-2 border-dashed rounded-lg cursor-pointer transition-colors ${
                dragActive 
                  ? "border-[#F97316] bg-orange-50" 
                  : "border-slate-300 hover:border-slate-400"
              }`}
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              onClick={() => document.getElementById('file-input')?.click()}
            >
              <Upload className={`w-12 h-12 mb-3 ${dragActive ? 'text-[#F97316]' : 'text-slate-400'}`} />
              <p className="text-base font-medium text-slate-700 mb-1">
                Arrastrar archivo aquí
              </p>
              <p className="text-sm text-slate-500 mb-2">o</p>
              <Button
                type="button"
                variant="outline"
                className="border-[#F97316] text-[#F97316] hover:bg-orange-50"
              >
                Seleccionar archivo
              </Button>
              <p className="text-xs text-slate-400 mt-3">
                Formatos aceptados: CSV, XLSX
              </p>
              <input
                id="file-input"
                type="file"
                accept=".csv, .xlsx"
                className="hidden"
                onChange={handleFileInput}
              />
            </div>

            {/* File Info */}
            {selectedFile && (
              <div className="bg-slate-50 rounded-lg p-4 border border-slate-200">
                <p className="text-sm font-medium text-[#111827] mb-2">
                  Archivo seleccionado: {selectedFile.name}
                </p>
                <div className="grid grid-cols-3 gap-4 mt-3">
                  <div>
                    <p className="text-xs text-slate-500">Usuarios detectados</p>
                    <p className="text-lg font-semibold text-[#111827]">{importStats.detected}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Usuarios nuevos</p>
                    <p className="text-lg font-semibold text-green-600">{importStats.new}</p>
                  </div>
                  <div>
                    <p className="text-xs text-slate-500">Usuarios duplicados</p>
                    <p className="text-lg font-semibold text-orange-600">{importStats.duplicates}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Expected Structure */}
            <div className="space-y-2">
              <p className="text-sm font-medium text-[#111827]">
                Estructura esperada del archivo:
              </p>
              <div className="bg-white rounded-lg border border-slate-200 overflow-hidden">
                <table className="w-full text-sm">
                  <thead className="bg-slate-50 border-b border-slate-200">
                    <tr>
                      <th className="px-4 py-2 text-left font-semibold text-slate-700">Nombre</th>
                      <th className="px-4 py-2 text-left font-semibold text-slate-700">Matrícula</th>
                      <th className="px-4 py-2 text-left font-semibold text-slate-700">Correo</th>
                      <th className="px-4 py-2 text-left font-semibold text-slate-700">Rol</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-slate-100">
                      <td className="px-4 py-2 text-slate-600">Juan Pérez</td>
                      <td className="px-4 py-2 text-slate-600">A01234</td>
                      <td className="px-4 py-2 text-slate-600">juan@universidad.edu</td>
                      <td className="px-4 py-2 text-slate-600">Estudiante</td>
                    </tr>
                    <tr>
                      <td className="px-4 py-2 text-slate-600">María López</td>
                      <td className="px-4 py-2 text-slate-600">P00412</td>
                      <td className="px-4 py-2 text-slate-600">maria@universidad.edu</td>
                      <td className="px-4 py-2 text-slate-600">Profesor</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>

          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsImportModalOpen(false);
                setSelectedFile(null);
                setImportStats({ detected: 0, new: 0, duplicates: 0 });
              }}
            >
              Cancelar
            </Button>
            <Button
              onClick={handleImport}
              className="bg-[#F97316] hover:bg-[#ea580c] text-white"
              disabled={!selectedFile}
            >
              Importar Usuarios
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
