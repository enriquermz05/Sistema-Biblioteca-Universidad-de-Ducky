import { useState } from "react";
import { useNavigate, useParams, Link } from "react-router";
import { ArrowLeft, Save, BookOpen } from "lucide-react";
import { mockBooks, BookCategory, BookStatus, BookCondition } from "../data/mockBooks";
import { toast } from "sonner";

export function EditBookBiblio() {
  const navigate = useNavigate();
  const { id } = useParams();
  const book = mockBooks.find((b) => b.id === id);

  const [formData, setFormData] = useState({
    title: book?.title || "",
    author: book?.author || "",
    isbn: book?.isbn || "",
    publisher: book?.publisher || "",
    year: book?.year.toString() || new Date().getFullYear().toString(),
    category: (book?.category || "") as BookCategory | "",
    description: book?.description || "",
    pages: book?.pages.toString() || "",
    language: book?.language || "Español",
    totalCopies: book?.totalCopies.toString() || "1",
    availableCopies: book?.availableCopies.toString() || "1",
    status: (book?.status || "Disponible") as BookStatus,
    condition: (book?.condition || "Perfecto") as BookCondition,
    location: book?.location || "",
    replacementPrice: book?.replacementPrice.toString() || "",
  });

  const categories: BookCategory[] = [
    "Ciencias de la Computación",
    "Ingeniería",
    "Matemáticas",
    "Física",
    "Biología",
    "Química",
    "Administración",
    "Economía",
    "Psicología",
    "Literatura",
    "Historia",
    "Filosofía",
  ];

  const statuses: BookStatus[] = ["Disponible", "Prestado", "Dañado", "Perdido"];
  const conditions: BookCondition[] = ["Perfecto", "Daño Menor", "Dañado", "No Utilizable"];

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validación básica
    if (!formData.title || !formData.author || !formData.isbn || !formData.category) {
      toast.error("Campos requeridos", {
        description: "Por favor completa todos los campos obligatorios.",
      });
      return;
    }

    toast.success("Libro actualizado", {
      description: `"${formData.title}" ha sido actualizado exitosamente.`,
    });

    navigate("/books");
  };

  if (!book) {
    return (
      <div className="max-w-4xl mx-auto px-4 md:px-0">
        <div className="bg-white rounded-lg shadow-md p-8 md:p-12 text-center">
          <BookOpen className="w-12 h-12 md:w-16 md:h-16 text-slate-300 mx-auto mb-4" />
          <h2 className="text-xl md:text-2xl font-semibold text-slate-800 mb-2">Libro no encontrado</h2>
          <p className="text-sm md:text-base text-slate-600 mb-6">
            El libro que intentas editar no existe en el catálogo
          </p>
          <Link
            to="/books"
            className="inline-flex items-center gap-2 px-4 md:px-6 py-2.5 md:py-3 bg-[#F97316] text-white rounded-lg hover:bg-[#EA580C] transition-colors text-sm md:text-base"
          >
            <ArrowLeft className="w-4 h-4 md:w-5 md:h-5" />
            Volver a Gestión de Libros
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 px-4 md:px-0">
      {/* Header */}
      <div className="flex items-center gap-3 md:gap-4">
        <Link
          to="/books"
          className="p-2 hover:bg-slate-100 rounded-lg transition-colors"
        >
          <ArrowLeft className="w-5 h-5 md:w-6 md:h-6 text-slate-600" />
        </Link>
        <div>
          <h1 className="text-2xl md:text-3xl font-bold text-slate-800">Editar Libro</h1>
          <p className="text-sm md:text-base text-slate-600">Actualiza la información bibliográfica</p>
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-lg shadow-md p-4 md:p-8 space-y-6">
        {/* Basic Information */}
        <div>
          <h2 className="text-lg md:text-xl font-semibold text-slate-800 mb-4 flex items-center gap-2">
            <BookOpen className="w-4 h-4 md:w-5 md:h-5 text-[#F97316]" />
            Información Básica
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Título <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="title"
                value={formData.title}
                onChange={handleChange}
                required
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
                placeholder="Ej: Sistemas de Bases de Datos"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Autor <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="author"
                value={formData.author}
                onChange={handleChange}
                required
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
                placeholder="Ej: John Doe"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                ISBN <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="isbn"
                value={formData.isbn}
                onChange={handleChange}
                required
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
                placeholder="Ej: 978-0-13187-325-4"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Editorial
              </label>
              <input
                type="text"
                name="publisher"
                value={formData.publisher}
                onChange={handleChange}
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
                placeholder="Ej: Pearson"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Año de Publicación
              </label>
              <input
                type="number"
                name="year"
                value={formData.year}
                onChange={handleChange}
                min="1900"
                max={new Date().getFullYear() + 1}
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Categoría <span className="text-red-500">*</span>
              </label>
              <select
                name="category"
                value={formData.category}
                onChange={handleChange}
                required
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
              >
                <option value="">Seleccionar categoría</option>
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Número de Páginas
              </label>
              <input
                type="number"
                name="pages"
                value={formData.pages}
                onChange={handleChange}
                min="1"
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
                placeholder="Ej: 500"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Idioma
              </label>
              <input
                type="text"
                name="language"
                value={formData.language}
                onChange={handleChange}
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Descripción
              </label>
              <textarea
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={4}
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors resize-none text-sm md:text-base"
                placeholder="Descripción breve del contenido del libro..."
              />
            </div>
          </div>
        </div>

        {/* Inventory Information */}
        <div className="border-t border-slate-200 pt-6">
          <h2 className="text-lg md:text-xl font-semibold text-slate-800 mb-4">
            Información de Inventario
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Número de Copias
              </label>
              <input
                type="number"
                name="totalCopies"
                value={formData.totalCopies}
                onChange={handleChange}
                min="1"
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Copias Disponibles
              </label>
              <input
                type="number"
                name="availableCopies"
                value={formData.availableCopies}
                onChange={handleChange}
                min="0"
                max={formData.totalCopies}
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Estado de Disponibilidad
              </label>
              <select
                name="status"
                value={formData.status}
                onChange={handleChange}
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
              >
                {statuses.map((status) => (
                  <option key={status} value={status}>
                    {status}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Condición del Libro
              </label>
              <select
                name="condition"
                value={formData.condition}
                onChange={handleChange}
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
              >
                {conditions.map((condition) => (
                  <option key={condition} value={condition}>
                    {condition}
                  </option>
                ))}
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Ubicación en Biblioteca
              </label>
              <input
                type="text"
                name="location"
                value={formData.location}
                onChange={handleChange}
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
                placeholder="Ej: Sección A - Estante 15"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">
                Precio de Reposición
              </label>
              <p className="text-xs text-slate-500 mb-2">Valor utilizado en caso de daño o pérdida del libro.</p>
              <input
                type="number"
                name="replacementPrice"
                value={formData.replacementPrice}
                onChange={handleChange}
                min="0"
                step="0.01"
                className="w-full px-3 md:px-4 py-2.5 md:py-3 border border-slate-200 rounded-lg focus:outline-none focus:border-[#F97316] transition-colors text-sm md:text-base"
                placeholder="$450.00"
              />
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row items-center gap-3 md:gap-4 pt-6 border-t border-slate-200">
          <button
            type="submit"
            className="w-full sm:flex-1 px-4 md:px-6 py-2.5 md:py-3 bg-[#F97316] text-white rounded-lg hover:bg-[#EA580C] transition-colors flex items-center justify-center gap-2 text-sm md:text-base"
          >
            <Save className="w-4 h-4 md:w-5 md:h-5" />
            Guardar Cambios
          </button>
          <Link
            to="/books"
            className="w-full sm:flex-1 px-4 md:px-6 py-2.5 md:py-3 bg-slate-200 text-slate-700 rounded-lg hover:bg-slate-300 transition-colors text-center text-sm md:text-base"
          >
            Cancelar
          </Link>
        </div>
      </form>
    </div>
  );
}