import { Users, BookCheck, DollarSign, TrendingUp, TrendingDown, BookOpen, Search, HelpCircle, Library } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { Link } from "react-router";

export function Dashboard() {
  const stats = [
    {
      title: "Total de Usuarios",
      value: "2,847",
      change: "+12.5%",
      trend: "up",
      icon: Users,
      color: "#F97316",
    },
    {
      title: "Préstamos Activos",
      value: "1,234",
      change: "+8.2%",
      trend: "up",
      icon: BookCheck,
      color: "#1E293B",
    },
    {
      title: "Multas Pendientes",
      value: "$4,580",
      change: "-3.1%",
      trend: "down",
      icon: DollarSign,
      color: "#F97316",
    },
  ];

  const recentActivity = [
    { user: "Sarah Johnson", action: "Préstamo de 'Sistemas de Bases de Datos'", time: "hace 10 minutos" },
    { user: "Michael Chen", action: "Devolución de 'Fundamentos de IA'", time: "hace 25 minutos" },
    { user: "Emma Williams", action: "Pago de multa recibido", time: "hace 1 hora" },
    { user: "James Brown", action: "Cuenta suspendida", time: "hace 2 horas" },
    { user: "Lisa Anderson", action: "Nuevo usuario registrado", time: "hace 3 horas" },
  ];

  return (
    <div className="space-y-8">
      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat) => {
          const Icon = stat.icon;
          const TrendIcon = stat.trend === "up" ? TrendingUp : TrendingDown;
          
          return (
            <Card key={stat.title} className="border-slate-200 hover:shadow-lg transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between pb-2">
                <CardTitle className="text-sm font-medium text-slate-600">
                  {stat.title}
                </CardTitle>
                <div
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{ backgroundColor: `${stat.color}15` }}
                >
                  <Icon className="w-5 h-5" style={{ color: stat.color }} />
                </div>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-[#111827]">{stat.value}</div>
                <div className="flex items-center gap-1 mt-2">
                  <TrendIcon
                    className={`w-4 h-4 ${
                      stat.trend === "up" ? "text-green-500" : "text-red-500"
                    }`}
                  />
                  <span
                    className={`text-sm font-medium ${
                      stat.trend === "up" ? "text-green-500" : "text-red-500"
                    }`}
                  >
                    {stat.change}
                  </span>
                  <span className="text-sm text-slate-500 ml-1">del mes pasado</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Quick Access to Catalog */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Link
          to="/books"
          className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-lg p-6 text-white hover:shadow-lg transition-shadow group"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <Library className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-1">Gestión de Libros</h3>
              <p className="text-sm text-blue-100">Administra el catálogo</p>
            </div>
          </div>
        </Link>

        <Link
          to="/catalog"
          className="bg-gradient-to-br from-[#F97316] to-[#EA580C] rounded-lg p-6 text-white hover:shadow-lg transition-shadow group"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <BookOpen className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-1">Catálogo de Libros</h3>
              <p className="text-sm text-orange-100">Explora la colección</p>
            </div>
          </div>
        </Link>

        <Link
          to="/catalog/search"
          className="bg-gradient-to-br from-[#1E293B] to-[#334155] rounded-lg p-6 text-white hover:shadow-lg transition-shadow group"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white bg-opacity-10 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <Search className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-1">Buscar Libros</h3>
              <p className="text-sm text-slate-300">Encuentra un libro</p>
            </div>
          </div>
        </Link>

        <Link
          to="/help"
          className="bg-white border-2 border-slate-200 rounded-lg p-6 hover:shadow-lg hover:border-[#F97316] transition-all group"
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-[#F97316] bg-opacity-10 rounded-lg flex items-center justify-center group-hover:scale-110 transition-transform">
              <HelpCircle className="w-6 h-6 text-[#F97316]" />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-1 text-slate-800">Ayuda</h3>
              <p className="text-sm text-slate-600">Asistente virtual</p>
            </div>
          </div>
        </Link>
      </div>

      {/* Recent Activity */}
      <Card className="border-slate-200">
        <CardHeader>
          <CardTitle className="text-[#111827]">Actividad Reciente</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentActivity.map((activity, index) => (
              <div
                key={index}
                className="flex items-start gap-4 pb-4 border-b border-slate-100 last:border-0 last:pb-0"
              >
                <div className="w-2 h-2 rounded-full bg-[#F97316] mt-2"></div>
                <div className="flex-1">
                  <p className="text-[#111827] font-medium">{activity.user}</p>
                  <p className="text-slate-600 text-sm">{activity.action}</p>
                </div>
                <span className="text-xs text-slate-400">{activity.time}</span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}