import { createBrowserRouter } from "react-router";
import { Login } from "./screens/Login";
import { Home } from "./screens/Home";
import { BookSearch } from "./screens/BookSearch";
import { SearchResults } from "./screens/SearchResults";
import { BookDetails } from "./screens/BookDetails";
import { MyLoans } from "./screens/MyLoans";
import { Fines } from "./screens/Fines";
import { Profile } from "./screens/Profile";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Login,
  },
  {
    path: "/login",
    Component: Login,
  },
  {
    path: "/home",
    Component: Home,
  },
  {
    path: "/search",
    Component: BookSearch,
  },
  {
    path: "/search/results",
    Component: SearchResults,
  },
  {
    path: "/book/:id",
    Component: BookDetails,
  },
  {
    path: "/loans",
    Component: MyLoans,
  },
  {
    path: "/fines",
    Component: Fines,
  },
  {
    path: "/profile",
    Component: Profile,
  },
]);
