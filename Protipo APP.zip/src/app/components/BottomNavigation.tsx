import { Home, Search, BookOpen, User } from "lucide-react";
import { Link, useLocation } from "react-router";

export function BottomNavigation() {
  const location = useLocation();

  const navItems = [
    {
      path: "/home",
      icon: Home,
      label: "Inicio",
    },
    {
      path: "/search",
      icon: Search,
      label: "Buscar",
    },
    {
      path: "/loans",
      icon: BookOpen,
      label: "Préstamos",
    },
    {
      path: "/profile",
      icon: User,
      label: "Perfil",
    },
  ];

  const isActive = (path: string) => {
    if (path === "/search") {
      return location.pathname.startsWith("/search") || location.pathname.startsWith("/book");
    }
    return location.pathname === path;
  };

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 z-50">
      <div className="max-w-md mx-auto flex items-center justify-around h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const active = isActive(item.path);

          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex flex-col items-center justify-center flex-1 h-full transition-colors ${
                active ? "text-[#F97316]" : "text-slate-400"
              }`}
            >
              <Icon className={`w-6 h-6 mb-1 ${active ? "fill-[#F97316]" : ""}`} />
              <span className="text-xs font-medium">{item.label}</span>
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
