import { Outlet, Link, useLocation } from "react-router";
import { LayoutDashboard, Users, BookOpen, BookCheck, BookX, FileText, Bell, User, LogOut, HelpCircle, Library, Menu, X, Shield } from "lucide-react";
import { useState } from "react";

export function DashboardLayout() {
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const menuItems = [
    { icon: LayoutDashboard, label: "Tablero", path: "/dashboard" },
    { icon: Users, label: "Gestión de Usuarios", path: "/users" },
    { icon: Library, label: "Gestión de Libros", path: "/books" },
    { icon: BookOpen, label: "Catálogo de Libros", path: "/catalog" },
    { icon: BookCheck, label: "Préstamos", path: "/loans" },
    { icon: BookX, label: "Devoluciones", path: "/returns" },
    { icon: FileText, label: "Reportes", path: "/reports" },
    { icon: Shield, label: "Roles y Permisos", path: "/roles" },
    { icon: HelpCircle, label: "Ayuda", path: "/help" },
  ];

  const closeSidebar = () => setSidebarOpen(false);

  return (
    <div className="flex h-screen bg-[#F8FAFC]">
      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden"
          onClick={closeSidebar}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed lg:static inset-y-0 left-0 z-50
        w-64 bg-[#1E293B] text-white flex flex-col
        transform transition-transform duration-300 ease-in-out
        ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}
      `}>
        {/* Mobile Close Button */}
        <button
          onClick={closeSidebar}
          className="lg:hidden absolute top-4 right-4 p-2 text-white hover:bg-slate-700 rounded-lg transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Logo */}
        <div className="p-6 border-b border-slate-700">
          <h1 className="text-xl md:text-2xl font-bold text-[#F97316]">Sistema Biblioteca</h1>
          <p className="text-xs md:text-sm text-slate-400 mt-1">Portal Universitario</p>
        </div>

        {/* Menu */}
        <nav className="flex-1 py-6 overflow-y-auto">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path || 
              (item.path === "/users" && location.pathname.startsWith("/users")) ||
              (item.path === "/books" && location.pathname.startsWith("/books")) ||
              (item.path === "/catalog" && location.pathname.startsWith("/catalog")) ||
              (item.path === "/roles" && location.pathname.startsWith("/roles")) ||
              (item.path === "/help" && location.pathname.startsWith("/help"));
            
            return (
              <Link
                key={item.path}
                to={item.path}
                onClick={closeSidebar}
                className={`flex items-center gap-3 px-6 py-3 transition-colors ${
                  isActive
                    ? "bg-[#F97316] text-white border-r-4 border-[#FDBA74]"
                    : "text-slate-300 hover:bg-slate-700 hover:text-white"
                }`}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                <span className="text-sm md:text-base">{item.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* User Info */}
        <div className="p-6 border-t border-slate-700">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#F97316] flex items-center justify-center flex-shrink-0">
              <User className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">Usuario Admin</p>
              <p className="text-xs text-slate-400 truncate">Administrador</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0">
        {/* Top Navigation */}
        <header className="bg-white border-b border-slate-200 px-4 md:px-8 py-3 md:py-4 flex items-center justify-between">
          <div className="flex items-center gap-3 md:gap-4 min-w-0">
            {/* Mobile Menu Button */}
            <button
              onClick={() => setSidebarOpen(true)}
              className="lg:hidden p-2 hover:bg-slate-100 rounded-lg transition-colors"
            >
              <Menu className="w-6 h-6 text-slate-600" />
            </button>
            
            <div className="min-w-0">
              <h2 className="text-lg md:text-2xl font-semibold text-[#111827] truncate">
                {menuItems.find(item => 
                  location.pathname === item.path || 
                  (item.path === "/users" && location.pathname.startsWith("/users")) ||
                  (item.path === "/books" && location.pathname.startsWith("/books")) ||
                  (item.path === "/catalog" && location.pathname.startsWith("/catalog")) ||
                  (item.path === "/roles" && location.pathname.startsWith("/roles")) ||
                  (item.path === "/help" && location.pathname.startsWith("/help"))
                )?.label || "Tablero"}
              </h2>
            </div>
          </div>
          
          <div className="flex items-center gap-2 md:gap-4">
            <button className="relative p-2 hover:bg-slate-100 rounded-lg transition-colors">
              <Bell className="w-4 h-4 md:w-5 md:h-5 text-slate-600" />
              <span className="absolute top-1 right-1 w-2 h-2 bg-[#F97316] rounded-full"></span>
            </button>
            <Link
              to="/login"
              className="hidden md:flex items-center gap-2 px-4 py-2 text-slate-600 hover:text-[#F97316] transition-colors"
            >
              <LogOut className="w-5 h-5" />
              <span>Cerrar Sesión</span>
            </Link>
            <Link
              to="/login"
              className="md:hidden p-2 hover:bg-slate-100 rounded-lg transition-colors"
              title="Cerrar Sesión"
            >
              <LogOut className="w-5 h-5 text-slate-600" />
            </Link>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-auto p-4 md:p-8">
          <Outlet />
        </main>
      </div>
    </div>
  );
}