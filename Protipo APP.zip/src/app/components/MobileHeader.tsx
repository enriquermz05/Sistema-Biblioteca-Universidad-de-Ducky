import { useNavigate } from "react-router";
import { LogOut, BookOpen } from "lucide-react";

export function MobileHeader() {
  const navigate = useNavigate();

  const handleLogout = () => {
    navigate("/login");
  };

  return (
    <header className="bg-gradient-to-r from-[#1E293B] to-[#334155] text-white sticky top-0 z-30 shadow-md">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2">
          <div className="w-10 h-10 bg-[#F97316] rounded-lg flex items-center justify-center">
            <BookOpen className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="font-bold text-base">Sistema Biblioteca</h1>
            <p className="text-xs text-slate-300">Universidad de Ducky</p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          className="flex items-center gap-2 px-3 py-2 bg-[#F97316] hover:bg-[#EA580C] rounded-lg transition-colors"
          title="Cerrar Sesión"
        >
          <LogOut className="w-4 h-4" />
          <span className="text-sm">Salir</span>
        </button>
      </div>
    </header>
  );
}
