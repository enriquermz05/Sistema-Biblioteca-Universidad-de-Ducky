Update the "Gestión de Libros" and "Catálogo de Libros" modules of the University Library System dashboard.

IMPORTANT:
Extend the current interface without redesigning the layout. Maintain the existing design system, color palette, typography, and component styles used in the system.

All interface text must be in Spanish.

The goal is to add two new capabilities:

1) Print catalog results
2) Book replacement price management

--------------------------------------------------

FEATURE 1: Imprimir Catálogo

Inside the "Catálogo de Libros" page, add a new button above the search results table.

Buttons area should include:

Buscar Libro
Filtrar
Imprimir Catálogo

Button label:
"Imprimir Catálogo"

Icon suggestion:
Printer icon

Behavior:

When the user performs a search in the catalog, the system allows printing the visible search results.

Example scenario:

User searches by author or title.

The results appear in the book table.

Clicking "Imprimir Catálogo" generates a printable layout with the current search results.

Create a printable preview modal with the following layout:

Title:
"Catálogo de Libros"

Subtitle:
Resultados de búsqueda

Table columns:

Título
Autor
Editorial
Categoría
Disponibilidad
Precio de Reposición

Buttons in modal:

Cancelar
Imprimir

The printable layout should look clean and formatted for paper.

--------------------------------------------------

FEATURE 2: Precio de Reposición del Libro

Add a new field to book data.

Field name:

Precio de Reposición

Description text:

"Valor utilizado en caso de daño o pérdida del libro."

--------------------------------------------------

UPDATE: Formulario "Agregar Libro"

Add a new input field.

Field label:

Precio de Reposición

Input type:

Currency

Example placeholder:

$450.00

Form fields should now include:

Título
Autor
Editorial
Categoría
ISBN
Precio de Reposición
Estado del Libro

--------------------------------------------------

UPDATE: Formulario "Editar Libro"

Add the same field:

Precio de Reposición

Editable currency field.

--------------------------------------------------

UPDATE: Detalle del Libro

Inside the book information panel include:

Precio de Reposición

Example display:

Precio de reposición: $450 MXN

--------------------------------------------------

UPDATE: Tabla del Catálogo

Add a new column in the books table.

Column name:

Precio

Display format:

$450 MXN

Table columns should now be:

Título
Autor
Categoría
Estado
Disponibilidad
Precio

--------------------------------------------------

DESIGN REQUIREMENTS

Maintain the existing admin dashboard layout.

Use the same card styles, tables, buttons, and spacing already used in the system.

Buttons should follow the current primary and secondary button styles.

The printable preview should be clean and minimal.

--------------------------------------------------

The final result should improve the book management module with:

Book replacement pricing
Printable catalog search results
Updated book creation and editing forms
Catalog table with book prices