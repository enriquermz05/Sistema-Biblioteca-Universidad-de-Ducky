Create a web admin interface for managing roles and permissions in a University Library Management System.

IMPORTANT:
Generate this as a separate screen called "Gestión de Roles y Permisos".
All text, labels, buttons, and interface elements must be in Spanish.

Platform:
Web dashboard (desktop).

Design style:
Modern university admin dashboard consistent with the existing library system design.

Color palette:
Primary: #F97316 (Naranja)
Secondary: #1E293B (Azul oscuro)
Background: #F8FAFC
Text: #111827

User roles in the system:
Administrador
Bibliotecario
Profesor
Alumno
Colaborador

The screen should allow the Administrator to define what permissions each role has.

Layout structure:

1. Sidebar navigation (same style as the system)
Tablero
Gestión de Usuarios
Catálogo de Libros
Préstamos
Devoluciones
Reportes
Roles y Permisos

2. Main title
"Gestión de Roles y Permisos"

3. Role selector
Dropdown or tabs to select a role:
Administrador
Bibliotecario
Profesor
Alumno
Colaborador

4. Permissions table (matriz de permisos)

Columns:
Rol
Crear Usuarios
Suspender Usuarios
Registrar Préstamo
Registrar Devolución
Renovar Préstamo
Buscar Libros
Consultar Catálogo
Ver Reportes

Rows:
Administrador
Bibliotecario
Profesor
Alumno
Colaborador

Each permission should be represented with toggle switches or checkboxes.

5. Action buttons
Guardar Cambios
Restablecer Permisos

6. Behavior
When selecting a role, the interface should display the permissions assigned to that role.

Administrator has all permissions enabled.

Bibliotecario can manage loans and returns but cannot manage users or system permissions.

Profesor, Alumno, and Colaborador can only search books and view the catalog.

Design requirements:
Clean table layout
Toggle switches for permissions
Clear hierarchy
Consistent with the rest of the system UI
Professional admin dashboard style.