Update the current "Gestión de Libros" and "Gestión de Usuarios" interfaces of the University Library System.

IMPORTANT:
Do NOT redesign the existing UI. Only extend the current interface and maintain the same design system, color palette, typography, layout structure, and components already used in the dashboard.

All interface text must remain in Spanish.

-----------------------------------------------------

FEATURE 1: Mostrar Precio de Reposición en Detalle del Libro

In the "Detalle del Libro" screen (book description page), add a new field displaying the replacement price of the book.

Place this information inside the "Información Bibliográfica" section.

Add a new card similar to the other information cards.

New field:

Precio de Reposición

Example display:

Precio de reposición  
$450 MXN

Description tooltip text:

"Este valor se utiliza en caso de pérdida o daño del libro."

Maintain the same card design used for:
ISBN
Editorial
Idioma
Año de Publicación
Ubicación

The layout should remain balanced with the existing grid.

-----------------------------------------------------

FEATURE 2: Permitir editar precio desde el detalle

Inside the book detail page add a small edit option.

Example button near the information section:

Editar Libro

When clicked, open the existing edit modal including the field:

Precio de Reposición

Allow administrators to update this value.

-----------------------------------------------------

FEATURE 3: Multas en perfiles de usuario

Update the "Perfil de Usuario" screen inside the user management module.

Add a new section titled:

Multas del Usuario

This section should appear below the "Préstamos Activos".

Display a table with the following columns:

Libro  
Motivo  
Precio de reposición  
Estado  

Example rows:

Libro: Sistemas de Bases de Datos  
Motivo: Libro perdido  
Precio de reposición: $450 MXN  
Estado: Pendiente

Libro: Introducción a Algoritmos  
Motivo: Libro dañado  
Precio de reposición: $380 MXN  
Estado: Pagado

Use colored status badges:

Pendiente → rojo  
Pagado → verde

-----------------------------------------------------

FEATURE 4: Ejemplos visuales

Populate some user profiles with example fines.

Example users:

Juan Pérez  
Multa: Libro perdido  
Monto: $450 MXN

María López  
Multa: Libro dañado  
Monto: $380 MXN

Carlos Ruiz  
Multa: Préstamo vencido  
Monto: $120 MXN

This helps demonstrate the fine system.

-----------------------------------------------------

FEATURE 5: Indicador de multas en perfil

Inside the user profile header add a small indicator:

Multas activas: 1  
Total adeudo: $450 MXN

Use warning color styling.

-----------------------------------------------------

DESIGN REQUIREMENTS

Maintain the existing dashboard style.

Use the same card components, table styles, badges, and spacing.

Do not modify navigation layout.

Ensure the new information integrates naturally with the existing design.

-----------------------------------------------------

The system should now demonstrate:

Book replacement price management
Fines linked to lost or damaged books
User profiles showing outstanding fines
Editable replacement price