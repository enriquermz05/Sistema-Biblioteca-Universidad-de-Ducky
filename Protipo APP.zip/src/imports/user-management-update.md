Update the existing "Gestión de Usuarios" screen of the University Library System.

IMPORTANT:
Do not redesign the entire interface. Extend the current layout and maintain the same design system, color palette, typography, and components already used in the system.

All interface text must be in Spanish.

The goal is to improve the user management module by adding bulk user import functionality and highlighting important users.

----------------------------------------

NEW FEATURE 1: Importar Usuarios

Add a new button near the existing "Agregar Usuario" button.

Buttons should be:

+ Agregar Usuario
Importar Usuarios
Exportar Usuarios

Use the same button style already used in the system.

----------------------------------------

IMPORT USERS MODAL

When clicking "Importar Usuarios", open a modal window.

Modal title:
"Importar Usuarios"

Modal content:

Description text:
"Importa múltiples usuarios desde un archivo CSV o Excel proveniente del sistema de servicios escolares."

Upload area:

[ Arrastrar archivo aquí ]
o
[ Seleccionar archivo ]

Accepted formats:
CSV
XLSX

Display the expected file structure:

Nombre
Matrícula
Correo
Rol

Example table preview:

Nombre | Matrícula | Correo | Rol
Juan Pérez | A01234 | juan@universidad.edu | Alumno
María López | P00412 | maria@universidad.edu | Profesor

Buttons inside modal:

Cancelar
Importar Usuarios

Optional validation message:

Usuarios detectados: 120
Usuarios nuevos: 110
Usuarios duplicados: 10

----------------------------------------

NEW FEATURE 2: Exportar Usuarios

Add a button:

"Exportar Usuarios"

When clicked, show a small dropdown:

Exportar como CSV
Exportar como Excel

----------------------------------------

NEW FEATURE 3: Usuarios Importantes

Above the user table add a new section:

Title:
"Usuarios Importantes"

Add dashboard-style cards showing key indicators:

Usuarios con multas pendientes
Usuarios suspendidos
Usuarios con préstamos activos
Usuarios nuevos esta semana

Example layout:

[ Usuarios con multas ] 12
[ Usuarios suspendidos ] 4
[ Préstamos activos ] 86
[ Nuevos usuarios ] 15

Cards should follow the same card style used in the main dashboard.

----------------------------------------

NEW FEATURE 4: Lista de usuarios prioritarios

Below the indicator cards add a section:

Title:
"Usuarios que requieren atención"

Display a small list of important users:

Example:

Juan Pérez
Estado: Multa pendiente
Acción: Ver detalle

María López
Estado: Préstamo vencido
Acción: Ver préstamo

Carlos Ruiz
Estado: Cuenta suspendida
Acción: Ver usuario

Use colored status badges:

Rojo → Multa
Naranja → Préstamo vencido
Gris → Suspendido

----------------------------------------

USER TABLE IMPROVEMENTS

Keep the existing user table but add filters above it:

Buscar usuario
Filtrar por rol
Filtrar por estado

States:

Activo
Suspendido
Con multa
Con préstamo

----------------------------------------

DESIGN REQUIREMENTS

Maintain the same visual style as the existing web dashboard.

Color palette:
Primary Orange
Dark sidebar
Light card backgrounds

Layout:
Left sidebar navigation
Top header
Cards and tables

Spacing and component style must match the existing UI system.

----------------------------------------

The final screen should represent a complete User Management module including:

Manual user creation
Bulk user import
User export
User priority indicators
User attention alerts
User table with filters