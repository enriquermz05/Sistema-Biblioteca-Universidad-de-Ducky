Design a multi-screen UI prototype for a digital library system focused on searching books.

Create multiple connected screens for a web and mobile responsive interface. The design must be clean, modern, and easy to use.

Screens required:

1. Book Search Home Screen
- A search bar at the top where users can type the title, author, or category of a book.
- Quick filter buttons (Author, Category, Availability, Year).
- A list/grid preview of popular or recommended books.
- Navigation menu (Home, Search Books, My Loans, Help).

2. Search Results Screen
- Shows a list of books based on the search query.
- Each book card should display:
  - Book cover
  - Title
  - Author
  - Availability status (Available / Loaned / Damaged / Lost)
  - Button to view details
- Filters on the side for:
  - Author
  - Category
  - Availability
  - Publication year

3. Book Details Screen
- Large book cover
- Book title and author
- Bibliographic information
- Availability in real time
- Button to request loan or reserve
- Button to go back to results

4. Filtered Search Screen
- Shows search results after applying filters
- Visible active filters at the top
- Option to remove filters
- Quick sorting options (title, author, availability)

5. Help / Chatbot Screen
- Simple chatbot interface to help users search books
- Example questions like:
  - "How do I find a book?"
  - "How can I see if a book is available?"
- Chat input box at the bottom

Requirements:
- Maximum 3 clicks to reach book information
- Responsive design for desktop and mobile
- Friendly and accessible interface
- Fast navigation between screens
- Connect all screens with clickable prototype interactions
